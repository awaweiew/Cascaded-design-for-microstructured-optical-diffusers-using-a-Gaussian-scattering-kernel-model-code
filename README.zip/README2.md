# Circular Angular Distribution

## Requirements

Run this folder in MATLAB. Keep all `.m` files in the same directory.

## Quick Check

Open MATLAB in this directory and run:

```matlab
test_first_three_modules
test_full_pipeline_smoke
test_coordinate_optimization_smoke
```

These checks use reduced settings and are intended to verify the workflow.

## Run the Optimization

Run the main script from this directory:

```matlab
run_full_coordinate_optimization
```

Edit the `control` and `config` values near the top of the script before a production run. The script writes the selected configuration, numerical results, and figures to its results directory.

## Run Snell Refinement

First run the main optimization and use its saved `best_config.json` file:

```matlab
control = struct();
control.bestConfigJsonPath = fullfile(pwd, 'results', '<run-directory>', 'best_config.json');
result = run_snell_coordinate_optimization(control);
```

Replace `<run-directory>` with the directory produced by the optimization. Reduce `control.rayCount` for a shorter trial run.

## Main Files

- `run_full_coordinate_optimization.m` runs the Gaussian-kernel workflow.
- `run_snell_coordinate_optimization.m` refines a saved configuration with Snell tracing.
- `test_*.m` files run reduced verification workflows.
- Supporting functions create surfaces, evaluate distributions, search parameters, and save results.
