# Anisotropic Angular Distribution

## Requirements

Run this folder in MATLAB. Keep this folder beside `circular angular distribution`, because the dual-axis workflow uses its shared model functions.

## Quick Check

Open MATLAB in this directory and run:

```matlab
test_dual_axis_optimization_smoke
```

The smoke test uses reduced numerical settings.

## Run the Optimization

Run the main function with its default control values:

```matlab
result = run_dual_axis_optimization();
```

To change the workflow, pass a control structure. For example:

```matlab
control = struct('action', 'optimize', 'createFigures', true);
result = run_dual_axis_optimization(control);
```

Use `action` values `smokeTest`, `forwardOnly`, or `optimize`. Adjust target angles, numerical resolutions, search limits, and Snell settings through fields in `control` before a production run.

## Optional Snell Refinement

Set `control.enableSnellRefinement = true` before calling `run_dual_axis_optimization`. The main workflow then supplies the saved Gaussian configuration and random bank to the refinement function.

## Main Files

- `run_dual_axis_optimization.m` runs the dual-axis workflow.
- `run_dual_axis_snell_refinement.m` performs local Snell refinement for a completed Gaussian result.
- `test_dual_axis_optimization_smoke.m` runs a reduced verification workflow.
- Supporting functions evaluate directional widths, search parameters, generate figures, and save results.
