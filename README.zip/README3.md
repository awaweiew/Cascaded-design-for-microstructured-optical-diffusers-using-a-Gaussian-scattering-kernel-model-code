# Coherence Analysis

## Requirements

Use Python 3.9 or later with `numpy`, `torch`, and `matplotlib` installed. A CUDA-enabled PyTorch installation and visible CUDA devices are required for the default diffuser-generation and propagation settings.

Run commands from this directory. Use `--help` with any script to list its available options.

## Workflow

Run the scripts in the following order.

### 1. Generate Source Modes

```powershell
python 01_generate_source.py --save-path source_modes.npz
```

Adjust source dimensions, coherence length, and tilt with the command-line options when needed.

### 2. Generate a Diffuser

Use a compatible configuration JSON and choose an output archive path:

```powershell
python 02_generate_diffuser.py --config-json "..\circular angular distribution\results\<run-directory>\best_config.json" --design-name selected_design --save-name "diffusers\selected_diffuser.npz"
```

The script creates the `diffusers` directory when necessary. The selected JSON must contain the geometry, height, aspect-ratio, numerical, random, and optical fields used by the generator.

### 3. Propagate Modes and Save Statistics

Before running, set `PropagationConfig.devices` in `03_ww_propagate_stats.py` to CUDA devices available on the machine. Then run:

```powershell
python 03_ww_propagate_stats.py --gsm-path source_modes.npz --diffuser-file "diffusers\selected_diffuser.npz" --out-dir propagation_stats_results
```

For a short trial, add `--max-test-modes 1`. Propagation output is written as NPZ statistics files in the selected output directory.

### 4. Postprocess Statistics

```powershell
python 04_9_8_postprocess_fixed.py --stats-dir propagation_stats_results --output-dir postprocess_figures
```

This step writes coherence cross-section figures and a CSV summary.

## Input and Output Paths

- Source files are written by `01_generate_source.py`.
- Diffuser archives are written by `02_generate_diffuser.py`.
- Propagation statistics are written by `03_ww_propagate_stats.py`.
- Figures and CSV summaries are written by `04_9_8_postprocess_fixed.py`.

Pass explicit relative paths through command-line options when using files from another directory.
