# Polarization Analysis

## Requirements

Run this folder in MATLAB. Execute scripts from this directory so that generated MAT files are written here.

## Run a Self-Contained Simulation

Run:

```matlab
diffuser_polarization_integrated
```

This script generates a diffuser surface and saves `surface_23deg.mat` and `diffuser_polarization_results.mat`.

## Run from an Optimization Configuration

Provide a `best_config.json` file through an environment variable, then run:

```matlab
setenv('DIFFUSER_BEST_CONFIG_JSON', fullfile(pwd, '..', 'circular angular distribution', 'results', '<run-directory>', 'best_config.json'));
diffuser_polarization_best_config
```

Alternatively, run `diffuser_polarization_best_config` and select the JSON file in the file picker. The script saves `diffuser_surface_best_config.mat`, `diffuser_polarization_best_config_results.mat`, and figure files.

## Run from an Existing Height Field

Place `Zfinal.mat` in this directory. The file must contain a variable named `Z_final`. Then run:

```matlab
diffuser_polarization
```

The script calculates polarization quantities and displays the generated figures.

## Inputs and Outputs

- `diffuser_polarization_integrated.m` uses its internal numerical settings.
- `diffuser_polarization_best_config.m` reads a compatible `best_config.json` file.
- `diffuser_polarization.m` reads `Zfinal.mat` with `Z_final`.
- MAT and figure files are written to this directory or its figure-output subdirectory.
