%% =====================================================================
%  diffuser_polarization.m  （追迹顺序：平行基板 -> 粗糙出射面）
%
%  光路（光沿 -z 传播）：
%    空气 ──► 平面基板前表面(空气→玻璃，正入射) ──► 基板(平行平板) ──►
%    粗糙出射面(玻璃→空气，即 diffuser 微结构) ──► 空气 ──► 近场面 ──► 光瞳面(频域)
%
%  考察两个面的偏振特性：
%    1) 紧贴 diffuser 的近场面（空域）：出射复振幅 E(x,y) 的偏振态 ψ、χ、强度；
%    2) diffuser 后的光瞳面（频域）：近场角谱 E(fx,fy)=FFT{E(x,y)} 的偏振态，
%       横坐标由 sinθ=λ·f 映射为方向角 θ，即"偏振随角度的变化"。
%
%  与论文公式的对应（均为第4节/式2.16,2.18）：
%    坡度 -> 法向 -> 入射角 θi=atan|s| -> 菲涅尔透射 ts,tp(式4.3)
%    -> 局部 s/p 基 + Jones 追迹(式4.12~4.14) -> 偏振椭圆 ψ,χ(式4.18,4.19)
%  关键差异：粗糙面位于"出射侧"，介质为 玻璃(n_sub)->空气(n_air)，
%    因此存在全反射(TIR)截止角 θc=asin(n_air/n_sub)，陡斜面光线被截留不透射。
%
%  依赖：diffuser.m 生成的 Z_final（或 23度.mat）。本脚本不修改 diffuser.m。
%  =====================================================================
close all; clc; clear;

%% ================== 0. 载入高度场 ==================
if ~exist('Z_final','var')
    try
        S = load('Zfinal.mat');
        Z = S.Z_final;
        fprintf('已载入高度场 Z_final\n');
    catch
        error('未找到高度场：请先运行 diffuser.m 生成并保存 Z_final。');
    end
else
    Z = Z_final;
end

%% ================== 1. 物理与网格参数 ==================
n_air  = 1.0;            % 空气折射率
n_sub  = 1.5;            % 基材折射率（玻璃）
lambda = 0.55e-3;        % 工作波长 [mm]（0.55 um）——相位屏与频域计算必需

Lx = 0.5;                % X 方向尺寸 [mm]，与 diffuser.m 一致
[ny, nx] = size(Z);
dx = Lx / (nx - 1);      % 网格间距 [mm]
x  = linspace(0, Lx, nx);
y  = linspace(0, Lx, ny);% 假定方形区域

% 基板厚度：平行平板只引入一个全局相位延迟，不改变偏振与相对强度，
% 因此此处仅作说明性参数（不进入计算）。
T_sub = 1.0;             % 基板厚度 [mm]（本仿真不敏感）

% 入射偏振态（全局 x-y 坐标系 Jones 矢量）
Ein = [1; 1]/sqrt(2);    % 45° 线偏振

%% ================== 2. 坡度与局部法向 ==================
[sx, sy] = gradient(Z, dx, dx);        % 坡度（式2.16）
Nnorm = sqrt(sx.^2 + sy.^2 + 1);

% 表面法向（指向入射介质=玻璃，向上）：n = [-sx, -sy, 1]/N
nx = -sx ./ Nnorm;
ny = -sy ./ Nnorm;
nz =  1 ./ Nnorm;

% 入射方向（玻璃内，沿 -z）
ki = [0, 0, -1];

% 入射角：cos(theta_i) = -ki·n = 1/sqrt(1+s^2) → theta_i = atan|s|
cosTi   = -(ki(1).*nx + ki(2).*ny + ki(3).*nz);
cosTi   = min(max(cosTi, 0), 1);
theta_i = acos(cosTi);
slope_mag = sqrt(sx.^2 + sy.^2);       % |s| = tan(theta_i)

%% ================== 3. 前表面（平面，空气->玻璃，正入射） ==================
% 正入射时 s/p 简并，ts=tp，仅一个均匀振幅透射，无偏振变化、无相位结构
t_front = 2*n_air/(n_air + n_sub);    % = 0.8（振幅）

%% ================== 4. 粗糙出射面（玻璃->空气）菲涅尔透射 + TIR ==================
% 入射介质 n1=n_sub(玻璃)，出射介质 n2=n_air(空气)
th_c   = asin(n_air/n_sub);           % 全反射临界角
mask_tir = theta_i >= th_c;           % 陡斜面 -> 全反射，不透射

sinTt = (n_sub/n_air) .* sin(theta_i);% Snell（式4.2）
sinTt(mask_tir) = 1;                  % 占位，避免 sqrt 负数
cosTt = sqrt(max(0, 1 - sinTt.^2));

% 菲涅尔透射系数（玻璃->空气，式4.3）
ts = 2*n_sub*cosTi ./ (n_sub*cosTi + n_air*cosTt);
tp = 2*n_sub*cosTi ./ (n_sub*cosTt + n_air*cosTi);
ts(mask_tir) = 0;  tp(mask_tir) = 0;  % 全反射区无透射

% 二向色性（式4.5，用透射率；仅定义在透射区）
Ts = abs(ts).^2 .* (n_air.*cosTt)./(n_sub.*cosTi);
Tp = abs(tp).^2 .* (n_air.*cosTt)./(n_sub.*cosTi);
D  = (Ts - Tp) ./ (Ts + Tp + eps);
D(mask_tir) = NaN;                    % 全反射区无意义

% s-p 相位延迟（透射 ts,tp 为实数 → Delta=0；全反射区不透射）
Delta = angle(ts) - angle(tp);

%% ================== 5. 局部 s/p 基与 Jones 追迹（式4.1,4.12~4.14） ==================
phi = atan2(-nx, ny);                 % 入射面方位角（s 基相对 x 轴）
cph = cos(phi); sph = sin(phi);

Es =  cph.*Ein(1) + sph.*Ein(2);      % R(phi)·Ein → 投影到 s
Ep = -sph.*Ein(1) + cph.*Ein(2);      %              → 投影到 p

Es2 = ts .* Es;                       % 局部对角 Jones：diag(ts,tp)
Ep2 = tp .* Ep;

Ex = cph.*Es2 - sph.*Ep2;             % R(-phi) 转回全局
Ey = sph.*Es2 + cph.*Ep2;

%% ================== 6. 近场面（紧贴 diffuser 出射侧） ==================
% 出射面相位屏（薄相位屏近似）：凹坑处玻璃更厚 → 光程更长 → 相位滞后
% φ = - (2π/λ)(n_sub - n_air)·Z ； 该标量相位对 Ex、Ey 相同，故不改变
% 逐点偏振态，只影响衍射（频域光瞳）。（符号取负为"凹坑加厚玻璃"约定）
phase_screen = exp(-1i * (2*pi/lambda) * (n_sub - n_air) * Z);

% 近场复振幅 = 前表面均匀透射 × Jones 追迹(偏振+振幅) × 相位屏
E_near_x = t_front * Ex .* phase_screen;
E_near_y = t_front * Ey .* phase_screen;

% 近场偏振椭圆与强度
I_near = abs(E_near_x).^2 + abs(E_near_y).^2;
psi_near = 0.5 * atan2( 2*real(conj(E_near_x).*E_near_y), ...
                        abs(E_near_x).^2 - abs(E_near_y).^2 );
tmp = 2*imag(conj(E_near_x).*E_near_y) ./ (abs(E_near_x).^2 + abs(E_near_y).^2 + eps);
tmp = min(max(tmp, -1), 1);
chi_near = 0.5 * asin(tmp);

%% ================== 7. 光瞳面（频域：近场角谱） ==================
E_pup_x = fftshift(fft2(E_near_x));
E_pup_y = fftshift(fft2(E_near_y));

% 频域坐标
fx = (-nx/2 : nx/2-1) / (nx*dx);      % 空间频率 [mm^-1]
fy = (-ny/2 : ny/2-1) / (ny*dx);

% 只保留传播波（角谱 |sinθ|=|λf|≤1），并把频率映射为方向角 θ
fmax = 1/lambda;
idx_x = abs(fx) <= fmax;
idx_y = abs(fy) <= fmax;
theta_x = asind(lambda*fx(idx_x));    % 方向角 [deg]，单调无 NaN
theta_y = asind(lambda*fy(idx_y));
E_pup_x = E_pup_x(idx_y, idx_x);      % 裁剪到传播区（倏逝波不到远场）
E_pup_y = E_pup_y(idx_y, idx_x);

% 光瞳强度与偏振椭圆
I_pup = (abs(E_pup_x).^2 + abs(E_pup_y).^2);
psi_pup = 0.5 * atan2( 2*real(conj(E_pup_x).*E_pup_y), ...
                       abs(E_pup_x).^2 - abs(E_pup_y).^2 );
tmp = 2*imag(conj(E_pup_x).*E_pup_y) ./ (abs(E_pup_x).^2 + abs(E_pup_y).^2 + eps);
tmp = min(max(tmp, -1), 1);
chi_pup = 0.5 * asin(tmp);

%% ================== 8. 偏振表征与统计 ==================
% 近场 Stokes 参数
S0n = abs(E_near_x).^2 + abs(E_near_y).^2;
S1n = abs(E_near_x).^2 - abs(E_near_y).^2;
S2n = 2*real(conj(E_near_x).*E_near_y);
S3n = 2*imag(conj(E_near_x).*E_near_y);

% 空间(孔径)平均后的全局偏振度 DoP：反映"不同点偏振态不同"带来的退偏
DoP_near = sqrt( sum(S1n(:))^2 + sum(S2n(:))^2 + sum(S3n(:))^2 ) / sum(S0n(:));

% 光瞳 Stokes 与全局 DoP
S0p = abs(E_pup_x).^2 + abs(E_pup_y).^2;
S1p = abs(E_pup_x).^2 - abs(E_pup_y).^2;
S2p = 2*real(conj(E_pup_x).*E_pup_y);
S3p = 2*imag(conj(E_pup_x).*E_pup_y);
DoP_pup = sqrt( sum(S1p(:))^2 + sum(S2p(:))^2 + sum(S3p(:))^2 ) / sum(S0p(:));

fprintf('\n===== 偏振追迹统计（平行基板 → 粗糙出射面）=====\n');
fprintf('TIR 截留面积占比: %.2f%%（陡斜面光线被全反射，不透射）\n', ...
    100*mean(mask_tir(:)));
fprintf('入射角 theta_i: 均值 %.2f°, 最大 %.2f°, 临界角 %.2f°\n', ...
    rad2deg(mean(theta_i(:))), rad2deg(max(theta_i(:))), rad2deg(th_c));
fprintf('近场  偏振方位角 ψ: 均值 %.2f°, 标准差 %.2f°（输入 45°）\n', ...
    rad2deg(mean(psi_near(:))), rad2deg(std(psi_near(:))));
fprintf('近场  孔径平均 DoP: %.4f（<1 表示空间退偏）\n', DoP_near);
fprintf('光瞳  孔径平均 DoP: %.4f\n', DoP_pup);

%% ================== 9. 可视化 ==================
% --- 图1：出射面几何量 ---
figure('Name','出射面：入射角 / 二向色性 / TIR','Color','w');
subplot(1,3,1);
imagesc(x*1e3, y*1e3, rad2deg(theta_i)); axis image; colorbar;
title('入射角 \theta_i (deg)');
subplot(1,3,2);
imagesc(x*1e3, y*1e3, D); axis image; colorbar;
title('二向色性 D');
subplot(1,3,3);
imagesc(x*1e3, y*1e3, mask_tir); axis image; colorbar;
title('全反射区（不透射）');

% --- 图2：近场面（紧贴 diffuser） ---
figure('Name','近场面：强度 / 偏振方位角 / 椭率','Color','w');
subplot(1,3,1);
imagesc(x*1e3, y*1e3, I_near); axis image; colorbar;
title('近场强度 |E|^2（TIR 区为暗区）');
subplot(1,3,2);
imagesc(x*1e3, y*1e3, rad2deg(psi_near)); axis image; colorbar;
title('近场偏振方位角 \psi (deg)');
subplot(1,3,3);
imagesc(x*1e3, y*1e3, rad2deg(chi_near)); axis image; colorbar;
title('近场椭率角 \chi (deg)');

% --- 图3：光瞳面（频域/角度域） ---
figure('Name','光瞳面：角谱强度 / 偏振方位角 / 椭率','Color','w');
subplot(1,3,1);
imagesc(theta_x, theta_y, log10(I_pup+eps)); axis image; colorbar;
xlim([-70 70]); ylim([-70 70]);
title('光瞳角谱强度 (log)'); xlabel('\theta_x (deg)'); ylabel('\theta_y (deg)');
subplot(1,3,2);
imagesc(theta_x, theta_y, rad2deg(psi_pup)); axis image; colorbar;
xlim([-70 70]); ylim([-70 70]);
title('光瞳偏振方位角 \psi (deg)');
subplot(1,3,3);
imagesc(theta_x, theta_y, rad2deg(chi_pup)); axis image; colorbar;
xlim([-70 70]); ylim([-70 70]);
title('光瞳椭率角 \chi (deg)');

% --- 图4：近场偏振方位角直方图 ---
figure('Name','近场偏振方位角分布','Color','w');
histogram(rad2deg(psi_near(:)), 100, 'Normalization','pdf', 'EdgeColor','none');
xline(45,'--r','输入方位 45°','LineWidth',1.5);
xlabel('近场偏振方位角 \psi (deg)'); ylabel('概率密度');
title('散射片引起的偏振方位角空间弥散'); grid on;

fprintf('\n仿真完成。\n');
