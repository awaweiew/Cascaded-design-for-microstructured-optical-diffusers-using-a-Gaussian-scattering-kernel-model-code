%% ========================================================================
%  diffuser_polarization_best_config.m
%
%  目的：
%  1) 读取坐标优化程序输出的 best_config.json；
%  2) 按优化程序的公共随机数规则确定性重建同一块 Z_final；
%  3) 严格按照当前初稿第4节的物理链条进行偏振光线追迹：
%       Z -> slope -> local normal -> vector Snell -> local s/p basis
%       -> Fresnel transmission -> 3D electric-field transport
%       -> back planar interface -> direct transmission / TIR diagnosis
%       -> angle-resolved Stokes accumulation -> psi, chi, DoLP, DoP.
%
%  当前实现的传播支路：
%       air -> rough surface -> glass -> planar back surface -> air
%
%  说明：
%  - 第3节的薄相位屏 / FFT / ASM 不混入本脚本；本脚本是第4节的几何-偏振层。
%  - 背面发生 TIR 的光线不计入“直接透射”输出；但计算并输出其 rs/rp 相位差，
%    作为内部反射相位延迟的诊断量。若要让 TIR 光线最终重新出射，需要继续追踪
%    其再次撞击粗糙面的路径，这属于下一层多次反射模型。
%  - 每条确定性 Jones 光线本身保持完全偏振；DoP<1 只在角度/探测单元内对
%    多条不同偏振态光线进行非相干 Stokes 混合后出现。
%  ========================================================================

close all; clc; clear;

%% ========================= A. 读取 best_config =========================
% 可以直接填写 JSON 绝对路径。批处理时也可设置环境变量
% DIFFUSER_BEST_CONFIG_JSON；两者都为空时，程序会弹出文件选择框。
bestConfigJsonPath = '';
if isempty(bestConfigJsonPath)
    bestConfigJsonPath = getenv('DIFFUSER_BEST_CONFIG_JSON');
end
if isempty(bestConfigJsonPath)
    [bestConfigFileName,bestConfigFolder] = uigetfile( ...
        '*.json','选择优化结果 best_config.json');
    if isequal(bestConfigFileName,0)
        error('未选择 best_config.json，程序终止。');
    end
    bestConfigJsonPath = fullfile(bestConfigFolder,bestConfigFileName);
end

assert(isfile(bestConfigJsonPath), ...
    '找不到 best_config.json：%s',bestConfigJsonPath);
bestConfig = jsondecode(fileread(bestConfigJsonPath));

% 表面几何、分布、数值和随机参数全部以最终优化配置为准。
Lx = bestConfig.geometry.Lx;
Ly = bestConfig.geometry.Ly;
NxUnit = bestConfig.geometry.Nx;
NyUnit = bestConfig.geometry.Ny;
resx = bestConfig.numerical.resolutionX;
resy = bestConfig.numerical.resolutionY;

h_min = bestConfig.height.minimum;
h_max = bestConfig.height.maximum;
alpha_h = bestConfig.height.alpha;
beta_h = bestConfig.height.beta;

% JSON 已保存优化后的实际上下限，不能再次乘 currentKaScale。
ka_min = bestConfig.aspectKa.minimum;
ka_max = bestConfig.aspectKa.maximum;
alpha_ka = bestConfig.aspectKa.alpha;
beta_ka = bestConfig.aspectKa.beta;

kb = bestConfig.geometry.kb;
pos_jitter_frac = bestConfig.geometry.positionJitterFraction;
rot_jitter = bestConfig.geometry.rotationRange;
smooth_k = bestConfig.numerical.softMinK;
rngSeed = bestConfig.random.seed;

show_mesh = false;

fprintf('\n[已读取优化结果 best_config]\n');
fprintf('JSON: %s\n',bestConfigJsonPath);
fprintf('口径 %.6f mm x %.6f mm；网格 %d x %d；单元 %d x %d\n', ...
    Lx,Ly,resx,resy,NxUnit,NyUnit);
fprintf('h=[%.9f, %.9f] mm, Beta(%.6f, %.6f)\n', ...
    h_min,h_max,alpha_h,beta_h);
fprintf('ka=[%.9f, %.9f], Beta(%.6f, %.6f), kb=%.9f, seed=%d\n', ...
    ka_min,ka_max,alpha_ka,beta_ka,kb,rngSeed);

%% ========================= B. 偏振追迹参数 =============================
n_air = bestConfig.optical.nAir;
n_sub = bestConfig.optical.nSubstrate;
% best_config 当前不含波长；偏振 Fresnel 模型按无色散折射率计算，
% 此变量保留给后续相位/色散扩展，仍需在三阶段脚本中手动设置。
lambda = 0.55e-3;              % [mm]

% 平面背面位置。粗糙上表面 z=Z_final<=0，光沿 -z 进入基材。
T_sub = 1.0;                    % 名义基板厚度 [mm]
z_back = -T_sub;

% 入射偏振：'x' / 'y' / '45' / 'circularR' / 'custom'
input_pol = '45';
Ein_custom = [1; 1i; 0] / sqrt(2);

% 偏振追迹采样步长：只影响 ray tracing，不改变 2000x2000 的 Z_final 生成。
% 设为1即逐像素全分辨率追迹；若内存/速度受限，可先用2~8。
ray_stride = 4;

% 是否把有限 0.5 mm x 0.5 mm 外边界当成真实侧壁孔径。
% false 更适合把当前区域看作大尺寸 diffuser 的代表性局部窗口。
enforce_lateral_aperture = false;

% 角域统计参数
theta_limit_deg = max(abs([bestConfig.angular.minimumDegree, ...
                           bestConfig.angular.maximumDegree]));
Ntheta = bestConfig.angular.sampleCount;

% 观测平面（可选空间域统计）
enable_observation_plane = true;
z_air_obs = 10.0;               % 背面之后在空气中传播距离 [mm]
Nobs = 301;
obs_half_width = 8.0;            % 观测面半宽 [mm]

% 数值阈值
basis_tol = 1e-12;
intensity_tol = 1e-14;

%% ========================= C. 生成 diffuser =============================
x = linspace(0, Lx, resx);
y = linspace(0, Ly, resy);
[X, Y] = meshgrid(x, y);
Z_final = zeros(size(X));
surfaceCovered = false(size(X));
px = Lx / NxUnit;
py = Ly / NyUnit;
cx_base = linspace(px/2, Lx - px/2, NxUnit);
cy_base = linspace(py/2, Ly - py/2, NyUnit);
jx_max = (px/2) * pos_jitter_frac;
jy_max = (py/2) * pos_jitter_frac;

M = NxUnit*NyUnit;
h_all = zeros(1,M);
ka_all = zeros(1,M);
a_all = zeros(1,M);
b_all = zeros(1,M);
theta_all = zeros(1,M);
cx_all = zeros(1,M);
cy_all = zeros(1,M);
count = 0;

% 与 build_common_random_bank.m 完全相同：使用局部 mt19937ar 流，
% 并严格按照位置 x、位置 y、高度、ka、旋转的顺序生成五组分位数。
geometryStream = RandStream('mt19937ar','Seed',rngSeed);
positionXQuantile = rand(geometryStream,M,1);
positionYQuantile = rand(geometryStream,M,1);
heightQuantile = rand(geometryStream,M,1);
kaQuantile = rand(geometryStream,M,1);
rotationQuantile = rand(geometryStream,M,1);

heightQuantile = min(max(heightQuantile,eps('double')),1-eps('double'));
kaQuantile = min(max(kaQuantile,eps('double')),1-eps('double'));
heightNormalized = betaincinv(heightQuantile,alpha_h,beta_h);
kaNormalized = betaincinv(kaQuantile,alpha_ka,beta_ka);
heightSamples = h_min+(h_max-h_min).*heightNormalized;
kaSamples = ka_min+(ka_max-ka_min).*kaNormalized;

fprintf('正在生成 diffuser: %d x %d 网格, %d 个椭球单元...\n', resx, resy, M);
for i = 1:NxUnit
    for j = 1:NyUnit
        count = count+1;

        % --- 中心位置 ---
        cx0 = cx_base(i);
        cy0 = cy_base(j);
        dx_jit = (2*positionXQuantile(count)-1) * jx_max;
        dy_jit = (2*positionYQuantile(count)-1) * jy_max;
        cx = min(max(cx0 + dx_jit, px/2), Lx - px/2);
        cy = min(max(cy0 + dy_jit, py/2), Ly - py/2);

        % --- 公共分位数对应的高度与宽深比 ---
        h = heightSamples(count);
        h_all(count) = h;
        ka_current = kaSamples(count);
        ka_all(count) = ka_current;

        % --- 长轴和短轴 ---
        a = ka_current * h;
        b = kb * a;

        % --- 随机旋转 ---
        theta = rotationQuantile(count) * rot_jitter;

        % 记录单元参数，便于后续设计参数分析
        a_all(count) = a;
        b_all(count) = b;
        theta_all(count) = theta;
        cx_all(count) = cx;
        cy_all(count) = cy;

        % --- 只在当前椭球附近的严格定义域内生成和融合 ---
        rMax = max(a,b);
        ixLocal = find(x >= cx-rMax & x <= cx+rMax);
        iyLocal = find(y >= cy-rMax & y <= cy+rMax);
        if isempty(ixLocal) || isempty(iyLocal)
            continue;
        end

        Xlocal = X(iyLocal,ixLocal);
        Ylocal = Y(iyLocal,ixLocal);
        [positiveCap,insideCap] = ellipsoid_cap_positive( ...
            Xlocal,Ylocal,cx,cy,a,b,h,theta);
        negativeCap = -positiveCap;

        oldSurface = Z_final(iyLocal,ixLocal);
        oldCoverage = surfaceCovered(iyLocal,ixLocal);
        newSurface = oldSurface;
        firstCoverage = insideCap & ~oldCoverage;
        overlapCoverage = insideCap & oldCoverage;

        % 首次覆盖直接采用真实凹面；只有两个真实椭球重叠时才 soft-min。
        newSurface(firstCoverage) = negativeCap(firstCoverage);
        if any(overlapCoverage(:))
            newSurface(overlapCoverage) = stable_softmin_two( ...
                oldSurface(overlapCoverage),negativeCap(overlapCoverage),smooth_k);
        end
        Z_final(iyLocal,ixLocal) = newSurface;
        surfaceCovered(iyLocal,ixLocal) = oldCoverage | insideCap;
    end
end

if z_back >= min(Z_final(:))
    error(['背面平面 z_back=%.6f mm 必须位于全部粗糙上表面以下。', ...
           '当前 min(Z_final)=%.6f mm。请增大 T_sub。'], z_back, min(Z_final(:)));
end

fprintf('diffuser 生成完成: Z范围 [%.4f, %.4f] mm\n', min(Z_final(:)), max(Z_final(:)));
fprintf('ka样本均值 %.6f，h样本均值 %.6f mm，表面覆盖率 %.3f %%\n', ...
    mean(ka_all),mean(h_all),100*nnz(surfaceCovered)/numel(surfaceCovered));

% 保存可复现表面及来源配置，避免使用与实际目标角度不对应的固定文件名。
save('diffuser_surface_best_config.mat','Z_final','x','y', ...
    'bestConfig','bestConfigJsonPath','h_all','ka_all','a_all','b_all', ...
    'theta_all','cx_all','cy_all','-v7.3');
fprintf('表面矩阵已保存: diffuser_surface_best_config.mat\n');

%% ========================= D. 表面坡度与法向 ===========================
dx = x(2) - x(1);
dy = y(2) - y(1);
[dZdx, dZdy] = gradient(Z_final, dx, dy);

% 初稿约定：光从空气沿 -z 入射。这里统一使用“介质1 -> 介质2”的界面法向。
% 对粗糙上表面 air -> glass，法向应指向玻璃，即向下：
% n12 = [dZ/dx, dZ/dy, -1] / sqrt(1+|grad Z|^2)
Nmag = sqrt(1 + dZdx.^2 + dZdy.^2);
nrx = dZdx ./ Nmag;
nry = dZdy ./ Nmag;
nrz = -1 ./ Nmag;

%% ========================= E. 选取 ray-tracing 网格 =====================
ixr = 1:ray_stride:resx;
iyr = 1:ray_stride:resy;
Xr = X(iyr, ixr);
Yr = Y(iyr, ixr);
Zr = Z_final(iyr, ixr);
Nrx = nrx(iyr, ixr);
Nry = nry(iyr, ixr);
Nrz = nrz(iyr, ixr);
Sxr = dZdx(iyr, ixr);
Syr = dZdy(iyr, ixr);

Nr_y = numel(iyr);
Nr_x = numel(ixr);
Nrays = numel(Xr);
fprintf('偏振追迹采样: %d x %d = %d 条光线 (ray_stride=%d)\n', ...
    Nr_x, Nr_y, Nrays, ray_stride);

R0 = [Xr(:), Yr(:), Zr(:)];
N1 = [Nrx(:), Nry(:), Nrz(:)];
N1 = normalize_rows(N1);
K0 = repmat([0, 0, -1], Nrays, 1);

% 输入三维电场，保证与 K0 正交
switch lower(input_pol)
    case 'x'
        E0_single = [1; 0; 0];
    case 'y'
        E0_single = [0; 1; 0];
    case '45'
        E0_single = [1; 1; 0] / sqrt(2);
    case 'circularr'
        E0_single = [1; -1i; 0] / sqrt(2);
    case 'custom'
        E0_single = Ein_custom(:);
        E0_single = E0_single - [0;0;-1] * ([0;0;-1]' * E0_single);
        E0_single = E0_single / norm(E0_single);
    otherwise
        error('未知 input_pol: %s', input_pol);
end
E0 = repmat(E0_single.', Nrays, 1);

%% ========================= F. 第一界面：air -> rough -> glass ===========
% 1) 入射角
cos_i1 = sum(K0 .* N1, 2);
cos_i1 = min(max(cos_i1, 0), 1);
theta_i1 = acos(cos_i1);

% 数学一致性检查：theta_i1 应等于 atan(|grad Z|)
theta_slope = atan(sqrt(Sxr(:).^2 + Syr(:).^2));
max_theta_err = max(abs(theta_i1 - theta_slope));

% 2) 精确矢量 Snell
eta1 = n_air / n_sub;
sin_t1_sq = eta1^2 .* max(0, 1 - cos_i1.^2);
cos_t1 = sqrt(max(0, 1 - sin_t1_sq));
K1 = eta1 .* K0 + (cos_t1 - eta1 .* cos_i1) .* N1;
K1 = normalize_rows(K1);

% 3) 局部 s/p 基
[S1basis, P1i] = local_sp_basis(N1, K0, basis_tol);
P1t = normalize_rows(cross(S1basis, K1, 2));

% 4) Fresnel 透射：使用初稿式(4.3)，同时乘公共功率归一化因子
[ts1, tp1, tau_s1, tau_p1, Ts1, Tp1] = fresnel_transmission(...
    n_air, n_sub, cos_i1, cos_t1);
D1 = (Ts1 - Tp1) ./ (Ts1 + Tp1 + eps);

Es1 = sum(E0 .* S1basis, 2);
Ep1 = sum(E0 .* P1i, 2);
E1 = (tau_s1 .* Es1) .* S1basis + (tau_p1 .* Ep1) .* P1t;

% 第一界面直接透射为无损实折射率，ts/tp 相位基本相同
Delta1 = angle(ts1) - angle(tp1);

% 横向性检查
transverse_err1 = max(abs(sum(E1 .* K1, 2)) ./ (sqrt(sum(abs(E1).^2,2)) + eps));

%% ========================= G. 在玻璃内传播至平面背面 ===================
% 直线 r(t)=R0+t*K1 与 z=z_back 相交
valid_down = K1(:,3) < -basis_tol;
t_to_back = nan(Nrays,1);
t_to_back(valid_down) = (z_back - R0(valid_down,3)) ./ K1(valid_down,3);
valid_back_intersection = valid_down & (t_to_back > 0);

Rback = nan(Nrays,3);
Rback(valid_back_intersection,:) = R0(valid_back_intersection,:) + ...
    t_to_back(valid_back_intersection) .* K1(valid_back_intersection,:);

if enforce_lateral_aperture
    valid_lateral = valid_back_intersection & ...
        Rback(:,1) >= 0 & Rback(:,1) <= Lx & ...
        Rback(:,2) >= 0 & Rback(:,2) <= Ly;
else
    valid_lateral = valid_back_intersection;
end

%% ========================= H. 第二界面：glass -> planar back -> air ======
Nback = repmat([0, 0, -1], Nrays, 1);   % glass -> air 的法向
cos_i2 = sum(K1 .* Nback, 2);
cos_i2 = min(max(cos_i2, 0), 1);
theta_i2 = acos(cos_i2);

eta2 = n_sub / n_air;
sin_t2_sq = eta2^2 .* max(0, 1 - cos_i2.^2);
mask_tir2 = valid_lateral & (sin_t2_sq >= 1);
mask_direct = valid_lateral & ~mask_tir2;

cos_t2 = nan(Nrays,1);
cos_t2(mask_direct) = sqrt(max(0, 1 - sin_t2_sq(mask_direct)));

% 直接透射方向
K2 = nan(Nrays,3);
K2(mask_direct,:) = eta2 .* K1(mask_direct,:) + ...
    (cos_t2(mask_direct) - eta2 .* cos_i2(mask_direct)) .* Nback(mask_direct,:);
K2(mask_direct,:) = normalize_rows(K2(mask_direct,:));

% 第二界面局部基。仅对有效背面入射光线构造。
[S2basis, P2i] = local_sp_basis(Nback, K1, basis_tol);
P2t = nan(Nrays,3);
P2t(mask_direct,:) = normalize_rows(cross(S2basis(mask_direct,:), K2(mask_direct,:), 2));

% Fresnel 直接透射
Ts2 = zeros(Nrays,1); Tp2 = zeros(Nrays,1);
ts2 = zeros(Nrays,1); tp2 = zeros(Nrays,1);
tau_s2 = zeros(Nrays,1); tau_p2 = zeros(Nrays,1);
if any(mask_direct)
    [ts2(mask_direct), tp2(mask_direct), tau_s2(mask_direct), tau_p2(mask_direct), ...
        Ts2(mask_direct), Tp2(mask_direct)] = fresnel_transmission(...
        n_sub, n_air, cos_i2(mask_direct), cos_t2(mask_direct));
end
D2 = nan(Nrays,1);
D2(mask_direct) = (Ts2(mask_direct) - Tp2(mask_direct)) ./ ...
                  (Ts2(mask_direct) + Tp2(mask_direct) + eps);

Es2 = sum(E1 .* S2basis, 2);
Ep2 = sum(E1 .* P2i, 2);
E2 = nan(Nrays,3);
E2(mask_direct,:) = ...
    (tau_s2(mask_direct) .* Es2(mask_direct)) .* S2basis(mask_direct,:) + ...
    (tau_p2(mask_direct) .* Ep2(mask_direct)) .* P2t(mask_direct,:);

% 第二界面直接透射相位差
Delta2 = nan(Nrays,1);
Delta2(mask_direct) = angle(ts2(mask_direct)) - angle(tp2(mask_direct));

% TIR 诊断：精确复 Fresnel 反射系数，注意 TIR 时是 |r|=1，而不是 |t|=1。
rs_tir = nan(Nrays,1);
rp_tir = nan(Nrays,1);
Delta_tir = nan(Nrays,1);
if any(mask_tir2)
    sin_t2 = sqrt(sin_t2_sq(mask_tir2));
    cos_t2_complex = 1i * sqrt(max(0, sin_t2.^2 - 1));
    ci = cos_i2(mask_tir2);
    rs = (n_sub.*ci - n_air.*cos_t2_complex) ./ ...
         (n_sub.*ci + n_air.*cos_t2_complex);
    rp = (n_air.*ci - n_sub.*cos_t2_complex) ./ ...
         (n_air.*ci + n_sub.*cos_t2_complex);
    rs_tir(mask_tir2) = rs;
    rp_tir(mask_tir2) = rp;
    Delta_tir(mask_tir2) = angle(rs) - angle(rp);
end

% 最终电场横向性
transverse_err2 = max(abs(sum(E2(mask_direct,:) .* K2(mask_direct,:), 2)) ./ ...
    (sqrt(sum(abs(E2(mask_direct,:)).^2,2)) + eps));

%% ========================= I. 最终空气中局部偏振基与 Stokes ============
% 对每条最终出射光线构造“以全局 x 方向为参考”的横向基。
% eH = global x 投影到垂直于 k2 的平面；eV=eH x k2。
K2d = K2(mask_direct,:);
E2d = E2(mask_direct,:);
Nd = size(K2d,1);

ex_lab = repmat([1,0,0], Nd, 1);
projx = sum(ex_lab .* K2d, 2);
eH = ex_lab - projx .* K2d;
eHn = sqrt(sum(eH.^2,2));

% 极端情况下若 k 几乎平行 global x，则改用 global y 作为参考。
badH = eHn < basis_tol;
if any(badH)
    ey_lab = repmat([0,1,0], sum(badH), 1);
    Kbad = K2d(badH,:);
    projy = sum(ey_lab .* Kbad, 2);
    eH(badH,:) = ey_lab - projy .* Kbad;
end
eH = normalize_rows(eH);
eV = normalize_rows(cross(eH, K2d, 2)); % 对 k=-z，eH=x 时 eV=+y

EH = sum(E2d .* eH, 2);
EV = sum(E2d .* eV, 2);

S0_ray = abs(EH).^2 + abs(EV).^2;
S1_ray = abs(EH).^2 - abs(EV).^2;
S2_ray = 2*real(conj(EH).*EV);
S3_ray = 2*imag(conj(EH).*EV);

psi_ray = 0.5 * atan2(S2_ray, S1_ray);
arg_chi = S3_ray ./ (S0_ray + eps);
arg_chi = min(max(arg_chi,-1),1);
chi_ray = 0.5 * asin(arg_chi);

% 每条非零 Jones 光线的 DoP 应接近1
DoP_ray = sqrt(S1_ray.^2 + S2_ray.^2 + S3_ray.^2) ./ (S0_ray + eps);

% 几何出射角
thx_ray = atan2d(K2d(:,1), -K2d(:,3));
thy_ray = atan2d(K2d(:,2), -K2d(:,3));

% 与初稿第2.3节线性坡度-角度映射做一致性诊断。
% 对小坡度，精确双界面 Snell 追迹应趋近：theta_out ~= (n_sub-n_air)*slope (rad)。
small_slope_mask_all = theta_i1 < deg2rad(5) & mask_direct;
if any(small_slope_mask_all)
    kxy_exact = K2(small_slope_mask_all,1:2) ./ (-K2(small_slope_mask_all,3));
    sxy_small = [Sxr(:),Syr(:)];
    sxy_small = sxy_small(small_slope_mask_all,:);
    kxy_linear = (n_sub-n_air)/n_air .* sxy_small;
    slope_angle_linear_rms = sqrt(mean(sum((kxy_exact-kxy_linear).^2,2)));
else
    slope_angle_linear_rms = NaN;
end

%% ========================= J. 角域 Stokes 非相干累计 ====================
theta_edges = linspace(-theta_limit_deg, theta_limit_deg, Ntheta+1);
theta_centers = 0.5*(theta_edges(1:end-1) + theta_edges(2:end));

[S0_ang,S1_ang,S2_ang,S3_ang,raycount_ang] = bin_stokes_2d(...
    thx_ray, thy_ray, S0_ray, S1_ray, S2_ray, S3_ray, theta_edges, theta_edges);

DoP_ang = sqrt(S1_ang.^2 + S2_ang.^2 + S3_ang.^2) ./ (S0_ang + eps);
DoLP_ang = sqrt(S1_ang.^2 + S2_ang.^2) ./ (S0_ang + eps);
psi_ang = 0.5 * atan2(S2_ang, S1_ang);
arg_chi_ang = S3_ang ./ (S0_ang + eps);
arg_chi_ang = min(max(arg_chi_ang,-1),1);
chi_ang = 0.5 * asin(arg_chi_ang);

empty_ang = S0_ang <= intensity_tol * max(S0_ang(:));
DoP_ang(empty_ang) = NaN;
DoLP_ang(empty_ang) = NaN;
psi_ang(empty_ang) = NaN;
chi_ang(empty_ang) = NaN;

% 整个出射角域若被一个不可分辨探测器整体接收，其有效 Stokes/DoP
S0_total = sum(S0_ray);
S1_total = sum(S1_ray);
S2_total = sum(S2_ray);
S3_total = sum(S3_ray);
DoP_total = sqrt(S1_total^2 + S2_total^2 + S3_total^2) / (S0_total + eps);
DoLP_total = sqrt(S1_total^2 + S2_total^2) / (S0_total + eps);
psi_total = 0.5 * atan2(S2_total,S1_total);
chi_total = 0.5 * asin(max(-1,min(1,S3_total/(S0_total+eps))));

%% ========================= K. 可选：实际观测平面 Stokes 累计 ============
if enable_observation_plane
    Rback_d = Rback(mask_direct,:);
    z_obs = z_back - z_air_obs;
    t_obs = (z_obs - z_back) ./ K2d(:,3);
    Robs = Rback_d + t_obs .* K2d;

    obs_edges = linspace(-obs_half_width, obs_half_width, Nobs+1);
    obs_centers = 0.5*(obs_edges(1:end-1)+obs_edges(2:end));
    [S0_obs,S1_obs,S2_obs,S3_obs,raycount_obs] = bin_stokes_2d(...
        Robs(:,1)-Lx/2, Robs(:,2)-Ly/2, S0_ray,S1_ray,S2_ray,S3_ray, ...
        obs_edges, obs_edges);

    DoP_obs = sqrt(S1_obs.^2 + S2_obs.^2 + S3_obs.^2) ./ (S0_obs + eps);
    DoLP_obs = sqrt(S1_obs.^2 + S2_obs.^2) ./ (S0_obs + eps);
    psi_obs = 0.5 * atan2(S2_obs,S1_obs);
    arg_chi_obs = S3_obs ./ (S0_obs + eps);
    arg_chi_obs = min(max(arg_chi_obs,-1),1);
    chi_obs = 0.5 * asin(arg_chi_obs);

    empty_obs = S0_obs <= intensity_tol * max(S0_obs(:));
    DoP_obs(empty_obs)=NaN; DoLP_obs(empty_obs)=NaN;
    psi_obs(empty_obs)=NaN; chi_obs(empty_obs)=NaN;
else
    obs_centers=[]; S0_obs=[]; DoP_obs=[]; DoLP_obs=[]; psi_obs=[]; chi_obs=[]; %#ok<NASGU>
    raycount_obs=[]; %#ok<NASGU>
end

%% ========================= L. 旋转线偏振片指标 ===========================
% 线偏振片只能测到 DoLP，而不是包含 S3 的完整 DoP。
analyzer_deg = linspace(0,180,361);
I_analyzer = 0.5 * (S0_total + S1_total*cosd(2*analyzer_deg) + ...
                   S2_total*sind(2*analyzer_deg));
Imax_an = max(I_analyzer);
Imin_an = min(I_analyzer);
DoLP_from_analyzer = (Imax_an-Imin_an)/(Imax_an+Imin_an+eps);

%% ========================= M. 数值与物理一致性输出 ======================
th_c = asind(n_air/n_sub);
fprintf('\n================ 偏振追迹结果 ================\n');
fprintf('第一界面：air -> rough glass；第二界面：glass -> planar air\n');
fprintf('坡度角一致性 max|theta_i1-atan(|gradZ|)| = %.3e deg\n', rad2deg(max_theta_err));
fprintf('第一界面 E·k 横向性最大相对误差 = %.3e\n', transverse_err1);
fprintf('最终出射 E·k 横向性最大相对误差 = %.3e\n', transverse_err2);
if isfinite(slope_angle_linear_rms)
    fprintf('小坡度下精确Snell与 Ktheta 线性映射的方向斜率RMS误差 = %.3e\n', slope_angle_linear_rms);
end
fprintf('粗糙面局部入射角: mean %.3f deg, max %.3f deg\n', ...
    rad2deg(mean(theta_i1)), rad2deg(max(theta_i1)));
fprintf('背面玻璃侧入射角: mean %.3f deg, max %.3f deg, 临界角 %.3f deg\n', ...
    rad2deg(mean(theta_i2(valid_lateral))), rad2deg(max(theta_i2(valid_lateral))), th_c);
fprintf('背面TIR光线占有效入射光线比例 = %.3f %%\n', ...
    100*sum(mask_tir2)/max(1,sum(valid_lateral)));
fprintf('直接透射光线比例 = %.3f %%（相对有效背面入射）\n', ...
    100*sum(mask_direct)/max(1,sum(valid_lateral)));
valid_dop_ray = S0_ray>intensity_tol;
if any(valid_dop_ray)
    fprintf('直接透射单光线 DoP: mean %.8f, min %.8f\n', ...
        mean(DoP_ray(valid_dop_ray)), min(DoP_ray(valid_dop_ray)));
else
    fprintf('警告：没有非零直接透射光线可用于 DoP 统计。\n');
end
fprintf('全角域不可分辨接收：DoLP = %.6f, DoP = %.6f\n', DoLP_total, DoP_total);
fprintf('全角域等效 psi = %.3f deg, chi = %.3f deg\n', ...
    rad2deg(psi_total), rad2deg(chi_total));
fprintf('旋转线偏振片调制度 = %.6f（应等于 DoLP）\n', DoLP_from_analyzer);
fprintf('第一界面 max|Delta_trans| = %.3e deg\n', ...
    rad2deg(max(abs(Delta1))));
if any(mask_direct)
    fprintf('第二界面直接透射 max|Delta_trans| = %.3e deg\n', ...
        rad2deg(max(abs(Delta2(mask_direct)))));
end
if any(mask_tir2)
    fprintf('TIR反射相位差 Delta_rs-rp: mean %.3f deg, range [%.3f, %.3f] deg\n', ...
        rad2deg(mean(Delta_tir(mask_tir2))), ...
        rad2deg(min(Delta_tir(mask_tir2))), rad2deg(max(Delta_tir(mask_tir2))));
end
fprintf('==============================================\n');

%% ========================= N. 可视化 ====================================
% Optics Express 风格：双栏宽度、Arial 字体、内向刻度、白色背景，
% 同时导出 600 dpi PNG 和保留矢量文字/坐标轴的 PDF。
scriptDirectory = fileparts(mfilename('fullpath'));
if isempty(scriptDirectory)
    scriptDirectory = pwd;
end
figureOutputDirectory = fullfile(scriptDirectory,'Optics_Express_figures');
if ~isfolder(figureOutputDirectory)
    mkdir(figureOutputDirectory);
end
if isfield(bestConfig,'dualTarget')
    designTag = 'dual_direction';
    polarizationFigureBaseName = 'Fig_3_15_angle_resolved_polarization';
else
    designTag = 'single_direction';
    polarizationFigureBaseName = 'Fig_3_14_angle_resolved_polarization';
end

% 1) diffuser 表面
figSurface = figure('Name','Diffuser surface','Color','w');
if show_mesh
    surf(1e3*X,1e3*Y,1e3*Z_final,1e3*Z_final,'EdgeColor',[0.2 0.2 0.2]);
else
    surf(1e3*X,1e3*Y,1e3*Z_final,1e3*Z_final,'EdgeColor','none');
end
axis equal; shading interp; colormap(gca,parula(256)); colorbar;
xlabel('x (\mum)'); ylabel('y (\mum)'); zlabel('z (\mum)');
title('Diffuser surface'); view(45,45); light; lighting gouraud;
export_oe_figure(figSurface,figureOutputDirectory, ...
    ['diffuser_surface_' designTag],17.8,10.8);

% 2) 几何/Fresnel 局部量
figLocal = figure('Name','Local ray/Fresnel diagnostics','Color','w');
tiledlayout(2,3,'Padding','compact','TileSpacing','compact');
nexttile;
imagesc(x(ixr)*1e3,y(iyr)*1e3,rad2deg(reshape(theta_i1,Nr_y,Nr_x))); axis image; set(gca,'YDir','normal'); colorbar;
title('(a) Rough-surface incidence angle'); xlabel('x (\mum)'); ylabel('y (\mum)');
nexttile;
imagesc(x(ixr)*1e3,y(iyr)*1e3,reshape(D1,Nr_y,Nr_x)); axis image; set(gca,'YDir','normal'); colorbar;
title('(b) Air-to-glass transmittance');
nexttile;
imagesc(x(ixr)*1e3,y(iyr)*1e3,rad2deg(reshape(theta_i2,Nr_y,Nr_x))); axis image; set(gca,'YDir','normal'); colorbar;
title('(c) Back-surface incidence angle');
nexttile;
D2map=reshape(D2,Nr_y,Nr_x);
imagesc(x(ixr)*1e3,y(iyr)*1e3,D2map); axis image; set(gca,'YDir','normal'); colorbar;
title('(d) Glass-to-air transmittance');
nexttile;
imagesc(x(ixr)*1e3,y(iyr)*1e3,reshape(mask_tir2,Nr_y,Nr_x)); axis image; set(gca,'YDir','normal'); colorbar;
title('(e) Back-surface TIR mask');
nexttile;
psi_map=nan(Nrays,1); psi_map(mask_direct)=rad2deg(psi_ray);
imagesc(x(ixr)*1e3,y(iyr)*1e3,reshape(psi_map,Nr_y,Nr_x)); axis image; set(gca,'YDir','normal'); colorbar;
title('(f) Transmitted-ray azimuth (deg)');
colormap(figLocal,parula(256));
export_oe_figure(figLocal,figureOutputDirectory, ...
    ['local_fresnel_diagnostics_' designTag],17.8,11.2);

% 3) 角域偏振结果
figAngle = figure('Name','Angle-resolved polarization','Color','w');
tiledlayout(2,3,'Padding','compact','TileSpacing','compact');
nexttile;
imagesc(theta_centers,theta_centers,log10(S0_ang+eps)); axis image; set(gca,'YDir','normal'); colorbar;
xlabel('\theta_x (deg)'); ylabel('\theta_y (deg)'); title('(a) log_{10} S_0');
nexttile;
imagesc(theta_centers,theta_centers,rad2deg(psi_ang)); axis image; set(gca,'YDir','normal'); colorbar;
title('(b) \psi(\theta_x,\theta_y) (deg)');
nexttile;
imagesc(theta_centers,theta_centers,rad2deg(chi_ang)); axis image; set(gca,'YDir','normal'); colorbar;
title('(c) \chi(\theta_x,\theta_y) (deg)');
nexttile;
imagesc(theta_centers,theta_centers,DoLP_ang); axis image; set(gca,'YDir','normal'); colorbar; clim([0 1]);
title('(d) DoLP'); xlabel('\theta_x (deg)'); ylabel('\theta_y (deg)');
nexttile;
imagesc(theta_centers,theta_centers,DoP_ang); axis image; set(gca,'YDir','normal'); colorbar; clim([0 1]);
title('(e) DoP');
nexttile;
imagesc(theta_centers,theta_centers,raycount_ang); axis image; set(gca,'YDir','normal'); colorbar;
title('(f) Ray count per angular bin');
colormap(figAngle,parula(256));
export_oe_figure(figAngle,figureOutputDirectory, ...
    [polarizationFigureBaseName '_' designTag],17.8,11.2);

% 4) 观测平面偏振结果
if enable_observation_plane
    figObservation = figure('Name','Observation-plane polarization','Color','w');
    tiledlayout(2,3,'Padding','compact','TileSpacing','compact');
    nexttile;
    imagesc(obs_centers,obs_centers,log10(S0_obs+eps)); axis image; set(gca,'YDir','normal'); colorbar;
    xlabel('x_{obs} (mm)'); ylabel('y_{obs} (mm)'); title('(a) log_{10} S_0');
    nexttile;
    imagesc(obs_centers,obs_centers,rad2deg(psi_obs)); axis image; set(gca,'YDir','normal'); colorbar;
    title('(b) \psi_{obs} (deg)');
    nexttile;
    imagesc(obs_centers,obs_centers,rad2deg(chi_obs)); axis image; set(gca,'YDir','normal'); colorbar;
    title('(c) \chi_{obs} (deg)');
    nexttile;
    imagesc(obs_centers,obs_centers,DoLP_obs); axis image; set(gca,'YDir','normal'); colorbar; clim([0 1]);
    title('(d) DoLP_{obs}'); xlabel('x_{obs} (mm)'); ylabel('y_{obs} (mm)');
    nexttile;
    imagesc(obs_centers,obs_centers,DoP_obs); axis image; set(gca,'YDir','normal'); colorbar; clim([0 1]);
    title('(e) DoP_{obs}');
    nexttile;
    imagesc(obs_centers,obs_centers,raycount_obs); axis image; set(gca,'YDir','normal'); colorbar;
    title('(f) Ray count per spatial bin');
    colormap(figObservation,parula(256));
    export_oe_figure(figObservation,figureOutputDirectory, ...
        ['observation_plane_polarization_' designTag],17.8,11.2);
end

% 5) DoLP 检偏曲线
figAnalyzer = figure('Name','DoLP measurement curve','Color','w');
plot(analyzer_deg,I_analyzer/max(I_analyzer), ...
    'Color',[0 0.4470 0.7410],'LineWidth',1.2);
grid on;
xlabel('Analyzer angle (deg)');
ylabel('Normalized intensity');
title(sprintf('DoLP measurement curve (DoLP = %.4f)',DoLP_from_analyzer));
export_oe_figure(figAnalyzer,figureOutputDirectory, ...
    ['dolp_curve_' designTag],8.5,6.5);
%% ========================= O. 保存关键结果 ===============================
results = struct();
results.bestConfig = bestConfig;
results.bestConfigJsonPath = bestConfigJsonPath;
results.params = struct('n_air',n_air,'n_sub',n_sub,'lambda',lambda, ...
    'T_sub',T_sub,'ray_stride',ray_stride,'input_pol',input_pol, ...
    'theta_limit_deg',theta_limit_deg,'Ntheta',Ntheta, ...
    'targetFwhmDegree',bestConfig.target.fwhmDegree, ...
    'targetMetric',bestConfig.target.metric);
results.geometry = struct('Lx',Lx,'Ly',Ly,'resolutionX',resx, ...
    'resolutionY',resy,'Nx',NxUnit,'Ny',NyUnit,'randomSeed',rngSeed, ...
    'minimumHeight',min(Z_final(:)),'maximumHeight',max(Z_final(:)), ...
    'coveredFraction',nnz(surfaceCovered)/numel(surfaceCovered));
results.diffuser = struct('h_all',h_all,'ka_all',ka_all,'a_all',a_all,'b_all',b_all, ...
    'theta_all',theta_all,'cx_all',cx_all,'cy_all',cy_all);
results.theta_centers = theta_centers;
results.S0_ang = S0_ang; results.S1_ang=S1_ang; results.S2_ang=S2_ang; results.S3_ang=S3_ang;
results.DoLP_ang=DoLP_ang; results.DoP_ang=DoP_ang; results.psi_ang=psi_ang; results.chi_ang=chi_ang;
results.DoLP_total=DoLP_total; results.DoP_total=DoP_total;
results.psi_total=psi_total; results.chi_total=chi_total;
results.TIR_fraction = sum(mask_tir2)/max(1,sum(valid_lateral));
results.max_theta_consistency_error_deg = rad2deg(max_theta_err);
results.transverse_err1 = transverse_err1;
results.transverse_err2 = transverse_err2;
results.small_slope_linear_mapping_rms = slope_angle_linear_rms;

save('diffuser_polarization_best_config_results.mat','results','-v7.3');
fprintf('结果已保存: diffuser_polarization_best_config_results.mat\n');

%% ========================================================================
%  Local functions
%  ========================================================================
function [Z,inside] = ellipsoid_cap_positive(X, Y, cx, cy, a, b, h, theta)
    dx = X - cx;
    dy = Y - cy;
    ct = cos(theta); st = sin(theta);
    xp =  ct.*dx + st.*dy;
    yp = -st.*dx + ct.*dy;
    r2 = (xp./a).^2 + (yp./b).^2;
    inside = r2 <= 1;
    Z = zeros(size(X));
    Z(inside) = h * sqrt(max(0, 1 - r2(inside)));
end

function Z = stable_softmin_two(A,B,k)
    % 数值稳定的两曲面 soft-min，避免直接指数运算上溢或下溢。
    maximumExponent = max(-k.*A,-k.*B);
    Z = -(maximumExponent + log( ...
        exp(-k.*A-maximumExponent) + ...
        exp(-k.*B-maximumExponent))) ./ k;
end

function A = normalize_rows(A)
    n = sqrt(sum(abs(A).^2,2));
    n(n==0) = 1;
    A = A ./ n;
end

function [Sbasis, Pibasis] = local_sp_basis(N12, Ki, tol)
    % N12: medium1 -> medium2 normal
    % Ki : incident propagation direction toward interface
    % s  : perpendicular to incidence plane
    Sbasis = cross(N12, Ki, 2);
    ns = sqrt(sum(Sbasis.^2,2));
    bad = ns < tol;

    % Normal incidence: s/p is degenerate. Choose a deterministic transverse
    % axis; because ts=tp at exact normal incidence, physical result is basis-independent.
    if any(bad)
        Kb = Ki(bad,:);
        ref = repmat([0,1,0],sum(bad),1);
        % If k is nearly y, use x reference instead.
        bad_ref = abs(sum(ref.*Kb,2)) > 0.99;
        ref(bad_ref,:) = repmat([1,0,0],sum(bad_ref),1);
        Sbasis(bad,:) = ref - sum(ref.*Kb,2).*Kb;
    end
    Sbasis = normalize_rows(Sbasis);
    Pibasis = normalize_rows(cross(Sbasis, Ki, 2));
end

function [ts,tp,tau_s,tau_p,Ts,Tp] = fresnel_transmission(n1,n2,cos_i,cos_t)
    % Electric-field amplitude transmission coefficients, matching draft Eq.(4.3)
    ts = 2*n1.*cos_i ./ (n1.*cos_i + n2.*cos_t);
    tp = 2*n1.*cos_i ./ (n1.*cos_t + n2.*cos_i);

    % Power transmission coefficients
    flux = (n2.*cos_t) ./ (n1.*cos_i + eps);
    Ts = abs(ts).^2 .* flux;
    Tp = abs(tp).^2 .* flux;

    % Power-normalized Jones coefficients. The common sqrt(flux) factor does
    % not change polarization ellipse but makes |tau|^2 equal transmitted power.
    g = sqrt(max(0,flux));
    tau_s = g .* ts;
    tau_p = g .* tp;
end

function [S0m,S1m,S2m,S3m,countm] = bin_stokes_2d(xv,yv,S0,S1,S2,S3,xedges,yedges)
    Nx = numel(xedges)-1;
    Ny = numel(yedges)-1;
    ix = discretize(xv,xedges);
    iy = discretize(yv,yedges);
    valid = ~isnan(ix) & ~isnan(iy) & isfinite(S0) & S0>=0;
    lin = sub2ind([Ny,Nx],iy(valid),ix(valid));

    S0v = accumarray(lin,S0(valid),[Ny*Nx,1],@sum,0);
    S1v = accumarray(lin,S1(valid),[Ny*Nx,1],@sum,0);
    S2v = accumarray(lin,S2(valid),[Ny*Nx,1],@sum,0);
    S3v = accumarray(lin,S3(valid),[Ny*Nx,1],@sum,0);
    Cv  = accumarray(lin,1,[Ny*Nx,1],@sum,0);

    S0m = reshape(S0v,[Ny,Nx]);
    S1m = reshape(S1v,[Ny,Nx]);
    S2m = reshape(S2v,[Ny,Nx]);
    S3m = reshape(S3v,[Ny,Nx]);
    countm = reshape(Cv,[Ny,Nx]);
end

function export_oe_figure(figHandle,outputDirectory,baseName,widthCm,heightCm)
    % Consistent Optics Express-compatible sizing and typography.
    set(figHandle,'Color','w','Units','centimeters', ...
        'Position',[2 2 widthCm heightCm],'PaperPositionMode','auto');
    axesHandles = findall(figHandle,'Type','axes');
    set(axesHandles,'FontName','Arial','FontSize',8,'LineWidth',0.8, ...
        'TickDir','in','TickLength',[0.015 0.015],'Box','on','Layer','top');
    for axisIndex = 1:numel(axesHandles)
        axesHandles(axisIndex).Title.FontName = 'Arial';
        axesHandles(axisIndex).Title.FontSize = 8;
        axesHandles(axisIndex).Title.FontWeight = 'normal';
        axesHandles(axisIndex).XLabel.FontName = 'Arial';
        axesHandles(axisIndex).YLabel.FontName = 'Arial';
        axesHandles(axisIndex).ZLabel.FontName = 'Arial';
    end
    colorbarHandles = findall(figHandle,'Type','ColorBar');
    if ~isempty(colorbarHandles)
        set(colorbarHandles,'FontName','Arial','FontSize',7,'LineWidth',0.6, ...
            'TickDirection','in');
    end
    drawnow;
    exportgraphics(figHandle,fullfile(outputDirectory,[baseName '.png']), ...
        'Resolution',600,'BackgroundColor','white');
    if startsWith(baseName,'dolp_curve')
        pdfContentType = 'vector';
    else
        pdfContentType = 'image';
    end
    exportgraphics(figHandle,fullfile(outputDirectory,[baseName '.pdf']), ...
        'ContentType',pdfContentType,'Resolution',600, ...
        'BackgroundColor','white');
end




