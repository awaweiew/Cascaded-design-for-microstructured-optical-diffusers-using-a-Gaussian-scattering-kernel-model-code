function [positiveCap, insideCap] = ellipsoid_cap_positive( ...
        X, Y, centerX, centerY, semiMajorA, semiMinorB, height, rotation)
%ELLIPSOID_CAP_POSITIVE 在给定网格上生成旋转椭球的正值上半帽。
%
% 该函数是表面生成模块和有效区域提取模块共用的基础几何函数。
% 椭球自身主轴坐标中的方程为：
%
%   z = h*sqrt(1-x'^2/a^2-y'^2/b^2)。
%
% 函数只在 x'^2/a^2+y'^2/b^2<=1 的严格定义域内赋值；定义域外
% positiveCap 保持为零，并通过 insideCap=false 明确表示“当前椭球
% 不存在”。调用方若要生成凹坑，应显式使用 negativeCap=-positiveCap。
%
% 输入长度单位必须一致；本项目统一使用 mm，rotation 使用 rad。

deltaX = X-centerX;
deltaY = Y-centerY;
cosRotation = cos(rotation);
sinRotation = sin(rotation);

% 将全局坐标旋转到椭球自身的长轴、短轴坐标系。
xPrime =  cosRotation.*deltaX + sinRotation.*deltaY;
yPrime = -sinRotation.*deltaX + cosRotation.*deltaY;

normalizedRadiusSquared = ...
    (xPrime./semiMajorA).^2 + (yPrime./semiMinorB).^2;
insideCap = normalizedRadiusSquared <= 1;

positiveCap = zeros(size(X));
positiveCap(insideCap) = height .* sqrt(max( ...
    0, 1-normalizedRadiusSquared(insideCap)));
end

