function transmittedDirection = refract_vectors_snell( ...
        incidentDirection, interfaceNormal, refractiveIndex1, refractiveIndex2)
%REFRACT_VECTORS_SNELL 使用矢量 Snell 定律计算一组折射方向。
%
% 输入：
%   incidentDirection - N x 3 入射单位方向；
%   interfaceNormal   - N x 3 从介质 1 指向介质 2 的单位法向；
%   refractiveIndex1  - 入射侧折射率；
%   refractiveIndex2  - 出射侧折射率。
%
% 输出：
%   transmittedDirection - N x 3 折射单位方向。发生全反射或输入无效的
%                          行返回 NaN。
%
% 计算思想是把入射方向分解为界面切向分量和法向分量。Snell 定律要求
% 切向波矢连续，因此折射方向的切向分量乘以 n1/n2；剩余单位模长由
% 沿界面法向的分量补足。该实现与现有一阶段修正代码中的 refract_vec
% 使用同一符号约定。

assert(size(incidentDirection,2) == 3 && size(interfaceNormal,2) == 3, ...
    '入射方向和界面法向必须是 N x 3 数组。');
assert(size(incidentDirection,1) == size(interfaceNormal,1), ...
    '入射方向与界面法向的行数必须一致。');

eta = refractiveIndex1/refractiveIndex2;
normalProjection = sum(incidentDirection.*interfaceNormal, 2);
incidentTangent = incidentDirection-normalProjection.*interfaceNormal;
transmittedTangent = eta.*incidentTangent;
transmittedTangentSquared = sum(transmittedTangent.^2, 2);

valid = isfinite(transmittedTangentSquared) & transmittedTangentSquared <= 1;
transmittedDirection = nan(size(incidentDirection));

transmittedDirection(valid,:) = transmittedTangent(valid,:) + ...
    sqrt(max(0,1-transmittedTangentSquared(valid))).*interfaceNormal(valid,:);

% 对有效结果再次单位化，抑制浮点误差积累。
normValue = vecnorm(transmittedDirection(valid,:), 2, 2);
transmittedDirection(valid,:) = ...
    transmittedDirection(valid,:)./normValue;
end

