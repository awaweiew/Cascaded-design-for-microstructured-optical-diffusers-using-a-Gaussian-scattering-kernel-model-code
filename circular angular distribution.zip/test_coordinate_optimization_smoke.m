%% 单参数坐标优化烟雾测试
% 用很小的模型验证方向探测、候选记录、最优参数回写和多轮驱动接口。
% 该脚本只检查程序逻辑，不用于判断真实 30° diffuser 的最优参数。

clear;
clc;

config = create_diffuser_config();
config.geometry.Nx = 6;
config.geometry.Ny = 6;
config.numerical.resolutionX = 160;
config.numerical.resolutionY = 160;
config.numerical.searchResolutionX = 160;
config.numerical.searchResolutionY = 160;
config.angular.sampleCount = 81;
config.measurement.radialBinCount = 80;
config.optimization.maximumSweeps = 1;
config.optimization.maximumEvaluationsPerParameter = 5;
config.optimization.noImprovementPatience = 1;
config.optimization.performMultiSeedValidation = false;

% 仅启用 kaScale，并限制为三个粗搜索位置，控制测试耗时。
for index = 1:numel(config.optimization.parameters)
    config.optimization.parameters(index).enabled = false;
end
index = find(strcmp({config.optimization.parameters.name},'kaScale'),1);
config.optimization.parameters(index).enabled = true;
config.optimization.parameters(index).lowerBound = 0.98;
config.optimization.parameters(index).upperBound = 1.02;
config.optimization.parameters(index).initialValue = 1.00;
config.optimization.parameters(index).coarseStep = 0.02;
config.optimization.parameters(index).fineStep = 0.01;

validate_diffuser_config(config);
bank = build_common_random_bank(config);
searchResult = run_coordinate_search(config,bank,'');

assert(~isempty(searchResult.history), '优化历史为空。');
assert(height(searchResult.parameterResults) == 1, ...
    '单参数单轮测试应当只生成一条参数汇总。');
bestScale = searchResult.parameterResults.bestValue(1);
assert(bestScale >= 0.98 && bestScale <= 1.02, ...
    '最优参数超出人工指定范围。');
assert(abs(searchResult.bestConfig.optimization.currentKaScale-bestScale) < 1e-12, ...
    '最优 kaScale 未正确回写到最终配置。');

fprintf('单参数坐标优化烟雾测试通过，返回 kaScale = %.6f。\n',bestScale);

