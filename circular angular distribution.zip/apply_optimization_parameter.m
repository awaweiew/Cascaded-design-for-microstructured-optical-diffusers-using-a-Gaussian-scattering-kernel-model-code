function updatedConfig = apply_optimization_parameter(config, parameter, value, skipValidation)
%APPLY_OPTIMIZATION_PARAMETER 将一个候选参数值写入配置结构体。
%
% 该函数把“优化器中的抽象参数”与“物理模型中的实际字段”分离。
% optimize_one_parameter 只处理参数值和误差，不需要知道 kaScale 应同时
% 缩放两个边界，也不需要知道 arrayN 应同时写入 Nx、Ny。

if nargin < 4
    skipValidation = false;
end

assert(isscalar(value) && isfinite(value), '候选参数值必须为有限标量。');
assert(value >= parameter.lowerBound-10*eps && ...
       value <= parameter.upperBound+10*eps, ...
    '参数 %s 的候选值超出人工设定范围。',parameter.name);

if parameter.isInteger
    value = round(value);
end

updatedConfig = config;
switch parameter.application
    case 'kaScale'
        updatedConfig.aspectKa.minimum = ...
            config.optimization.baseAspectKaMinimum*value;
        updatedConfig.aspectKa.maximum = ...
            config.optimization.baseAspectKaMaximum*value;
        updatedConfig.optimization.currentKaScale = value;

    case 'direct'
        pathParts = strsplit(char(parameter.targetPath),'.');
        updatedConfig = set_nested_field_local(updatedConfig,pathParts,value);

    case 'arrayN'
        updatedConfig.geometry.Nx = value;
        updatedConfig.geometry.Ny = value;

    otherwise
        error('不支持的参数写入类型：%s。',parameter.application);
end

% 参数写入后立即做完整检查。若某个单参数候选值使上下限相互冲突，
% 该候选点会在评价模块中被标记为无效，而不会继续分配大型矩阵。
if ~skipValidation
    validate_diffuser_config(updatedConfig);
end
end

function structure = set_nested_field_local(structure,pathParts,value)
% 递归写入 geometry.kb、aspectKa.alpha 等任意层级的标量字段。
fieldName = pathParts{1};
assert(isfield(structure,fieldName), '配置中不存在字段路径 %s。',fieldName);
if isscalar(pathParts)
    structure.(fieldName) = value;
else
    structure.(fieldName) = set_nested_field_local( ...
        structure.(fieldName),pathParts(2:end),value);
end
end
