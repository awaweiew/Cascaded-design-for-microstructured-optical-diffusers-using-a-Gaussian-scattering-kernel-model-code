function value = get_optimization_parameter_value(config, parameter)
%GET_OPTIMIZATION_PARAMETER_VALUE 从当前配置读取一个优化参数的实际值。

switch parameter.application
    case 'kaScale'
        value = config.optimization.currentKaScale;
    case 'direct'
        pathParts = strsplit(char(parameter.targetPath),'.');
        value = get_nested_field_local(config,pathParts);
    case 'arrayN'
        assert(config.geometry.Nx == config.geometry.Ny, ...
            'arrayN 参数要求 Nx 与 Ny 相等。');
        value = config.geometry.Nx;
    otherwise
        error('不支持的参数读取类型：%s。',parameter.application);
end
end

function value = get_nested_field_local(structure,pathParts)
fieldName = pathParts{1};
assert(isfield(structure,fieldName), '配置中不存在字段路径 %s。',fieldName);
if isscalar(pathParts)
    value = structure.(fieldName);
else
    value = get_nested_field_local(structure.(fieldName),pathParts(2:end));
end
end
