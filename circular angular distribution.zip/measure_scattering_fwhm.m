function metrics = measure_scattering_fwhm(config, angularDistribution)
%MEASURE_SCATTERING_FWHM 按初稿定义测量中心截线和径向平均 FWHM。
%
% 本函数对应模块七。它同时计算：
%   1. theta_y 最接近 0 时的完整 theta_x 截线 FWHM；
%   2. theta_x 最接近 0 时的完整 theta_y 截线 FWHM；
%   3. 最大完整内切圆内的径向平均 FWHM。
%
% 完整截线 FWHM 必须由实际峰值左右两侧的 0.5 交点共同确定，不能假定
% 峰值严格位于 0°，也不能简单使用右侧半高角乘 2。径向曲线只有
% r>=0，因此径向 FWHM 定义为半高半径的 2 倍。

theta = angularDistribution.thetaDegree(:);
if strcmp(angularDistribution.mode,'full')
    H = angularDistribution.normalized;
    assert(size(H,1) == numel(theta) && size(H,2) == numel(theta), ...
        '角分布矩阵尺寸必须与 theta 坐标长度一致。');
    [~,zeroIndex] = min(abs(theta));
    centerCutX = H(:,zeroIndex);
    centerCutY = H(zeroIndex,:).';
else
    H = [];
    centerCutX = angularDistribution.centerCutXNormalized;
    centerCutY = angularDistribution.centerCutYNormalized;
end

centerCutX = centerCutX/(max(centerCutX,[],'omitnan')+eps);
[leftHalfX,rightHalfX,fwhmCenterX] = find_level_width_local( ...
    theta,centerCutX,0.5);

centerCutY = centerCutY/(max(centerCutY,[],'omitnan')+eps);
[leftHalfY,rightHalfY,fwhmCenterY] = find_level_width_local( ...
    theta,centerCutY,0.5);

% 径向平均只统计角度正方形中的最大完整内切圆，避免大半径圆环只剩
% 四角样本而造成平均值失真。
if strcmp(angularDistribution.mode,'full')
    [thetaXGrid,thetaYGrid] = ndgrid(theta,theta);
    radiusGrid = sqrt(thetaXGrid.^2+thetaYGrid.^2);
    maximumCompleteRadius = min(abs([theta(1),theta(end)]));
    radialEdges = linspace( ...
        0,maximumCompleteRadius,config.measurement.radialBinCount+1);
    radialCenters = 0.5*(radialEdges(1:end-1)+radialEdges(2:end));
    radialProfile = nan(size(radialCenters));

    for binIndex = 1:numel(radialCenters)
        annulusMask = radiusGrid >= radialEdges(binIndex) & ...
            radiusGrid < radialEdges(binIndex+1);
        if any(annulusMask(:))
            radialProfile(binIndex) = mean(H(annulusMask),'omitnan');
        end
    end
    radialProfileNormalized = radialProfile/ ...
        (max(radialProfile,[],'omitnan')+eps);
    radialHalfRadius = find_outward_level_radius_local( ...
        radialCenters,radialProfileNormalized,0.5);
    fwhmRadial = 2*radialHalfRadius;
else
    radialCenters = nan(0,1);
    radialProfileNormalized = nan(0,1);
    radialHalfRadius = NaN;
    fwhmRadial = NaN;
end

switch config.target.metric
    case 'centerCutX'
        primaryFwhm = fwhmCenterX;
    case 'centerCutY'
        primaryFwhm = fwhmCenterY;
    case 'radialAverage'
        assert(strcmp(angularDistribution.mode,'full'), ...
            '径向平均作为主指标时必须构造完整二维角分布。');
        primaryFwhm = fwhmRadial;
    otherwise
        error('未知目标指标：%s。',config.target.metric);
end

metrics.primaryMetric = config.target.metric;
metrics.primaryFwhmDegree = primaryFwhm;
metrics.targetFwhmDegree = config.target.fwhmDegree;
metrics.absoluteErrorDegree = abs(primaryFwhm-config.target.fwhmDegree);
metrics.signedErrorDegree = primaryFwhm-config.target.fwhmDegree;
metrics.withinTolerance = isfinite(primaryFwhm) && ...
    metrics.absoluteErrorDegree <= config.target.angleToleranceDegree;

metrics.fwhmCenterXDegree = fwhmCenterX;
metrics.fwhmCenterYDegree = fwhmCenterY;
metrics.fwhmRadialDegree = fwhmRadial;
metrics.leftHalfXDegree = leftHalfX;
metrics.rightHalfXDegree = rightHalfX;
metrics.leftHalfYDegree = leftHalfY;
metrics.rightHalfYDegree = rightHalfY;
metrics.radialHalfRadiusDegree = radialHalfRadius;
metrics.anisotropyDegree = abs(fwhmCenterX-fwhmCenterY);

metrics.thetaDegree = theta;
metrics.centerCutXNormalized = centerCutX;
metrics.centerCutYNormalized = centerCutY;
metrics.radialRadiusDegree = radialCenters(:);
metrics.radialProfileNormalized = radialProfileNormalized(:);
end

function [leftCross,rightCross,fullWidth] = ...
        find_level_width_local(theta,intensityNormalized,level)
% 从曲线真实峰值向左右分别寻找给定强度交点，并进行线性插值。
theta = theta(:);
intensityNormalized = intensityNormalized(:);
valid = isfinite(theta) & isfinite(intensityNormalized);
theta = theta(valid);
intensityNormalized = intensityNormalized(valid);
leftCross = NaN;
rightCross = NaN;
fullWidth = NaN;
if isempty(theta)
    return;
end

[theta,order] = sort(theta);
intensityNormalized = intensityNormalized(order);
peakValue = max(intensityNormalized);
if ~isfinite(peakValue) || peakValue <= 0
    return;
end
intensityNormalized = intensityNormalized/peakValue;
[~,peakIndex] = max(intensityNormalized);

leftIndex = find(intensityNormalized(1:peakIndex) <= level,1,'last');
if ~isempty(leftIndex) && leftIndex < peakIndex
    leftCross = interpolate_level_local( ...
        theta(leftIndex),intensityNormalized(leftIndex), ...
        theta(leftIndex+1),intensityNormalized(leftIndex+1),level);
end

rightRelativeIndex = find( ...
    intensityNormalized(peakIndex:end) <= level,1,'first');
if ~isempty(rightRelativeIndex)
    rightIndex = peakIndex+rightRelativeIndex-1;
    if rightIndex > peakIndex
        rightCross = interpolate_level_local( ...
            theta(rightIndex-1),intensityNormalized(rightIndex-1), ...
            theta(rightIndex),intensityNormalized(rightIndex),level);
    end
end

if isfinite(leftCross) && isfinite(rightCross)
    fullWidth = rightCross-leftCross;
end
end

function radiusAtLevel = find_outward_level_radius_local( ...
        radius,intensityNormalized,level)
% 从径向曲线的实际峰值向半径增大方向寻找首次阈值交点。
radius = radius(:);
intensityNormalized = intensityNormalized(:);
valid = isfinite(radius) & isfinite(intensityNormalized);
radius = radius(valid);
intensityNormalized = intensityNormalized(valid);
radiusAtLevel = NaN;
if isempty(radius)
    return;
end

[radius,order] = sort(radius);
intensityNormalized = intensityNormalized(order);
peakValue = max(intensityNormalized);
if ~isfinite(peakValue) || peakValue <= 0
    return;
end
intensityNormalized = intensityNormalized/peakValue;
[~,peakIndex] = max(intensityNormalized);
relativeIndex = find(intensityNormalized(peakIndex:end) <= level,1,'first');
if isempty(relativeIndex)
    return;
end

index2 = peakIndex+relativeIndex-1;
if index2 <= peakIndex
    radiusAtLevel = radius(index2);
else
    index1 = index2-1;
    radiusAtLevel = interpolate_level_local( ...
        radius(index1),intensityNormalized(index1), ...
        radius(index2),intensityNormalized(index2),level);
end
end

function crossing = interpolate_level_local(x1,y1,x2,y2,level)
% 两个离散采样点之间用线性插值求 y=level 的交点。
if abs(y2-y1) < eps
    crossing = 0.5*(x1+x2);
else
    crossing = x1+(level-y1)*(x2-x1)/(y2-y1);
end
end
