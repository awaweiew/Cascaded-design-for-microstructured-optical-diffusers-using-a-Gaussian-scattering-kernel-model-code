%% 完整正向链路烟雾测试
% 使用较小阵列和较低分辨率检查模块四至模块八的接口与基本数值性质。
% 该测试不执行正式参数优化，也不代表 60 x 60、5000 x 5000 的设计结果。

clear;
clc;

config = create_diffuser_config();
config.geometry.Nx = 8;
config.geometry.Ny = 8;
config.numerical.resolutionX = 240;
config.numerical.resolutionY = 240;
config.numerical.searchResolutionX = 240;
config.numerical.searchResolutionY = 240;
config.angular.sampleCount = 101;
config.measurement.radialBinCount = 100;
config.numerical.returnCoverageMask = false;
validate_diffuser_config(config);

bank = build_common_random_bank(config);
options.resolutionX = 240;
options.resolutionY = 240;
options.retainLargeData = true;
options.failFast = true;
evaluation = evaluate_diffuser_candidate(config,bank,options);

assert(strcmp(evaluation.status,'valid'), '完整正向链路返回无效状态。');
assert(isfinite(evaluation.primaryFwhmDegree) && ...
       evaluation.primaryFwhmDegree > 0, '主 FWHM 无效。');
assert(evaluation.validKernelCount > 0, '未生成有效高斯核。');
assert(all(isfinite(evaluation.angularDistribution.normalized(:))), ...
    '二维归一化角分布包含 NaN 或 Inf。');
assert(abs(max(evaluation.angularDistribution.normalized(:))-1) < 1e-12, ...
    '二维角分布未正确执行峰值归一化。');

% 搜索阶段的 targetOnly 模式必须与完整二维混合的中心截线逐点一致。
targetOnlyAngular = assemble_gaussian_distribution( ...
    config,evaluation.kernelStats,'targetOnly');
targetOnlyMetrics = measure_scattering_fwhm(config,targetOnlyAngular);
assert(abs(targetOnlyMetrics.fwhmCenterXDegree- ...
           evaluation.metrics.fwhmCenterXDegree) < 1e-10, ...
    'targetOnly 与完整二维分布的 x 中心截线 FWHM 不一致。');
assert(abs(targetOnlyMetrics.fwhmCenterYDegree- ...
           evaluation.metrics.fwhmCenterYDegree) < 1e-10, ...
    'targetOnly 与完整二维分布的 y 中心截线 FWHM 不一致。');

fprintf('完整正向链路烟雾测试通过。\n');
fprintf('有效高斯核：%d，主 FWHM：%.6f deg。\n', ...
    evaluation.validKernelCount,evaluation.primaryFwhmDegree);
