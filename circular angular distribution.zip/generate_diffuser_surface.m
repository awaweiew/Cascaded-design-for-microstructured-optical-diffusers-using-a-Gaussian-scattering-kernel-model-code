function [surface, units] = generate_diffuser_surface(config, randomBank)
%GENERATE_DIFFUSER_SURFACE 由配置和公共随机样本生成连续散射片高度场。
%
% 本函数对应模块三：散射片表面生成。
%
% 计算逻辑与现有一阶段修正程序保持一致：
%   1. 将有效口径划分为 Nx x Ny 个规则单元；
%   2. 在各单元中心附近加入受限的位置扰动；
%   3. 通过公共均匀分位数和 Beta 逆变换生成 h、k_a；
%   4. 计算椭球半轴 a=k_a*h、b=k_b*a 以及旋转角；
%   5. 仅在椭球帽严格定义域内生成负高度凹坑；
%   6. 首次覆盖像素直接使用当前椭球帽高度；
%   7. 只有两个真实凹坑重叠时才执行数值稳定的 soft-min。
%
% 输入：
%   config     - 模型配置结构体。
%   randomBank - build_common_random_bank 生成的公共随机样本库。
%
% 输出：
%   surface - 连续表面结果：
%       .x, .y          一维空间坐标 [mm]
%       .Z              高度矩阵 [mm]，凹面为负，未覆盖平面为 0
%       .dx, .dy        网格间距 [mm]
%       .coveredMask    覆盖逻辑矩阵（可按配置选择不返回）
%       .coveredFraction口径内被至少一个椭球覆盖的面积比例
%   units   - 每个微结构的真实参数表，包含中心、h、k_a、a、b、旋转角。

validate_diffuser_config(config);
validate_bank_for_surface(randomBank, config);

%% ========================== 1. 建立空间网格 ==========================
Lx = config.geometry.Lx;
Ly = config.geometry.Ly;
Nx = config.geometry.Nx;
Ny = config.geometry.Ny;
resX = config.numerical.resolutionX;
resY = config.numerical.resolutionY;

x = linspace(0, Lx, resX);
y = linspace(0, Ly, resY);
dx = x(2) - x(1);
dy = y(2) - y(1);

% 不在此处长期保存完整 X、Y 网格，因为 5000 x 5000 双精度矩阵各约
% 占 200 MB。后续只在当前椭球的局部矩形范围内临时建立 Xloc、Yloc，
% 可显著降低峰值内存，同时不会改变任何几何计算公式。
Z = zeros(resY, resX);
coveredMask = false(resY, resX);

%% ====================== 2. 规则单元和扰动尺度 ======================
periodX = Lx / Nx;
periodY = Ly / Ny;
centerXBase = linspace(periodX/2, Lx-periodX/2, Nx);
centerYBase = linspace(periodY/2, Ly-periodY/2, Ny);

jitterFraction = config.geometry.positionJitterFraction;
maximumJitterX = (periodX/2) * jitterFraction;
maximumJitterY = (periodY/2) * jitterFraction;

unitCount = Nx * Ny;

% 预分配数值数组，避免在循环内反复扩展内存。
centerX = zeros(unitCount, 1);
centerY = zeros(unitCount, 1);
height = zeros(unitCount, 1);
ka = zeros(unitCount, 1);
semiMajorA = zeros(unitCount, 1);
semiMinorB = zeros(unitCount, 1);
rotation = zeros(unitCount, 1);

%% ======================= 3. Beta 分位数反变换 =======================
% betaincinv(u,a,b) 给出正则化不完全 Beta 函数的逆，与 Beta 分布的
% 分位数函数等价。使用它可以不依赖 betarnd，并允许同一组 u 在改变
% alpha、beta 后保持分位身份不变。
heightNormalized = betaincinv( ...
    randomBank.heightQuantile, config.height.alpha, config.height.beta);
kaNormalized = betaincinv( ...
    randomBank.kaQuantile, config.aspectKa.alpha, config.aspectKa.beta);

height(:) = config.height.minimum + ...
    (config.height.maximum-config.height.minimum) .* heightNormalized;
ka(:) = config.aspectKa.minimum + ...
    (config.aspectKa.maximum-config.aspectKa.minimum) .* kaNormalized;

semiMajorA(:) = ka .* height;
semiMinorB(:) = config.geometry.kb .* semiMajorA;
rotation(:) = config.geometry.rotationRange .* randomBank.rotationQuantile;

%% ==================== 4. 逐微结构生成并融合表面 ====================
softMinK = config.numerical.softMinK;
unitIndex = 0;

% 循环顺序与原程序一致：外层遍历 x 方向单元，内层遍历 y 方向单元。
% randomBank 中第 p 个样本与此处第 p 个微结构一一对应。
for indexX = 1:Nx
    for indexY = 1:Ny
        unitIndex = unitIndex + 1;

        % ---------- 4.1 在规则中心上加入双向均匀位置扰动 ----------
        cx = centerXBase(indexX) + ...
            (2*randomBank.positionXQuantile(unitIndex)-1) * maximumJitterX;
        cy = centerYBase(indexY) + ...
            (2*randomBank.positionYQuantile(unitIndex)-1) * maximumJitterY;

        % 即使用户未来将扰动比例设置到边界，也将中心限制在最外层单元
        % 中心范围内，保持与原程序相同的口径边界保护逻辑。
        cx = min(max(cx, periodX/2), Lx-periodX/2);
        cy = min(max(cy, periodY/2), Ly-periodY/2);

        centerX(unitIndex) = cx;
        centerY(unitIndex) = cy;

        currentHeight = height(unitIndex);
        currentA = semiMajorA(unitIndex);
        currentB = semiMinorB(unitIndex);
        currentRotation = rotation(unitIndex);

        % ---------- 4.2 确定当前椭球对应的局部计算范围 ----------
        maximumRadius = max(currentA, currentB);
        xIndices = find(x >= cx-maximumRadius & x <= cx+maximumRadius);
        yIndices = find(y >= cy-maximumRadius & y <= cy+maximumRadius);

        if isempty(xIndices) || isempty(yIndices)
            % 正常配置下不会进入此分支；保留它是为了防止极端人工参数
            % 导致局部区域完全落在离散网格之外。
            continue;
        end

        [Xlocal, Ylocal] = meshgrid(x(xIndices), y(yIndices));

        % ---------- 4.3 生成当前旋转椭球帽的严格定义域 ----------
        [positiveCap, insideCap] = ellipsoid_cap_positive( ...
            Xlocal, Ylocal, cx, cy, currentA, currentB, ...
            currentHeight, currentRotation);
        negativeCap = -positiveCap;

        % ---------- 4.4 只在真实覆盖和真实重叠区域融合 ----------
        oldLocalSurface = Z(yIndices, xIndices);
        oldLocalCoverage = coveredMask(yIndices, xIndices);
        newLocalSurface = oldLocalSurface;

        firstCoverage = insideCap & ~oldLocalCoverage;
        overlapCoverage = insideCap & oldLocalCoverage;

        % 首次覆盖不与 Z=0 做 soft-min，避免产生 -log(2)/k 的伪偏移。
        newLocalSurface(firstCoverage) = negativeCap(firstCoverage);

        % 只有已经被旧椭球覆盖且也位于新椭球内部的像素，才是真实重叠。
        if any(overlapCoverage(:))
            newLocalSurface(overlapCoverage) = stable_softmin_two( ...
                oldLocalSurface(overlapCoverage), ...
                negativeCap(overlapCoverage), softMinK);
        end

        Z(yIndices, xIndices) = newLocalSurface;
        coveredMask(yIndices, xIndices) = oldLocalCoverage | insideCap;
    end
end

%% ========================== 5. 整理输出 ==========================
surface.x = x;
surface.y = y;
surface.Z = Z;
surface.dx = dx;
surface.dy = dy;
surface.sizeX = Lx;
surface.sizeY = Ly;
surface.resolutionX = resX;
surface.resolutionY = resY;
surface.coveredFraction = nnz(coveredMask) / numel(coveredMask);
surface.minimumHeight = min(Z(:));
surface.maximumHeight = max(Z(:));

if config.numerical.returnCoverageMask
    surface.coveredMask = coveredMask;
else
    surface.coveredMask = [];
end

% 使用 table 便于后续按列统计、保存 CSV 或人工检查。每一行对应一个
% 真实微结构，顺序与公共随机样本库完全一致。
unitId = (1:unitCount).';
% 循环中 indexY 变化最快，因此显式构造与循环顺序一致的网格编号。
gridIndexX = repelem((1:Nx).', Ny, 1);
gridIndexY = repmat((1:Ny).', Nx, 1);
units = table( ...
    unitId, gridIndexX(:), gridIndexY(:), centerX, centerY, ...
    height, ka, semiMajorA, semiMinorB, rotation, ...
    'VariableNames', { ...
    'unitId', 'gridIndexX', 'gridIndexY', 'centerX_mm', 'centerY_mm', ...
    'height_mm', 'ka', 'semiMajorA_mm', 'semiMinorB_mm', 'rotation_rad'});
end

function result = stable_softmin_two(firstSurface, secondSurface, k)
% 计算两个高度值的数值稳定 soft-min：
% softmin(A,B) = -log(exp(-kA)+exp(-kB))/k。
%
% 直接计算指数可能在深凹坑或大 k 下溢出/上溢出，因此先减去两项指数
% 中的较大值，再执行 log-sum-exp。此形式与原程序使用的公式一致。
maximumExponent = max(-k.*firstSurface, -k.*secondSurface);
result = -(maximumExponent + log( ...
    exp(-k.*firstSurface-maximumExponent) + ...
    exp(-k.*secondSurface-maximumExponent))) ./ k;
end

function validate_bank_for_surface(randomBank, config)
% 在大型矩阵分配前确认随机样本库与当前阵列规模相匹配。
expectedCount = config.geometry.Nx * config.geometry.Ny;
requiredFields = { ...
    'positionXQuantile', 'positionYQuantile', 'heightQuantile', ...
    'kaQuantile', 'rotationQuantile', 'unitCount'};

for index = 1:numel(requiredFields)
    assert(isfield(randomBank, requiredFields{index}), ...
        '公共随机样本库缺少字段 %s。', requiredFields{index});
end

assert(randomBank.unitCount == expectedCount, ...
    '随机样本库包含 %d 个单元，但当前配置需要 %d 个单元。', ...
    randomBank.unitCount, expectedCount);

quantileFields = requiredFields(1:5);
for index = 1:numel(quantileFields)
    values = randomBank.(quantileFields{index});
    assert(iscolumn(values) && numel(values) == expectedCount, ...
        '随机样本字段 %s 的尺寸与当前阵列不匹配。', quantileFields{index});
    assert(all(isfinite(values)) && all(values >= 0) && all(values <= 1), ...
        '随机样本字段 %s 必须全部为 [0,1] 内有限数。', quantileFields{index});
end
end
