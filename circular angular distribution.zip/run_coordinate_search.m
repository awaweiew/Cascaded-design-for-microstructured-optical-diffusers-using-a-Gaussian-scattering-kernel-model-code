function searchResult = run_coordinate_search( ...
        initialConfig,randomBank,outputDirectory)
%RUN_COORDINATE_SEARCH 按人工给定顺序执行多轮单参数坐标优化。
%
% 本函数对应模块十。enabled=true 的参数按照 config.optimization.parameters
% 中的顺序逐一进入 optimize_one_parameter；当前参数确定后立即固定其
% 最优值，再进入下一个参数。全部参数完成一次称为一轮 sweep。
%
% 输入：
%   initialConfig   - 初始配置；
%   randomBank      - 公共随机样本库；
%   outputDirectory - 检查点保存目录；传入空字符可关闭检查点。
%
% 输出：
%   searchResult    - 最终配置、全部评价历史、每参数停止原因和搜索摘要。

if nargin < 3
    outputDirectory = '';
end
validate_diffuser_config(initialConfig);

parameterList = initialConfig.optimization.parameters;
enabledMask = [parameterList.enabled];
enabledParameters = parameterList(enabledMask);
assert(~isempty(enabledParameters), '至少需要启用一个待优化参数。');

% 在正式搜索前，将所有启用参数写到用户指定的 initialValue。
currentConfig = initialConfig;
for parameterIndex = 1:numel(enabledParameters)
    currentConfig = apply_optimization_parameter( ...
        currentConfig,enabledParameters(parameterIndex), ...
        enabledParameters(parameterIndex).initialValue,true);
end
% 所有初始值统一写入后再检查，避免同时移动高度上下限时出现无意义的
% 中间状态冲突。
validate_diffuser_config(currentConfig);

evaluationOptions.resolutionX = currentConfig.numerical.searchResolutionX;
evaluationOptions.resolutionY = currentConfig.numerical.searchResolutionY;
evaluationOptions.retainLargeData = false;
evaluationOptions.failFast = currentConfig.optimization.failFast;
if currentConfig.optimization.useTargetOnlyAngularDuringSearch && ...
        ~strcmp(currentConfig.target.metric,'radialAverage')
    evaluationOptions.angularMode = 'targetOnly';
else
    evaluationOptions.angularMode = 'full';
end

evaluationCache = containers.Map('KeyType','char','ValueType','any');
allHistory = repmat(empty_history_record_local(),0,1);
parameterResults = repmat(empty_parameter_result_local(),0,1);

% 先记录初始方案，作为整轮改善量的基准。
baselineEvaluation = evaluate_diffuser_candidate( ...
    currentConfig,randomBank,evaluationOptions);
allHistory(end+1,1) = evaluation_to_history_local( ...
    baselineEvaluation,0,'baseline',NaN,'baseline');
previousSweepObjective = baselineEvaluation.objectiveDegree;

fprintf('\n[开始坐标优化]\n');
fprintf('初始主 FWHM = %.6f deg，目标误差 = %.6f deg。\n', ...
    baselineEvaluation.primaryFwhmDegree,baselineEvaluation.objectiveDegree);

completedSweeps = 0;
globalStopReason = 'maximum_sweeps_reached';

for sweepIndex = 1:currentConfig.optimization.maximumSweeps
    fprintf('\n--- 第 %d 轮参数优化 ---\n',sweepIndex);

    for parameterIndex = 1:numel(enabledParameters)
        parameter = enabledParameters(parameterIndex);
        fprintf('\n优化参数 %s，当前值 %.9g。\n', ...
            parameter.name,get_optimization_parameter_value(currentConfig,parameter));

        [currentConfig,oneResult] = optimize_one_parameter( ...
            currentConfig,randomBank,parameter,evaluationOptions,evaluationCache);

        compactParameterResult = empty_parameter_result_local();
        compactParameterResult.sweep = sweepIndex;
        compactParameterResult.parameterName = oneResult.parameterName;
        compactParameterResult.initialValue = oneResult.initialValue;
        compactParameterResult.bestValue = oneResult.bestValue;
        compactParameterResult.bestObjectiveDegree = oneResult.bestObjectiveDegree;
        compactParameterResult.bestFwhmDegree = oneResult.bestFwhmDegree;
        compactParameterResult.stopReason = oneResult.stopReason;
        compactParameterResult.evaluationCount = oneResult.evaluationCount;
        parameterResults(end+1,1) = compactParameterResult; %#ok<AGROW>

        for recordIndex = 1:numel(oneResult.evaluations)
            record = oneResult.evaluations(recordIndex);
            historyRecord = empty_history_record_local();
            historyRecord.sweep = sweepIndex;
            historyRecord.parameterName = oneResult.parameterName;
            historyRecord.parameterValue = record.parameterValue;
            historyRecord.phase = record.phase;
            historyRecord.status = record.status;
            historyRecord.primaryFwhmDegree = record.primaryFwhmDegree;
            historyRecord.objectiveDegree = record.objectiveDegree;
            historyRecord.signedErrorDegree = record.signedErrorDegree;
            historyRecord.fwhmCenterXDegree = record.fwhmCenterXDegree;
            historyRecord.fwhmCenterYDegree = record.fwhmCenterYDegree;
            historyRecord.fwhmRadialDegree = record.fwhmRadialDegree;
            historyRecord.anisotropyDegree = record.anisotropyDegree;
            historyRecord.withinTolerance = record.withinTolerance;
            historyRecord.validKernelCount = record.validKernelCount;
            historyRecord.skippedKernelCount = record.skippedKernelCount;
            historyRecord.elapsedSecond = record.elapsedSecond;
            historyRecord.fromCache = record.fromCache;
            historyRecord.errorMessage = record.errorMessage;
            allHistory(end+1,1) = historyRecord; %#ok<AGROW>
        end

        fprintf('参数 %s 最优值 %.9g，FWHM %.6f deg，停止原因：%s。\n', ...
            oneResult.parameterName,oneResult.bestValue, ...
            oneResult.bestFwhmDegree,oneResult.stopReason);

        save_checkpoint_local(outputDirectory,currentConfig, ...
            allHistory,parameterResults,sweepIndex,parameterIndex);
    end

    completedSweeps = sweepIndex;
    sweepEvaluation = evaluate_diffuser_candidate( ...
        currentConfig,randomBank,evaluationOptions);
    summaryHistory = evaluation_to_history_local( ...
        sweepEvaluation,sweepIndex,'sweep_summary',NaN,'sweep_summary');
    allHistory(end+1,1) = summaryHistory; %#ok<AGROW>

    sweepImprovement = previousSweepObjective-sweepEvaluation.objectiveDegree;
    fprintf('\n第 %d 轮结束：FWHM %.6f deg，误差 %.6f deg，本轮改善 %.6f deg。\n', ...
        sweepIndex,sweepEvaluation.primaryFwhmDegree, ...
        sweepEvaluation.objectiveDegree,sweepImprovement);

    if sweepEvaluation.withinTolerance
        % 即使已经进入角度容差，本轮中所有启用参数也已经依次访问完毕。
        globalStopReason = 'target_tolerance_reached_after_complete_sweep';
        break;
    end
    if sweepIndex > 1 && ...
       sweepImprovement < currentConfig.optimization.minimumSweepImprovementDegree
        globalStopReason = 'minimum_sweep_improvement_reached';
        break;
    end
    previousSweepObjective = sweepEvaluation.objectiveDegree;
end

finalSearchEvaluation = evaluate_diffuser_candidate( ...
    currentConfig,randomBank,evaluationOptions);

searchResult.initialConfig = initialConfig;
searchResult.bestConfig = currentConfig;
searchResult.baselineEvaluation = baselineEvaluation;
searchResult.finalSearchEvaluation = finalSearchEvaluation;
searchResult.history = struct2table(allHistory);
searchResult.parameterResults = struct2table(parameterResults);
searchResult.completedSweeps = completedSweeps;
searchResult.stopReason = globalStopReason;
searchResult.cacheEntryCount = evaluationCache.Count;
end

function history = evaluation_to_history_local( ...
        evaluation,sweep,parameterName,parameterValue,phase)
history = empty_history_record_local();
history.sweep = sweep;
history.parameterName = parameterName;
history.parameterValue = parameterValue;
history.phase = phase;
history.status = evaluation.status;
history.primaryFwhmDegree = evaluation.primaryFwhmDegree;
history.objectiveDegree = evaluation.objectiveDegree;
history.signedErrorDegree = evaluation.signedErrorDegree;
history.fwhmCenterXDegree = evaluation.fwhmCenterXDegree;
history.fwhmCenterYDegree = evaluation.fwhmCenterYDegree;
history.fwhmRadialDegree = evaluation.fwhmRadialDegree;
history.anisotropyDegree = evaluation.anisotropyDegree;
history.withinTolerance = evaluation.withinTolerance;
history.validKernelCount = evaluation.validKernelCount;
history.skippedKernelCount = evaluation.skippedKernelCount;
history.elapsedSecond = evaluation.elapsedSecond;
history.fromCache = evaluation.fromCache;
history.errorMessage = evaluation.errorMessage;
end

function save_checkpoint_local(outputDirectory,currentConfig, ...
        allHistory,parameterResults,sweepIndex,parameterIndex)
if isempty(outputDirectory)
    return;
end
if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end
checkpointFile = fullfile(outputDirectory,'optimization_checkpoint.mat');
historyTable = struct2table(allHistory);
parameterResultTable = struct2table(parameterResults);
save(checkpointFile,'currentConfig','historyTable','parameterResultTable', ...
    'sweepIndex','parameterIndex','-v7.3');
end

function record = empty_history_record_local()
record = struct( ...
    'sweep',0,'parameterName','','parameterValue',NaN,'phase','', ...
    'status','invalid','primaryFwhmDegree',NaN,'objectiveDegree',Inf, ...
    'signedErrorDegree',NaN,'fwhmCenterXDegree',NaN, ...
    'fwhmCenterYDegree',NaN,'fwhmRadialDegree',NaN, ...
    'anisotropyDegree',NaN,'withinTolerance',false, ...
    'validKernelCount',0,'skippedKernelCount',0, ...
    'elapsedSecond',NaN,'fromCache',false,'errorMessage','');
end

function result = empty_parameter_result_local()
result = struct( ...
    'sweep',0,'parameterName','','initialValue',NaN,'bestValue',NaN, ...
    'bestObjectiveDegree',Inf,'bestFwhmDegree',NaN, ...
    'stopReason','','evaluationCount',0);
end
