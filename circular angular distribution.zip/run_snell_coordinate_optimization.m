function result = run_snell_coordinate_optimization(userControl)
%RUN_SNELL_COORDINATE_OPTIMIZATION 基于完整 Snell 光线追迹继续优化 k_a 尺度。
%
% 本函数直接读取高斯核坐标优化保存的 best_config.json，并以其中的
% 最佳结构为起点，只继续改变宽深比整体缩放系数 kaScale。每个候选
% 结构均重新生成连续高度场，随后用完整两界面矢量 Snell 定律逐光线
% 计算出射角，不构造或叠加任何高斯散射核。
%
% 默认调用：
%   result = run_snell_coordinate_optimization();
%
% 调整光线数和分块大小：
%   options.rayCount = 1e7;
%   options.rayChunkSize = 2.5e5;
%   result = run_snell_coordinate_optimization(options);
%
% 主要设计原则：
%   1. 从 best_config 的 currentKaScale 出发；
%   2. 全部候选结构共用同一组几何随机分位数和同一组入射光线；
%   3. 左右探测搜索方向，随后进行粗步长遍历；
%   4. 跨越目标角后在括区间内用细步长搜索；
%   5. FWHM 评价定义、目标角和容差均从 best_config 读取；
%   6. 光线按块生成、追迹和累计，不在内存中保存全部 1e7 条光线。

if nargin < 1 || isempty(userControl)
    userControl = struct();
end

%% ========================= 1. 用户控制区 =========================
defaults.bestConfigJsonPath = [ ...
    'D:\课题\小论文\参考文献与初稿\8-18日初稿\高斯快速逼近代码\高斯核散射模型完整坐标优化程序\优化结果\20260904_142411\best_config.json'];

% 总光线数是可调变量。默认严格使用 1e7 条光线。
defaults.rayCount = 1e7;

% 每块只保留这些光线的坐标、坡度和方向。减小该值可进一步降低峰值
% 内存，但会增加循环次数；改变分块大小不会改变 random 模式的光线集。
defaults.rayChunkSize = 2.5e5;

% 'random'：固定随机种子的均匀空间采样，与常规蒙特卡洛追迹一致；
% 'r2'    ：确定性低差异 R2 序列，在相同光线数下通常具有更低统计噪声。
defaults.raySamplingMode = 'random';
defaults.rayRandomSeed = 104729;

% 留空时使用 best_config 中保存的表面网格。若内存允许，可人工改为
% 2000 或更高并进行分辨率收敛验证。
defaults.surfaceResolutionX = [];
defaults.surfaceResolutionY = [];

% 默认不平滑角度直方图，FWHM 完全来自原始光线计数。若 1e7 条光线
% 对单条中心截线仍有明显统计起伏，可设为 0.5~1.0 个角度箱；论文最终
% 结果应同时报告该设置，并用不同光线数检查收敛。
defaults.angularSmoothingSigmaBins = 0;

% 搜索参数留空时从 best_config 的 kaScale 配置读取。起点默认采用高斯
% 核优化所得 currentKaScale，而不是重新从 1.0 开始。
defaults.startScale = [];
defaults.scaleLowerBound = [];
defaults.scaleUpperBound = [];
defaults.coarseStep = [];
defaults.fineStep = [];
defaults.maximumEvaluations = [];
defaults.noImprovementPatience = [];

defaults.createFigures = true;
defaults.saveMatFile = true;
defaults.saveAngularCsv = true;
defaults.outputRootDirectory = '';

control = merge_control_local(defaults,userControl);
validate_control_local(control);

%% ================== 2. 读取最佳配置并准备依赖 ==================
assert(isfile(control.bestConfigJsonPath), ...
    '找不到 best_config.json：%s',control.bestConfigJsonPath);
bestConfig = jsondecode(fileread(control.bestConfigJsonPath));

resultDirectory = fileparts(control.bestConfigJsonPath);
optimizationResultRoot = fileparts(resultDirectory);
modelDirectory = fileparts(optimizationResultRoot);
addpath(modelDirectory);

requiredFunctions = { ...
    'validate_diffuser_config','build_common_random_bank', ...
    'generate_diffuser_surface','refract_vectors_snell', ...
    'measure_scattering_fwhm'};
for functionIndex = 1:numel(requiredFunctions)
    assert(exist(requiredFunctions{functionIndex},'file') == 2, ...
        '缺少依赖函数 %s.m；请将本文件放在完整坐标优化程序目录中运行。', ...
        requiredFunctions{functionIndex});
end

[baseKaMinimum,baseKaMaximum,savedScale,parameterDefaults] = ...
    read_ka_defaults_local(bestConfig);
control = fill_search_defaults_local(control,savedScale,parameterDefaults);

if isempty(control.surfaceResolutionX)
    control.surfaceResolutionX = bestConfig.numerical.resolutionX;
end
if isempty(control.surfaceResolutionY)
    control.surfaceResolutionY = bestConfig.numerical.resolutionY;
end

templateConfig = bestConfig;
templateConfig.numerical.resolutionX = control.surfaceResolutionX;
templateConfig.numerical.resolutionY = control.surfaceResolutionY;
templateConfig.numerical.returnCoverageMask = false;
templateConfig.optimization.baseAspectKaMinimum = baseKaMinimum;
templateConfig.optimization.baseAspectKaMaximum = baseKaMaximum;
validate_diffuser_config(templateConfig);

% 只生成一次几何公共随机分位数。改变 kaScale 时，每个微单元保持相同
% 的位置、凹深分位身份、k_a 分位身份和旋转角身份。
geometryRandomBank = build_common_random_bank(templateConfig);

if isempty(control.outputRootDirectory)
    control.outputRootDirectory = fullfile(modelDirectory,'Snell优化结果');
end
timeStamp = char(datetime('now','Format','yyyyMMdd_HHmmss'));
outputDirectory = fullfile(control.outputRootDirectory,timeStamp);
if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end

fprintf('\n============================================================\n');
fprintf('Snell 光线追迹 kaScale 坐标优化\n');
fprintf('输入配置：%s\n',control.bestConfigJsonPath);
fprintf('起始 kaScale：%.9g\n',control.startScale);
fprintf('基础 k_a 范围：[%.9g, %.9g]\n',baseKaMinimum,baseKaMaximum);
fprintf('光线数：%.0f；分块：%.0f；采样：%s\n', ...
    control.rayCount,control.rayChunkSize,control.raySamplingMode);
fprintf('表面网格：%d x %d\n', ...
    control.surfaceResolutionX,control.surfaceResolutionY);
fprintf('目标：%s FWHM = %.6f +/- %.6f deg\n', ...
    bestConfig.target.metric,bestConfig.target.fwhmDegree, ...
    bestConfig.target.angleToleranceDegree);
fprintf('输出目录：%s\n',outputDirectory);
fprintf('============================================================\n');

context.templateConfig = templateConfig;
context.geometryRandomBank = geometryRandomBank;
context.baseKaMinimum = baseKaMinimum;
context.baseKaMaximum = baseKaMaximum;
context.control = control;

%% ========================= 3. 坐标搜索 =========================
searchResult = search_scale_local(context);
bestScale = searchResult.bestScale;
bestEvaluation = searchResult.bestEvaluation;
bestSnellConfig = apply_scale_local( ...
    templateConfig,baseKaMinimum,baseKaMaximum,bestScale);

%% ========================= 4. 保存结果 =========================
historyTable = struct2table(searchResult.history,'AsArray',true);
writetable(historyTable,fullfile(outputDirectory,'snell_optimization_history.csv'));

summaryTable = table( ...
    control.startScale,bestScale, ...
    baseKaMinimum*bestScale,baseKaMaximum*bestScale, ...
    bestEvaluation.metrics.primaryFwhmDegree, ...
    bestEvaluation.metrics.absoluteErrorDegree, ...
    bestEvaluation.metrics.withinTolerance, ...
    string(searchResult.stopReason), ...
    'VariableNames',{ ...
    'startScale','bestScale','bestKaMinimum','bestKaMaximum', ...
    'primaryFwhmDegree','absoluteErrorDegree','withinTolerance','stopReason'});
writetable(summaryTable,fullfile(outputDirectory,'snell_parameter_summary.csv'));

write_json_local(fullfile(outputDirectory,'best_config_snell.json'),bestSnellConfig);

if control.saveAngularCsv
    writematrix(bestEvaluation.angularDistribution.normalized, ...
        fullfile(outputDirectory,'snell_final_angular_distribution_normalized.csv'));
end

if control.saveMatFile
    save(fullfile(outputDirectory,'complete_snell_optimization_result.mat'), ...
        'bestSnellConfig','bestEvaluation','searchResult','control', ...
        'outputDirectory','-v7.3');
end

if control.createFigures
    plot_results_local(bestEvaluation,searchResult,bestSnellConfig,outputDirectory);
end

result.bestConfig = bestSnellConfig;
result.bestEvaluation = bestEvaluation;
result.searchResult = searchResult;
result.control = control;
result.outputDirectory = outputDirectory;

fprintf('\nSnell 优化完成。\n');
fprintf('最佳 kaScale：%.9g\n',bestScale);
fprintf('最佳 k_a 范围：[%.9g, %.9g]\n', ...
    bestSnellConfig.aspectKa.minimum,bestSnellConfig.aspectKa.maximum);
fprintf('主 FWHM：%.6f deg\n',bestEvaluation.metrics.primaryFwhmDegree);
fprintf('目标绝对误差：%.6f deg\n',bestEvaluation.metrics.absoluteErrorDegree);
fprintf('停止原因：%s\n',searchResult.stopReason);
fprintf('结果目录：%s\n',outputDirectory);
end

%% ========================================================================
function searchResult = search_scale_local(context)
% 与高斯核阶段相同的单参数坐标搜索，只把候选评价替换为 Snell 光线追迹。
control = context.control;
history = repmat(empty_record_local(),0,1);
evaluationCache = containers.Map('KeyType','char','ValueType','any');
stopReason = 'maximum_evaluations';

currentRecord = evaluate_at_local(control.startScale,'initial');
bestRecord = currentRecord;
bestEvaluation = get_cached_evaluation_local(control.startScale);

if currentRecord.withinTolerance
    stopReason = 'target_tolerance_reached_at_initial_value';
    finish_local();
    return;
end

% ------------------------- 左右方向探测 -------------------------
probeValues = [ ...
    control.startScale-control.coarseStep, ...
    control.startScale+control.coarseStep];
probeValues = probeValues( ...
    probeValues >= control.scaleLowerBound-10*eps & ...
    probeValues <= control.scaleUpperBound+10*eps);

probeRecords = repmat(empty_record_local(),0,1);
bracketFound = false;
bracketFirst = empty_record_local();
bracketSecond = empty_record_local();

for probeIndex = 1:numel(probeValues)
    if numel(history) >= control.maximumEvaluations
        break;
    end
    probeRecord = evaluate_at_local(probeValues(probeIndex),'direction_probe');
    probeRecords(end+1,1) = probeRecord; %#ok<AGROW>
    update_best_local(probeRecord);

    if probeRecord.withinTolerance
        stopReason = 'target_tolerance_reached_during_direction_probe';
        finish_local();
        return;
    end
    if crosses_target_local(currentRecord,probeRecord)
        bracketFound = true;
        bracketFirst = currentRecord;
        bracketSecond = probeRecord;
        break;
    end
end

if bracketFound
    refine_bracket_local(bracketFirst,bracketSecond);
    if bestRecord.withinTolerance
        stopReason = 'target_tolerance_reached_during_refinement';
    else
        stopReason = 'target_bracket_refined_to_parameter_resolution';
    end
    finish_local();
    return;
end

if isempty(probeRecords)
    stopReason = 'initial_value_is_at_both_boundaries';
    finish_local();
    return;
end

[bestProbeObjective,bestProbeIndex] = min([probeRecords.objectiveDegree]);
if ~(bestProbeObjective < currentRecord.objectiveDegree)
    stopReason = 'no_improving_search_direction';
    finish_local();
    return;
end

selectedProbe = probeRecords(bestProbeIndex);
searchDirection = sign(selectedProbe.scale-currentRecord.scale);
previousRecord = selectedProbe;
noImprovementCount = 0;

% ------------------------- 粗步长单向遍历 -------------------------
while numel(history) < control.maximumEvaluations
    nextScale = previousRecord.scale+searchDirection*control.coarseStep;
    if nextScale < control.scaleLowerBound-10*eps || ...
       nextScale > control.scaleUpperBound+10*eps
        stopReason = 'parameter_boundary_reached';
        break;
    end

    nextRecord = evaluate_at_local(nextScale,'coarse_traversal');
    oldBestObjective = bestRecord.objectiveDegree;
    update_best_local(nextRecord);

    if nextRecord.withinTolerance
        stopReason = 'target_tolerance_reached_during_coarse_traversal';
        break;
    end

    if crosses_target_local(previousRecord,nextRecord)
        refine_bracket_local(previousRecord,nextRecord);
        if bestRecord.withinTolerance
            stopReason = 'target_tolerance_reached_during_refinement';
        else
            stopReason = 'target_bracket_refined_to_parameter_resolution';
        end
        break;
    end

    if bestRecord.objectiveDegree < oldBestObjective
        noImprovementCount = 0;
    else
        noImprovementCount = noImprovementCount+1;
    end
    if noImprovementCount >= control.noImprovementPatience
        stopReason = 'no_improvement_patience_reached';
        break;
    end
    previousRecord = nextRecord;
end

finish_local();

    function record = evaluate_at_local(scale,phase)
        scale = min(max(scale,control.scaleLowerBound),control.scaleUpperBound);
        key = scale_key_local(scale);
        fromCache = isKey(evaluationCache,key);
        if fromCache
            evaluation = evaluationCache(key);
        else
            try
                evaluation = evaluate_scale_snell_local(context,scale);
            catch exception
                evaluation = invalid_evaluation_local(exception.message);
            end
            evaluationCache(key) = evaluation;
        end
        record = record_from_evaluation_local(evaluation,scale,phase,fromCache);
        history(end+1,1) = record;

        fprintf(['[%02d] %-18s scale=%9.6f, FWHM=%10.6f deg, ', ...
            '|error|=%9.6f deg, valid rays=%d, time=%.2f s%s\n'], ...
            numel(history),phase,scale,record.primaryFwhmDegree, ...
            record.objectiveDegree,record.validRayCount, ...
            record.elapsedSecond,ternary_local(fromCache,' [cache]',''));
    end

    function evaluation = get_cached_evaluation_local(scale)
        evaluation = evaluationCache(scale_key_local(scale));
    end

    function update_best_local(candidateRecord)
        if candidateRecord.objectiveDegree < bestRecord.objectiveDegree
            bestRecord = candidateRecord;
            bestEvaluation = get_cached_evaluation_local(candidateRecord.scale);
        end
    end

    function refine_bracket_local(firstRecord,secondRecord)
        lowerScale = min(firstRecord.scale,secondRecord.scale);
        upperScale = max(firstRecord.scale,secondRecord.scale);
        fineScales = (lowerScale+control.fineStep): ...
            control.fineStep:(upperScale-control.fineStep);
        if isempty(fineScales) && upperScale-lowerScale > 10*eps
            fineScales = 0.5*(lowerScale+upperScale);
        end

        for fineIndex = 1:numel(fineScales)
            if numel(history) >= control.maximumEvaluations
                return;
            end
            fineRecord = evaluate_at_local(fineScales(fineIndex),'fine_refinement');
            update_best_local(fineRecord);
            if fineRecord.withinTolerance
                return;
            end
        end
    end

    function finish_local()
        searchResult.bestScale = bestRecord.scale;
        searchResult.bestEvaluation = bestEvaluation;
        searchResult.bestRecord = bestRecord;
        searchResult.history = history;
        searchResult.stopReason = stopReason;
        searchResult.evaluationCount = numel(history);
    end
end

%% ========================================================================
function evaluation = evaluate_scale_snell_local(context,scale)
% 生成一个候选表面，并用分块光线追迹得到完整二维出射角分布。
startTime = tic;
control = context.control;
config = apply_scale_local( ...
    context.templateConfig,context.baseKaMinimum,context.baseKaMaximum,scale);

surface = generate_diffuser_surface(config,context.geometryRandomBank);
[slopeXGrid,slopeYGrid] = gradient(surface.Z,surface.dx,surface.dy);
normalGridLength = sqrt(1+slopeXGrid.^2+slopeYGrid.^2);
normalXGrid = slopeXGrid./normalGridLength;
normalYGrid = slopeYGrid./normalGridLength;
normalZGrid = -1./normalGridLength;
clear slopeXGrid slopeYGrid normalGridLength;

theta = linspace( ...
    config.angular.minimumDegree,config.angular.maximumDegree, ...
    config.angular.sampleCount).';
dTheta = theta(2)-theta(1);
angleEdges = [ ...
    theta(1)-0.5*dTheta; ...
    0.5*(theta(1:end-1)+theta(2:end)); ...
    theta(end)+0.5*dTheta];

angularCounts = zeros(numel(theta),numel(theta));
processedRayCount = 0;
validSnellRayCount = 0;
inAngularRangeRayCount = 0;

if strcmp(control.raySamplingMode,'random')
    rayStream = RandStream('mt19937ar','Seed',control.rayRandomSeed);
else
    rayStream = [];
end

while processedRayCount < control.rayCount
    currentCount = min( ...
        control.rayChunkSize,control.rayCount-processedRayCount);
    firstRayIndex = processedRayCount+1;
    [rayX,rayY] = generate_ray_positions_local( ...
        control,rayStream,firstRayIndex,currentCount, ...
        config.geometry.Lx,config.geometry.Ly);

    [rayNormalX,rayNormalY,rayNormalZ] = bilinear_sample_normals_local( ...
        normalXGrid,normalYGrid,normalZGrid,rayX,rayY, ...
        config.geometry.Lx,config.geometry.Ly);

    [thetaX,thetaY,validSnell] = normal_to_output_angles_snell_local( ...
        rayNormalX,rayNormalY,rayNormalZ, ...
        config.optical.nAir,config.optical.nSubstrate);
    thetaX = thetaX(validSnell);
    thetaY = thetaY(validSnell);

    chunkCounts = histcounts2(thetaX,thetaY,angleEdges,angleEdges);
    angularCounts = angularCounts+chunkCounts;
    validSnellRayCount = validSnellRayCount+nnz(validSnell);
    inAngularRangeRayCount = inAngularRangeRayCount+sum(chunkCounts(:));
    processedRayCount = processedRayCount+currentCount;
end

if control.angularSmoothingSigmaBins > 0
    countsForMeasurement = gaussian_smooth_2d_local( ...
        angularCounts,control.angularSmoothingSigmaBins);
else
    countsForMeasurement = angularCounts;
end

assert(any(countsForMeasurement(:) > 0), ...
    '当前角度范围内没有有效出射光线。');

angularDistribution.mode = 'full';
angularDistribution.thetaDegree = theta;
angularDistribution.counts = angularCounts;
angularDistribution.normalized = countsForMeasurement/ ...
    (max(countsForMeasurement(:))+eps);
angularDistribution.angleSpacingDegree = dTheta;

metrics = measure_scattering_fwhm(config,angularDistribution);
if ~isfinite(metrics.primaryFwhmDegree)
    error('未能在当前角度范围和光线统计下获得有效的主 FWHM。');
end

evaluation.status = 'valid';
evaluation.scale = scale;
evaluation.config = config;
evaluation.metrics = metrics;
evaluation.angularDistribution = angularDistribution;
evaluation.objectiveDegree = metrics.absoluteErrorDegree;
evaluation.signedErrorDegree = metrics.signedErrorDegree;
evaluation.withinTolerance = metrics.withinTolerance;
evaluation.totalRayCount = control.rayCount;
evaluation.validSnellRayCount = validSnellRayCount;
evaluation.invalidSnellRayCount = control.rayCount-validSnellRayCount;
evaluation.inAngularRangeRayCount = inAngularRangeRayCount;
evaluation.outsideAngularRangeRayCount = ...
    validSnellRayCount-inAngularRangeRayCount;
evaluation.surfaceMinimumHeight_mm = surface.minimumHeight;
evaluation.surfaceMaximumHeight_mm = surface.maximumHeight;
evaluation.surfaceCoveredFraction = surface.coveredFraction;
evaluation.surfaceResolutionX = surface.resolutionX;
evaluation.surfaceResolutionY = surface.resolutionY;
evaluation.elapsedSecond = toc(startTime);
evaluation.errorMessage = '';
end

%% ========================================================================
function [rayX,rayY] = generate_ray_positions_local( ...
        control,rayStream,firstRayIndex,count,Lx,Ly)
switch control.raySamplingMode
    case 'random'
        % 用交错的一维序列生成 x/y，使光线集合不依赖 rayChunkSize。
        uv = rand(rayStream,2*count,1);
        rayX = Lx*uv(1:2:end);
        rayY = Ly*uv(2:2:end);

    case 'r2'
        % 二维 R2 低差异序列。它不需要保存全局样本，也严格可复现。
        rayIndex = (firstRayIndex:(firstRayIndex+count-1)).';
        plasticConstant = 1.32471795724474602596;
        alphaX = 1/plasticConstant;
        alphaY = 1/(plasticConstant^2);
        rayX = Lx*mod(0.5+rayIndex*alphaX,1);
        rayY = Ly*mod(0.5+rayIndex*alphaY,1);

    otherwise
        error('未知 raySamplingMode：%s。',control.raySamplingMode);
end
end

%% ========================================================================
function [sampleX,sampleY,sampleZ] = bilinear_sample_normals_local( ...
        normalX,normalY,normalZ,rayX,rayY,Lx,Ly)
% 在规则网格上插值单位法向，再重新单位化。该顺序与完整光线追迹基准
% 一致，并避免为每个光线块构造完整 X/Y 网格。
[resolutionY,resolutionX] = size(normalX);

coordinateX = (rayX/Lx)*(resolutionX-1);
coordinateY = (rayY/Ly)*(resolutionY-1);
indexX = floor(coordinateX)+1;
indexY = floor(coordinateY)+1;
weightX = coordinateX-floor(coordinateX);
weightY = coordinateY-floor(coordinateY);

indexX = min(max(indexX,1),resolutionX-1);
indexY = min(max(indexY,1),resolutionY-1);

index00 = indexY+(indexX-1)*resolutionY;
index10 = indexY+indexX*resolutionY;
index01 = indexY+1+(indexX-1)*resolutionY;
index11 = indexY+1+indexX*resolutionY;

sampleX = interpolate_field_local(normalX);
sampleY = interpolate_field_local(normalY);
sampleZ = interpolate_field_local(normalZ);
sampleLength = sqrt(sampleX.^2+sampleY.^2+sampleZ.^2);
sampleX = sampleX./sampleLength;
sampleY = sampleY./sampleLength;
sampleZ = sampleZ./sampleLength;

    function sample = interpolate_field_local(field)
        sample = (1-weightX).*(1-weightY).*field(index00)+ ...
                 weightX.*(1-weightY).*field(index10)+ ...
                 (1-weightX).*weightY.*field(index01)+ ...
                 weightX.*weightY.*field(index11);
    end
end

%% ========================================================================
function [thetaX,thetaY,valid] = normal_to_output_angles_snell_local( ...
        normalX,normalY,normalZ,refractiveIndexAir,refractiveIndexSubstrate)
% 对每条光线执行粗糙前表面和与光轴垂直的平整后表面两次精确折射。
rayCount = numel(normalX);
incidentDirection = zeros(rayCount,3);
incidentDirection(:,3) = -1;
roughNormal = [normalX(:),normalY(:),normalZ(:)];

insideDirection = refract_vectors_snell( ...
    incidentDirection,roughNormal,refractiveIndexAir,refractiveIndexSubstrate);
validFirst = all(isfinite(insideDirection),2);

finalDirection = nan(rayCount,3);
if any(validFirst)
    flatNormal = zeros(nnz(validFirst),3);
    flatNormal(:,3) = -1;
    finalDirection(validFirst,:) = refract_vectors_snell( ...
        insideDirection(validFirst,:),flatNormal, ...
        refractiveIndexSubstrate,refractiveIndexAir);
end

valid = all(isfinite(finalDirection),2);
thetaX = nan(rayCount,1);
thetaY = nan(rayCount,1);
thetaX(valid) = atan2d(finalDirection(valid,1),-finalDirection(valid,3));
thetaY(valid) = atan2d(finalDirection(valid,2),-finalDirection(valid,3));
end

%% ========================================================================
function smoothed = gaussian_smooth_2d_local(values,sigmaBins)
radius = max(1,ceil(4*sigmaBins));
coordinate = (-radius:radius).';
kernel = exp(-0.5*(coordinate/sigmaBins).^2);
kernel = kernel/sum(kernel);
smoothed = conv2(conv2(values,kernel,'same'),kernel.','same');
end

%% ========================================================================
function config = apply_scale_local(config,baseMinimum,baseMaximum,scale)
config.aspectKa.minimum = baseMinimum*scale;
config.aspectKa.maximum = baseMaximum*scale;
config.optimization.baseAspectKaMinimum = baseMinimum;
config.optimization.baseAspectKaMaximum = baseMaximum;
config.optimization.currentKaScale = scale;
validate_diffuser_config(config);
end

%% ========================================================================
function [baseMinimum,baseMaximum,currentScale,parameterDefaults] = ...
        read_ka_defaults_local(config)
assert(isfield(config,'optimization'), ...
    'best_config 缺少 optimization 字段。');

if isfield(config.optimization,'currentKaScale')
    currentScale = config.optimization.currentKaScale;
else
    currentScale = 1;
end

if isfield(config.optimization,'baseAspectKaMinimum') && ...
   isfield(config.optimization,'baseAspectKaMaximum')
    baseMinimum = config.optimization.baseAspectKaMinimum;
    baseMaximum = config.optimization.baseAspectKaMaximum;
else
    baseMinimum = config.aspectKa.minimum/currentScale;
    baseMaximum = config.aspectKa.maximum/currentScale;
end

parameters = config.optimization.parameters;
parameterNames = {parameters.name};
parameterIndex = find(strcmp(parameterNames,'kaScale'),1);
assert(~isempty(parameterIndex),'best_config 中没有 kaScale 参数定义。');
parameterDefaults = parameters(parameterIndex);
end

%% ========================================================================
function control = fill_search_defaults_local(control,savedScale,parameter)
if isempty(control.startScale)
    control.startScale = savedScale;
end
if isempty(control.scaleLowerBound)
    control.scaleLowerBound = parameter.lowerBound;
end
if isempty(control.scaleUpperBound)
    control.scaleUpperBound = parameter.upperBound;
end
if isempty(control.coarseStep)
    control.coarseStep = parameter.coarseStep;
end
if isempty(control.fineStep)
    control.fineStep = parameter.fineStep;
end
if isempty(control.maximumEvaluations)
    control.maximumEvaluations = 100;
end
if isempty(control.noImprovementPatience)
    control.noImprovementPatience = 5;
end

assert(control.startScale >= control.scaleLowerBound && ...
       control.startScale <= control.scaleUpperBound, ...
    '起始 kaScale 不在搜索边界内。');
assert(control.coarseStep > 0 && control.fineStep > 0, ...
    '粗、细搜索步长必须为正。');
end

%% ========================================================================
function control = merge_control_local(defaults,userControl)
control = defaults;
userFields = fieldnames(userControl);
defaultFields = fieldnames(defaults);
for fieldIndex = 1:numel(userFields)
    fieldName = userFields{fieldIndex};
    assert(any(strcmp(defaultFields,fieldName)), ...
        '未知控制字段：%s。',fieldName);
    control.(fieldName) = userControl.(fieldName);
end
end

%% ========================================================================
function validate_control_local(control)
assert(ischar(control.bestConfigJsonPath) || isstring(control.bestConfigJsonPath), ...
    'bestConfigJsonPath 必须为文本路径。');
assert(isscalar(control.rayCount) && isfinite(control.rayCount) && ...
       control.rayCount >= 1 && control.rayCount == floor(control.rayCount), ...
    'rayCount 必须为正整数。');
assert(isscalar(control.rayChunkSize) && isfinite(control.rayChunkSize) && ...
       control.rayChunkSize >= 1 && ...
       control.rayChunkSize == floor(control.rayChunkSize), ...
    'rayChunkSize 必须为正整数。');
assert(any(strcmp(control.raySamplingMode,{'random','r2'})), ...
    'raySamplingMode 只能为 random 或 r2。');
assert(isscalar(control.rayRandomSeed) && isfinite(control.rayRandomSeed) && ...
       control.rayRandomSeed >= 0 && control.rayRandomSeed == floor(control.rayRandomSeed), ...
    'rayRandomSeed 必须为非负整数。');
assert(isscalar(control.angularSmoothingSigmaBins) && ...
       isfinite(control.angularSmoothingSigmaBins) && ...
       control.angularSmoothingSigmaBins >= 0, ...
    'angularSmoothingSigmaBins 必须为非负有限标量。');
end

%% ========================================================================
function record = record_from_evaluation_local(evaluation,scale,phase,fromCache)
record = empty_record_local();
record.scale = scale;
record.phase = phase;
record.status = evaluation.status;
record.fromCache = fromCache;
record.errorMessage = evaluation.errorMessage;
record.elapsedSecond = evaluation.elapsedSecond;

if strcmp(evaluation.status,'valid')
    record.primaryMetric = evaluation.metrics.primaryMetric;
    record.primaryFwhmDegree = evaluation.metrics.primaryFwhmDegree;
    record.fwhmCenterXDegree = evaluation.metrics.fwhmCenterXDegree;
    record.fwhmCenterYDegree = evaluation.metrics.fwhmCenterYDegree;
    record.fwhmRadialDegree = evaluation.metrics.fwhmRadialDegree;
    record.anisotropyDegree = evaluation.metrics.anisotropyDegree;
    record.objectiveDegree = evaluation.metrics.absoluteErrorDegree;
    record.signedErrorDegree = evaluation.metrics.signedErrorDegree;
    record.withinTolerance = evaluation.metrics.withinTolerance;
    record.validRayCount = evaluation.validSnellRayCount;
    record.invalidSnellRayCount = evaluation.invalidSnellRayCount;
    record.outsideAngularRangeRayCount = evaluation.outsideAngularRangeRayCount;
else
    record.objectiveDegree = Inf;
end
end

%% ========================================================================
function record = empty_record_local()
record = struct( ...
    'scale',NaN,'phase','','status','invalid','primaryMetric','', ...
    'primaryFwhmDegree',NaN,'fwhmCenterXDegree',NaN, ...
    'fwhmCenterYDegree',NaN,'fwhmRadialDegree',NaN, ...
    'anisotropyDegree',NaN,'objectiveDegree',Inf, ...
    'signedErrorDegree',NaN,'withinTolerance',false, ...
    'validRayCount',0,'invalidSnellRayCount',0, ...
    'outsideAngularRangeRayCount',0,'elapsedSecond',NaN, ...
    'fromCache',false,'errorMessage','');
end

%% ========================================================================
function evaluation = invalid_evaluation_local(message)
evaluation.status = 'invalid';
evaluation.metrics = struct();
evaluation.objectiveDegree = Inf;
evaluation.signedErrorDegree = NaN;
evaluation.withinTolerance = false;
evaluation.validSnellRayCount = 0;
evaluation.invalidSnellRayCount = 0;
evaluation.outsideAngularRangeRayCount = 0;
evaluation.elapsedSecond = 0;
evaluation.errorMessage = message;
end

%% ========================================================================
function result = crosses_target_local(firstRecord,secondRecord)
result = isfinite(firstRecord.signedErrorDegree) && ...
         isfinite(secondRecord.signedErrorDegree) && ...
         firstRecord.signedErrorDegree*secondRecord.signedErrorDegree <= 0;
end

%% ========================================================================
function key = scale_key_local(scale)
key = sprintf('%.15g',scale);
end

%% ========================================================================
function output = ternary_local(condition,trueText,falseText)
if condition
    output = trueText;
else
    output = falseText;
end
end

%% ========================================================================
function write_json_local(pathName,structure)
try
    jsonText = jsonencode(structure,'PrettyPrint',true);
catch
    jsonText = jsonencode(structure);
end
fileId = fopen(pathName,'w','n','UTF-8');
assert(fileId >= 0,'无法创建 JSON 文件：%s',pathName);
cleanup = onCleanup(@() fclose(fileId));
fwrite(fileId,jsonText,'char');
end

%% ========================================================================
function plot_results_local(evaluation,searchResult,config,outputDirectory)
theta = evaluation.metrics.thetaDegree;
H = evaluation.angularDistribution.normalized;
metrics = evaluation.metrics;

angularFigure = figure('Color','w','Name','Snell 最终二维角分布');
imagesc(theta,theta,H.');
axis image;
set(gca,'YDir','normal');
xlabel('\theta_x (deg)');
ylabel('\theta_y (deg)');
title(sprintf('Snell ray tracing, %s FWHM = %.4f^\circ', ...
    metrics.primaryMetric,metrics.primaryFwhmDegree));
colorbar;
colormap turbo;
exportgraphics(angularFigure, ...
    fullfile(outputDirectory,'snell_final_angular_distribution.png'), ...
    'Resolution',180);

profileFigure = figure('Color','w','Name','Snell 最终 FWHM 曲线');
plot(theta,metrics.centerCutXNormalized,'LineWidth',2); hold on;
plot(theta,metrics.centerCutYNormalized,'--','LineWidth',2);
if ~isempty(metrics.radialRadiusDegree)
    plot(metrics.radialRadiusDegree,metrics.radialProfileNormalized, ...
        '-.','LineWidth',2);
end
yline(0.5,':','Half maximum','LineWidth',1.5);
grid on;
xlabel('Angle (deg)');
ylabel('Peak-normalized ray count');
legend( ...
    sprintf('x cut, FWHM %.4f^\circ',metrics.fwhmCenterXDegree), ...
    sprintf('y cut, FWHM %.4f^\circ',metrics.fwhmCenterYDegree), ...
    sprintf('radial, FWHM %.4f^\circ',metrics.fwhmRadialDegree), ...
    'Half maximum','Location','best');
title('Snell 出射角分布的中心截线与径向平均');
exportgraphics(profileFigure, ...
    fullfile(outputDirectory,'snell_final_fwhm_profiles.png'), ...
    'Resolution',180);

history = searchResult.history;
valid = strcmp({history.status},'valid');
validHistory = history(valid);
historyFigure = figure('Color','w','Name','Snell 坐标搜索历史');
tiledlayout(2,1);
nexttile;
plot(1:numel(validHistory),[validHistory.primaryFwhmDegree],'-o','LineWidth',1.6);
yline(config.target.fwhmDegree,'--','Target','LineWidth',1.4);
grid on;
ylabel('FWHM (deg)');
title('Snell 候选结构的主 FWHM');
nexttile;
semilogy(1:numel(validHistory), ...
    max([validHistory.objectiveDegree],eps),'-o','LineWidth',1.6);
yline(config.target.angleToleranceDegree,'--','Tolerance','LineWidth',1.4);
grid on;
xlabel('Valid evaluation index');
ylabel('|FWHM-target| (deg)');
exportgraphics(historyFigure, ...
    fullfile(outputDirectory,'snell_optimization_history.png'), ...
    'Resolution',180);
end
