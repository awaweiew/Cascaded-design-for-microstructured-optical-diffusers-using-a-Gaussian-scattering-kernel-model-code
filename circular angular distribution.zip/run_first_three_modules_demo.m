%% 前三个基础模块的运行入口
% 本脚本只完成：配置、公共随机样本、散射片连续表面生成。
% 它不会计算高斯核、Snell 出射角、FWHM，也不会执行参数优化。

clear;
clc;
close all;

%% ========================= 模块一：参数配置 =========================
config = create_diffuser_config();

% 快速检查时可暂时启用下面两行，例如先用 800 x 800 检查程序流程。
% 正式生成时请保持 create_diffuser_config 中的 5000 x 5000。
% config.numerical.resolutionX = 800;
% config.numerical.resolutionY = 800;

% 人工修改 config 后必须再次检查，防止上下限或数组尺寸不合法。
validate_diffuser_config(config);

%% ====================== 模块二：公共随机样本库 ======================
randomBank = build_common_random_bank(config);

%% ====================== 模块三：散射片表面生成 ======================
tic;
[surface, units] = generate_diffuser_surface(config, randomBank);
elapsedTime = toc;

fprintf('\n前三个基础模块运行完成。\n');
fprintf('微结构数量：%d\n', height(units));
fprintf('空间分辨率：%d x %d\n', ...
    surface.resolutionX, surface.resolutionY);
fprintf('最低表面高度：%.9f mm\n', surface.minimumHeight);
fprintf('表面覆盖比例：%.6f\n', surface.coveredFraction);
fprintf('表面生成耗时：%.3f s\n', elapsedTime);

%% ========================== 结果快速显示 ==========================
% 显示时降采样，不改变完整高度场本身。
plotStride = max(1, ceil(max( ...
    surface.resolutionX, surface.resolutionY)/800));
rows = 1:plotStride:surface.resolutionY;
columns = 1:plotStride:surface.resolutionX;

figure('Color', 'w', 'Name', '前三模块生成的 diffuser 表面');
surf( ...
    1e3*surface.x(columns), ...
    1e3*surface.y(rows), ...
    1e3*surface.Z(rows, columns), ...
    1e3*surface.Z(rows, columns), ...
    'EdgeColor', 'none');
axis equal tight;
xlabel('x (\mum)');
ylabel('y (\mum)');
zlabel('z (\mum)');
title('公共随机样本生成的随机凹面椭球 diffuser');
colormap turbo;
colorbar;
view(45, 45);
light;
lighting gouraud;

