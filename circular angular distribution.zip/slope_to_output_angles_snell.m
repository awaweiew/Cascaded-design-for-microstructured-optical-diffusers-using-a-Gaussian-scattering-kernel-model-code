function [thetaX, thetaY, valid] = slope_to_output_angles_snell( ...
        slopeX, slopeY, refractiveIndexAir, refractiveIndexSubstrate)
%SLOPE_TO_OUTPUT_ANGLES_SNELL 将表面坡度映射为空气侧最终出射角。
%
% 本函数执行与现有一阶段修正程序一致的完整两界面非线性传播：
%
%   平行入射空气光 [0,0,-1]
%       -> 粗糙空气/基底前表面
%       -> 基底内部方向
%       -> 平坦基底/空气后表面
%       -> 最终出射角 thetaX、thetaY。
%
% 对高度场 z=Z(x,y)，从空气指向基底的局部单位法向取：
%
%   n=[dZ/dx,dZ/dy,-1]/sqrt(1+(dZ/dx)^2+(dZ/dy)^2)。
%
% 因目标 FWHM 为 30°，不使用 theta=K*s 的小角度线性近似。

slopeX = slopeX(:);
slopeY = slopeY(:);
assert(numel(slopeX) == numel(slopeY), 'x、y 坡度样本数量必须一致。');

sampleCount = numel(slopeX);
thetaX = nan(sampleCount,1);
thetaY = nan(sampleCount,1);
valid = false(sampleCount,1);

finiteSlope = isfinite(slopeX) & isfinite(slopeY);
if ~any(finiteSlope)
    return;
end

sx = slopeX(finiteSlope);
sy = slopeY(finiteSlope);
normalLength = sqrt(1+sx.^2+sy.^2);
roughNormal = [sx./normalLength, sy./normalLength, -1./normalLength];
incidentDirection = repmat([0,0,-1], numel(sx), 1);

insideDirection = refract_vectors_snell( ...
    incidentDirection, roughNormal, refractiveIndexAir, refractiveIndexSubstrate);
validFirstInterface = all(isfinite(insideDirection),2);
if ~any(validFirstInterface)
    return;
end

finalDirection = nan(size(insideDirection));
flatNormal = repmat([0,0,-1], nnz(validFirstInterface), 1);
finalDirection(validFirstInterface,:) = refract_vectors_snell( ...
    insideDirection(validFirstInterface,:), flatNormal, ...
    refractiveIndexSubstrate, refractiveIndexAir);
validLocal = all(isfinite(finalDirection),2);

thetaXLocal = nan(size(sx));
thetaYLocal = nan(size(sy));
thetaXLocal(validLocal) = atan2d( ...
    finalDirection(validLocal,1), -finalDirection(validLocal,3));
thetaYLocal(validLocal) = atan2d( ...
    finalDirection(validLocal,2), -finalDirection(validLocal,3));

originalIndex = find(finiteSlope);
thetaX(originalIndex(validLocal)) = thetaXLocal(validLocal);
thetaY(originalIndex(validLocal)) = thetaYLocal(validLocal);
valid(originalIndex(validLocal)) = true;
end

