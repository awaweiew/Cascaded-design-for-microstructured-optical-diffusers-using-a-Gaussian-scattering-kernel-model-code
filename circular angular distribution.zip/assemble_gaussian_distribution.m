function angularDistribution = assemble_gaussian_distribution(config, kernelStats, mode)
%ASSEMBLE_GAUSSIAN_DISTRIBUTION 叠加全部有效微结构的二维高斯角分布。
%
% 本函数对应模块六。第 p 个微结构的角分布为单位积分二维高斯密度，
% 核中心和协方差来自非线性 Snell 角样本统计，核权重来自有效透射面积。
% 所有高斯核相加后先归一化为离散概率密度，再执行峰值归一化以计算
% 中心截线和径向 FWHM。
%
% mode='full' 时输出完整二维分布；mode='targetOnly' 时只计算二维混合
% 在 theta_y=0 和 theta_x=0 上的精确截线，用于中心截线目标的快速搜索。
% 输出矩阵的第一维对应 theta_x，第二维对应 theta_y。

if nargin < 3
    mode = 'full';
end
assert(any(strcmp(mode,{'full','targetOnly'})), ...
    '高斯角分布模式必须为 full 或 targetOnly。');

theta = linspace( ...
    config.angular.minimumDegree, ...
    config.angular.maximumDegree, ...
    config.angular.sampleCount);
angleSpacing = abs(theta(2)-theta(1));
if strcmp(mode,'full')
    [thetaXGrid,thetaYGrid] = ndgrid(theta,theta);
    rawDistribution = zeros(numel(theta),numel(theta));
else
    rawCenterCutX = zeros(numel(theta),1);
    rawCenterCutY = zeros(numel(theta),1);
end

statsTable = kernelStats.table;
validIndices = find(statsTable.validKernel);
assert(~isempty(validIndices), ...
    '当前候选表面没有形成任何有效高斯核，请检查分辨率和有效区域阈值。');

for localIndex = 1:numel(validIndices)
    row = validIndices(localIndex);
    covariance = [ ...
        statsTable.cov11_deg2(row),statsTable.cov12_deg2(row); ...
        statsTable.cov12_deg2(row),statsTable.cov22_deg2(row)];
    determinant = det(covariance);
    if ~isfinite(determinant) || determinant <= 0
        continue;
    end

    % 对 2 x 2 对称矩阵显式写出逆矩阵，避免在数千次循环中重复调用 inv。
    inverseCovariance = [ ...
        covariance(2,2),-covariance(1,2); ...
        -covariance(2,1),covariance(1,1)]/determinant;

    normalization = 2*pi*sqrt(determinant);
    if strcmp(mode,'full')
        deltaThetaX = thetaXGrid-statsTable.meanThetaX_deg(row);
        deltaThetaY = thetaYGrid-statsTable.meanThetaY_deg(row);
        quadraticForm = ...
            inverseCovariance(1,1).*deltaThetaX.^2 + ...
            2*inverseCovariance(1,2).*deltaThetaX.*deltaThetaY + ...
            inverseCovariance(2,2).*deltaThetaY.^2;
        gaussianDensity = exp(-0.5*quadraticForm)/normalization;
        rawDistribution = rawDistribution + ...
            statsTable.weight(row).*gaussianDensity;
    else
        % x 截线固定 theta_y=0；y 截线固定 theta_x=0。这里直接代入同一
        % 二维高斯公式，因此不是额外近似，只省略优化目标不需要的网格点。
        deltaX = theta(:)-statsTable.meanThetaX_deg(row);
        fixedDeltaY = -statsTable.meanThetaY_deg(row);
        quadraticX = inverseCovariance(1,1).*deltaX.^2 + ...
            2*inverseCovariance(1,2).*deltaX.*fixedDeltaY + ...
            inverseCovariance(2,2).*fixedDeltaY.^2;
        rawCenterCutX = rawCenterCutX + statsTable.weight(row).* ...
            exp(-0.5*quadraticX)/normalization;

        fixedDeltaX = -statsTable.meanThetaX_deg(row);
        deltaY = theta(:)-statsTable.meanThetaY_deg(row);
        quadraticY = inverseCovariance(1,1).*fixedDeltaX.^2 + ...
            2*inverseCovariance(1,2).*fixedDeltaX.*deltaY + ...
            inverseCovariance(2,2).*deltaY.^2;
        rawCenterCutY = rawCenterCutY + statsTable.weight(row).* ...
            exp(-0.5*quadraticY)/normalization;
    end
end

angularDistribution.thetaDegree = theta;
angularDistribution.angleSpacingDegree = angleSpacing;
angularDistribution.validKernelCount = kernelStats.validCount;
angularDistribution.mode = mode;

if strcmp(mode,'full')
    discreteIntegral = sum(rawDistribution(:))*angleSpacing^2;
    assert(isfinite(discreteIntegral) && discreteIntegral > 0, ...
        '高斯核叠加结果的总积分无效。');
    probabilityDensity = rawDistribution/discreteIntegral;
    peakValue = max(probabilityDensity(:));
    assert(isfinite(peakValue) && peakValue > 0, '高斯角分布峰值无效。');
    angularDistribution.raw = rawDistribution;
    angularDistribution.pdf = probabilityDensity;
    angularDistribution.normalized = probabilityDensity/peakValue;
    angularDistribution.discreteIntegralBeforeNormalization = discreteIntegral;
else
    assert(max(rawCenterCutX) > 0 && max(rawCenterCutY) > 0, ...
        '目标截线的高斯核叠加结果无效。');
    angularDistribution.centerCutXNormalized = ...
        rawCenterCutX/max(rawCenterCutX);
    angularDistribution.centerCutYNormalized = ...
        rawCenterCutY/max(rawCenterCutY);
end
end
