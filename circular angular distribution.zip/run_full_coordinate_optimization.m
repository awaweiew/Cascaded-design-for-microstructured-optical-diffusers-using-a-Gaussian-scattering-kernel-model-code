%% 高斯核散射模型：完整坐标优化总控脚本
% -------------------------------------------------------------------------
% 这是整个算法唯一需要日常修改和运行的入口脚本。它负责：
%   1. 设置固定物理参数；
%   2. 指定目标 FWHM 和评价方式；
%   3. 指定每个优化参数的开关、范围、粗细步长和先后顺序；
%   4. 运行公共随机样本约束下的逐参数坐标搜索；
%   5. 用正式分辨率重新评价最优参数；
%   6. 可选执行多随机种子稳定性验证；
%   7. 保存 MAT、CSV、JSON 和结果图。
%
% 参数顺序由 config.optimization.parameters 在配置函数中的排列决定。
% 本脚本不修改初稿和原始一阶段程序。
% -------------------------------------------------------------------------

clear;
clc;
close all;

projectDirectory = fileparts(mfilename('fullpath'));
addpath(projectDirectory);

%% ========================== A. 总体运行控制 ==========================

% action 可选：
%   'optimize'    执行完整坐标优化；
%   'forwardOnly'只计算当前初始参数，不改变任何参数；
%   'smokeTest'   使用很小阵列和低分辨率检查所有正向模块接口。
control.action = 'optimize';

% 搜索完成后是否以 create_diffuser_config 中的正式 5000 x 5000
% 分辨率重新评价最优参数。关闭时使用搜索分辨率进行最终评价。
control.runFinalFullResolution = false; %true;

% 是否执行多随机种子验证。大规模正式验证耗时较长，可先在搜索分辨率
% 验证，论文最终数据再将 validationUseFullResolution 改为 true。
control.runMultiSeedValidation = false;%true;
control.validationUseFullResolution = false;

% 是否绘制并保存最终表面、角分布、FWHM 曲线和优化历史。
control.createFigures = true;

%% ======================= B. 固定参数人工填写区 =======================
config = create_diffuser_config();

% diffuser 口径与规则阵列数量。
config.geometry.Lx = 0.5;                 % [mm]
config.geometry.Ly = 0.5;                 % [mm]
config.geometry.Nx = 400;
config.geometry.Ny = 400;

% 高度范围及 Beta 分布。若这些参数保持固定，不要在下一节启用它们。
config.height.minimum = 0.018;            % [mm]
config.height.maximum = 0.030;            % [mm]
config.height.alpha = 1.22;
config.height.beta = 4.48;

% k_a 基础范围及 Beta 分布。kaScale 会相对于这两个基础边界缩放。
config.aspectKa.minimum = 0.5   .*0.93.*0.984;
config.aspectKa.maximum = 0.8   .*0.93.*0.984;
config.aspectKa.alpha = 0.4;
config.aspectKa.beta = 0.4;
config.optimization.baseAspectKaMinimum = config.aspectKa.minimum;
config.optimization.baseAspectKaMaximum = config.aspectKa.maximum;
config.optimization.currentKaScale = 1.0;

config.geometry.kb = 0.666660;
config.geometry.positionJitterFraction = 0.40;
config.geometry.rotationRange = pi;
config.numerical.softMinK = 2500;         % [1/mm]
config.optical.nAir = 1.0;
config.optical.nSubstrate = 1.49;

% 目标角度是完整 FWHM，不是半角。
config.target.fwhmDegree = 30.0;
config.target.angleToleranceDegree = 0.10;
config.target.metric = 'centerCutX';       % 也可选 centerCutY/radialAverage

% 搜索阶段和最终阶段的空间分辨率。
config.numerical.searchResolutionX = 600;
config.numerical.searchResolutionY = 600;
config.numerical.resolutionX = 5000;
config.numerical.resolutionY = 5000;

% 固定角度网格。扩大范围可处理更宽散射，但会在点数不变时降低角分辨率。
config.angular.minimumDegree = -60;
config.angular.maximumDegree = 60;
config.angular.sampleCount = 301;

%% ====================== C. 优化参数人工填写区 ======================
% 先关闭全部参数，再按需要开启。这样不容易因配置函数新增示例参数而
% 意外扩大计算量。优化顺序仍由参数数组本身的排列顺序决定。
for parameterIndex = 1:numel(config.optimization.parameters)
    config.optimization.parameters(parameterIndex).enabled = false;
end

% ---------- 参数 1：k_a 整体缩放系数 ----------
index = find(strcmp({config.optimization.parameters.name},'kaScale'),1);
config.optimization.parameters(index).enabled = true;
config.optimization.parameters(index).lowerBound = 0.1;
config.optimization.parameters(index).upperBound = 2.0;
config.optimization.parameters(index).initialValue = 1.00;
config.optimization.parameters(index).coarseStep = 0.01;
config.optimization.parameters(index).fineStep = 0.002;

% ---------- 参数 2：短长轴比例 k_b ----------
index = find(strcmp({config.optimization.parameters.name},'kb'),1);
config.optimization.parameters(index).enabled = false;
config.optimization.parameters(index).lowerBound = 0.55;
config.optimization.parameters(index).upperBound = 0.70;
config.optimization.parameters(index).initialValue = 0.60;
config.optimization.parameters(index).coarseStep = 0.01;
config.optimization.parameters(index).fineStep = 0.002;

% 若要继续优化 k_a 的 Beta 分布形状，可取消下面注释并填写范围。
% index = find(strcmp({config.optimization.parameters.name},'alphaKa'),1);
% config.optimization.parameters(index).enabled = true;
% config.optimization.parameters(index).lowerBound = 1.0;
% config.optimization.parameters(index).upperBound = 3.0;
% config.optimization.parameters(index).initialValue = 1.62;
% config.optimization.parameters(index).coarseStep = 0.20;
% config.optimization.parameters(index).fineStep = 0.05;

% 多轮坐标搜索控制。
config.optimization.maximumSweeps = 3;
config.optimization.noImprovementPatience = 5;
config.optimization.maximumEvaluationsPerParameter = 100;
config.optimization.minimumSweepImprovementDegree = 0.01;
config.optimization.validationSeeds = 1:5;
config.optimization.performMultiSeedValidation = control.runMultiSeedValidation;

validate_diffuser_config(config);

%% ========================== D. 输出目录 ==========================
timeStamp = char(datetime('now','Format','yyyyMMdd_HHmmss'));
outputDirectory = fullfile(projectDirectory,'优化结果',timeStamp);
if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end
fprintf('本次结果目录：%s\n',outputDirectory);

%% ======================== E. 按运行模式执行 ========================
searchResult = [];
validation = [];

switch control.action
    case 'smokeTest'
        % 烟雾测试只检查模块连通性，不代表 60 x 60 正式设计结果。
        config.geometry.Nx = 12;
        config.geometry.Ny = 12;
        config.numerical.resolutionX = 320;
        config.numerical.resolutionY = 320;
        config.numerical.searchResolutionX = 320;
        config.numerical.searchResolutionY = 320;
        config.angular.sampleCount = 101;
        validate_diffuser_config(config);
        bank = build_common_random_bank(config);
        options.resolutionX = 320;
        options.resolutionY = 320;
        options.retainLargeData = true;
        options.failFast = true;
        options.angularMode = 'full';
        finalEvaluation = evaluate_diffuser_candidate(config,bank,options);

    case 'forwardOnly'
        bank = build_common_random_bank(config);
        options.resolutionX = config.numerical.resolutionX;
        options.resolutionY = config.numerical.resolutionY;
        options.retainLargeData = true;
        options.failFast = true;
        options.angularMode = 'full';
        finalEvaluation = evaluate_diffuser_candidate(config,bank,options);

    case 'optimize'
        bank = build_common_random_bank(config);
        searchResult = run_coordinate_search(config,bank,outputDirectory);
        bestConfig = searchResult.bestConfig;

        if control.runFinalFullResolution
            finalResolutionX = bestConfig.numerical.resolutionX;
            finalResolutionY = bestConfig.numerical.resolutionY;
        else
            finalResolutionX = bestConfig.numerical.searchResolutionX;
            finalResolutionY = bestConfig.numerical.searchResolutionY;
        end

        finalOptions.resolutionX = finalResolutionX;
        finalOptions.resolutionY = finalResolutionY;
        finalOptions.retainLargeData = true;
        finalOptions.failFast = true;
        finalOptions.angularMode = 'full';
        finalEvaluation = evaluate_diffuser_candidate( ...
            bestConfig,bank,finalOptions);

        if control.runMultiSeedValidation
            if control.validationUseFullResolution
                validationResolutionX = bestConfig.numerical.resolutionX;
                validationResolutionY = bestConfig.numerical.resolutionY;
            else
                validationResolutionX = bestConfig.numerical.searchResolutionX;
                validationResolutionY = bestConfig.numerical.searchResolutionY;
            end
            validation = validate_design_across_seeds( ...
                bestConfig,bestConfig.optimization.validationSeeds, ...
                validationResolutionX,validationResolutionY);
        end

    otherwise
        error('未知 control.action：%s。',control.action);
end

%% ========================== F. 保存与汇报 ==========================
save_optimization_results(outputDirectory,searchResult,finalEvaluation,validation);
if control.createFigures
    plot_optimization_results(finalEvaluation,searchResult,outputDirectory);
end

fprintf('\n计算完成。\n');
fprintf('主评价指标：%s\n',finalEvaluation.metrics.primaryMetric);
fprintf('最终主 FWHM：%.6f deg\n',finalEvaluation.metrics.primaryFwhmDegree);
fprintf('目标角度误差：%.6f deg\n',finalEvaluation.metrics.absoluteErrorDegree);
fprintf('结果已保存到：%s\n',outputDirectory);
