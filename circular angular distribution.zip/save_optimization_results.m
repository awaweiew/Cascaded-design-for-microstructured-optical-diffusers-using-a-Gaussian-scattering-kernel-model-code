function save_optimization_results( ...
        outputDirectory,searchResult,finalEvaluation,validation)
%SAVE_OPTIMIZATION_RESULTS 保存优化配置、历史、最终数据和验证结果。
%
% MAT 文件用于无损保留 MATLAB 结构体和二维矩阵；CSV 文件用于在 Origin、
% Excel 或 Python 中直接查看标量历史。每次总控脚本运行使用独立时间目录，
% 不覆盖以前结果。

if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end

save(fullfile(outputDirectory,'complete_optimization_result.mat'), ...
    'searchResult','finalEvaluation','validation','-v7.3');

if ~isempty(searchResult)
    writetable(searchResult.history, ...
        fullfile(outputDirectory,'optimization_history.csv'));
    writetable(searchResult.parameterResults, ...
        fullfile(outputDirectory,'parameter_summary.csv'));
end

if ~isempty(validation) && isfield(validation,'perSeed')
    writetable(validation.perSeed, ...
        fullfile(outputDirectory,'multi_seed_validation.csv'));
end

% 单独保存最终角分布及坐标，方便不加载完整结果文件时使用。
if isfield(finalEvaluation,'angularDistribution')
    thetaDegree = finalEvaluation.angularDistribution.thetaDegree;
    angularDistributionNormalized = ...
        finalEvaluation.angularDistribution.normalized;
    angularDistributionPdf = finalEvaluation.angularDistribution.pdf;
    save(fullfile(outputDirectory,'final_angular_distribution.mat'), ...
        'thetaDegree','angularDistributionNormalized', ...
        'angularDistributionPdf','-v7.3');
    writematrix(angularDistributionNormalized, ...
        fullfile(outputDirectory,'final_angular_distribution_normalized.csv'));
end

% JSON 只保存最终配置，便于人工审阅和跨语言读取。
if isfield(finalEvaluation,'config')
    configJson = jsonencode(finalEvaluation.config);
    writelines(string(configJson),fullfile(outputDirectory,'best_config.json'));
end
end

