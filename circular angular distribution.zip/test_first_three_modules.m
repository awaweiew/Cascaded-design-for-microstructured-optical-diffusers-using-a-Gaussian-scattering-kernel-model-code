%% 前三个基础模块的轻量自检
% 该脚本将分辨率降到 240 x 220，仅用于快速验证接口、随机复现性、
% 参数边界和 soft-min 表面基本性质，不替代 5000 x 5000 正式结果验证。

clear;
clc;

config = create_diffuser_config();
config.numerical.resolutionX = 240;
config.numerical.resolutionY = 220;
validate_diffuser_config(config);

bankFirst = build_common_random_bank(config);
bankSecond = build_common_random_bank(config);

% 相同配置和种子必须产生逐元素完全相同的公共随机数。
assert(isequal(bankFirst.heightQuantile, bankSecond.heightQuantile), ...
    '相同种子未能复现高度公共随机分位数。');
assert(isequal(bankFirst.kaQuantile, bankSecond.kaQuantile), ...
    '相同种子未能复现 k_a 公共随机分位数。');

[surfaceFirst, unitsFirst] = generate_diffuser_surface(config, bankFirst);
[surfaceSecond, unitsSecond] = generate_diffuser_surface(config, bankSecond);

% 正向表面生成也必须完全可复现。
assert(isequal(surfaceFirst.Z, surfaceSecond.Z), ...
    '相同配置和公共随机样本未能复现相同表面。');
assert(isequal(unitsFirst, unitsSecond), ...
    '相同配置和公共随机样本未能复现相同微结构参数。');

% 凹面约定：所有表面高度均应小于等于零，且至少存在一个负值像素。
assert(all(surfaceFirst.Z(:) <= 0), '表面中出现了正高度，不符合凹面约定。');
assert(any(surfaceFirst.Z(:) < 0), '表面中不存在凹坑。');

% 所有随机参数都必须落在人工给定的有限区间内。
assert(all(unitsFirst.height_mm >= config.height.minimum) && ...
       all(unitsFirst.height_mm <= config.height.maximum), ...
    '生成高度超出人工设定的上下限。');
assert(all(unitsFirst.ka >= config.aspectKa.minimum) && ...
       all(unitsFirst.ka <= config.aspectKa.maximum), ...
    '生成 k_a 超出人工设定的上下限。');
assert(all(abs(unitsFirst.semiMajorA_mm - ...
       unitsFirst.ka.*unitsFirst.height_mm) < 100*eps), ...
    '半长轴不满足 a=k_a*h。');
assert(all(abs(unitsFirst.semiMinorB_mm - ...
       config.geometry.kb.*unitsFirst.semiMajorA_mm) < 100*eps), ...
    '半短轴不满足 b=k_b*a。');

fprintf('前三个基础模块的全部轻量自检均已通过。\n');

