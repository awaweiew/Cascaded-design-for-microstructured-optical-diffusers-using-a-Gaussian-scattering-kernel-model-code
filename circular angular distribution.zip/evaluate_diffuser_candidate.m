function evaluation = evaluate_diffuser_candidate(config, randomBank, options)
%EVALUATE_DIFFUSER_CANDIDATE 对一组完整参数执行高斯核模型正向评价。
%
% 本函数对应模块八，是物理模型和优化算法之间的唯一接口。内部依次执行：
%   表面生成 -> 有效区域/坡度 -> 非线性 Snell -> 高斯核叠加 -> FWHM。
%
% options 可包含：
%   .resolutionX    本次评价使用的 x 分辨率；
%   .resolutionY    本次评价使用的 y 分辨率；
%   .retainLargeData是否在输出中保留高度场、核表和二维角分布；
%   .failFast       true 时遇到错误立即抛出，false 时返回 objective=Inf；
%   .angularMode    'full' 或 'targetOnly'。

if nargin < 3
    options = struct();
end
options = fill_evaluation_options_local(config,options);

evaluation = empty_evaluation_local();
startTime = tic;

try
    candidateConfig = config;
    candidateConfig.numerical.resolutionX = options.resolutionX;
    candidateConfig.numerical.resolutionY = options.resolutionY;

    % 优化候选点不需要长期保留覆盖矩阵，可减少大型评价的返回内存。
    if ~options.retainLargeData
        candidateConfig.numerical.returnCoverageMask = false;
    end
    validate_diffuser_config(candidateConfig);

    expectedUnitCount = candidateConfig.geometry.Nx*candidateConfig.geometry.Ny;
    if randomBank.unitCount ~= expectedUnitCount || ...
       randomBank.seed ~= candidateConfig.random.seed
        % 当 arrayN 或随机种子改变时，按当前配置重新建立确定性样本库。
        % 对固定 N 和种子的普通候选点仍使用传入的同一公共随机数。
        candidateBank = build_common_random_bank(candidateConfig);
    else
        candidateBank = randomBank;
    end

    [surfaceData,units] = generate_diffuser_surface(candidateConfig,candidateBank);
    kernelStats = extract_gaussian_kernel_stats(candidateConfig,surfaceData,units);
    angularDistribution = assemble_gaussian_distribution( ...
        candidateConfig,kernelStats,options.angularMode);
    metrics = measure_scattering_fwhm(candidateConfig,angularDistribution);

    if ~isfinite(metrics.primaryFwhmDegree)
        error('未能在当前角度网格内获得有效的主 FWHM。');
    end

    evaluation.status = 'valid';
    evaluation.objectiveDegree = metrics.absoluteErrorDegree;
    evaluation.signedErrorDegree = metrics.signedErrorDegree;
    evaluation.primaryFwhmDegree = metrics.primaryFwhmDegree;
    evaluation.fwhmCenterXDegree = metrics.fwhmCenterXDegree;
    evaluation.fwhmCenterYDegree = metrics.fwhmCenterYDegree;
    evaluation.fwhmRadialDegree = metrics.fwhmRadialDegree;
    evaluation.anisotropyDegree = metrics.anisotropyDegree;
    evaluation.withinTolerance = metrics.withinTolerance;
    evaluation.validKernelCount = kernelStats.validCount;
    evaluation.skippedKernelCount = kernelStats.skippedCount;
    evaluation.coveredFraction = surfaceData.coveredFraction;
    evaluation.minimumSurfaceHeight_mm = surfaceData.minimumHeight;
    evaluation.errorMessage = '';

    if options.retainLargeData
        evaluation.config = candidateConfig;
        evaluation.randomBank = candidateBank;
        evaluation.surfaceData = surfaceData;
        evaluation.units = units;
        evaluation.kernelStats = kernelStats;
        evaluation.angularDistribution = angularDistribution;
        evaluation.metrics = metrics;
    end
catch exception
    evaluation.status = 'invalid';
    evaluation.objectiveDegree = Inf;
    evaluation.errorMessage = exception.message;
    if options.failFast
        rethrow(exception);
    end
end

evaluation.elapsedSecond = toc(startTime);
evaluation.resolutionX = options.resolutionX;
evaluation.resolutionY = options.resolutionY;
evaluation.fromCache = false;
end

function options = fill_evaluation_options_local(config,options)
if ~isfield(options,'resolutionX')
    options.resolutionX = config.numerical.resolutionX;
end
if ~isfield(options,'resolutionY')
    options.resolutionY = config.numerical.resolutionY;
end
if ~isfield(options,'retainLargeData')
    options.retainLargeData = false;
end
if ~isfield(options,'failFast')
    options.failFast = config.optimization.failFast;
end
if ~isfield(options,'angularMode')
    options.angularMode = 'full';
end
if strcmp(config.target.metric,'radialAverage')
    options.angularMode = 'full';
end
end

function evaluation = empty_evaluation_local()
% 固定字段集合使有效点、无效点和缓存点能够安全组成结构体数组。
evaluation = struct( ...
    'status','invalid', ...
    'objectiveDegree',Inf, ...
    'signedErrorDegree',NaN, ...
    'primaryFwhmDegree',NaN, ...
    'fwhmCenterXDegree',NaN, ...
    'fwhmCenterYDegree',NaN, ...
    'fwhmRadialDegree',NaN, ...
    'anisotropyDegree',NaN, ...
    'withinTolerance',false, ...
    'validKernelCount',0, ...
    'skippedKernelCount',0, ...
    'coveredFraction',NaN, ...
    'minimumSurfaceHeight_mm',NaN, ...
    'errorMessage','', ...
    'elapsedSecond',NaN, ...
    'resolutionX',NaN, ...
    'resolutionY',NaN, ...
    'fromCache',false);
end
