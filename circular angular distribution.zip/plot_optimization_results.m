function figureHandles = plot_optimization_results( ...
        finalEvaluation,searchResult,outputDirectory)
%PLOT_OPTIMIZATION_RESULTS 绘制最终表面、角分布、FWHM 曲线和优化轨迹。
%
% 所有图均保存为 PNG。该函数不重新计算物理模型，只读取最终评价和
% 搜索历史，因此绘图设置不会影响优化结果。

if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end
assert(isfield(finalEvaluation,'surfaceData') && ...
       isfield(finalEvaluation,'angularDistribution') && ...
       isfield(finalEvaluation,'metrics'), ...
    '绘图要求最终评价使用 retainLargeData=true。');

figureHandles = gobjects(0);
surfaceData = finalEvaluation.surfaceData;
angular = finalEvaluation.angularDistribution;
metrics = finalEvaluation.metrics;

% ----------------------------- 最终表面 -----------------------------
plotStride = max(1,ceil(max( ...
    surfaceData.resolutionX,surfaceData.resolutionY)/800));
rows = 1:plotStride:surfaceData.resolutionY;
columns = 1:plotStride:surfaceData.resolutionX;
surfaceFigure = figure('Color','w','Name','最终优化 diffuser 表面');
surf(1e3*surfaceData.x(columns),1e3*surfaceData.y(rows), ...
    1e3*surfaceData.Z(rows,columns),1e3*surfaceData.Z(rows,columns), ...
    'EdgeColor','none');
axis equal tight;
xlabel('x (\mum)'); ylabel('y (\mum)'); zlabel('z (\mum)');
title('最终优化参数生成的 diffuser 连续表面');
colormap turbo; colorbar; view(45,45); light; lighting gouraud;
exportgraphics(surfaceFigure,fullfile(outputDirectory,'final_surface.png'), ...
    'Resolution',200);
figureHandles(end+1) = surfaceFigure;

% --------------------------- 二维高斯角分布 ---------------------------
angularFigure = figure('Color','w','Name','最终二维高斯角分布');
imagesc(angular.thetaDegree,angular.thetaDegree,angular.normalized.');
axis image; set(gca,'YDir','normal');
xlabel('\theta_x (deg)'); ylabel('\theta_y (deg)');
title(sprintf('Gaussian angular distribution, FWHM = %.4f^\\circ', ...
    metrics.primaryFwhmDegree));
colormap turbo; colorbar;
exportgraphics(angularFigure, ...
    fullfile(outputDirectory,'final_angular_distribution.png'),'Resolution',200);
figureHandles(end+1) = angularFigure;

% -------------------------- 截线和径向曲线 --------------------------
profileFigure = figure('Color','w','Name','最终 FWHM 曲线');
plot(metrics.thetaDegree,metrics.centerCutXNormalized,'LineWidth',1.8); hold on;
plot(metrics.thetaDegree,metrics.centerCutYNormalized,'--','LineWidth',1.8);
plot(metrics.radialRadiusDegree,metrics.radialProfileNormalized, ...
    '-.','LineWidth',1.8);
yline(0.5,':','Half maximum','LineWidth',1.2);
grid on; ylim([0,1.05]);
xlabel('Angle (deg)'); ylabel('Peak-normalized intensity');
legend( ...
    sprintf('x cut, FWHM %.4f^\\circ',metrics.fwhmCenterXDegree), ...
    sprintf('y cut, FWHM %.4f^\\circ',metrics.fwhmCenterYDegree), ...
    sprintf('radial, FWHM %.4f^\\circ',metrics.fwhmRadialDegree), ...
    'Half maximum','Location','best');
title('最终角分布的中心截线与径向平均');
exportgraphics(profileFigure,fullfile(outputDirectory,'final_fwhm_profiles.png'), ...
    'Resolution',200);
figureHandles(end+1) = profileFigure;

% ---------------------------- 优化历史 ----------------------------
if ~isempty(searchResult) && isfield(searchResult,'history') && ...
        ~isempty(searchResult.history)
    history = searchResult.history;
    validRow = isfinite(history.primaryFwhmDegree);
    evaluationIndex = find(validRow);
    historyFigure = figure('Color','w','Name','坐标优化历史');
    tiledlayout(2,1,'TileSpacing','compact');
    nexttile;
    plot(evaluationIndex,history.primaryFwhmDegree(validRow),'o-','LineWidth',1.2);
    yline(finalEvaluation.config.target.fwhmDegree,'--','Target');
    grid on; ylabel('FWHM (deg)'); title('候选参数评价得到的主 FWHM');
    nexttile;
    semilogy(evaluationIndex,max(history.objectiveDegree(validRow),eps), ...
        'o-','LineWidth',1.2);
    grid on; xlabel('Valid evaluation index'); ylabel('|FWHM-target| (deg)');
    title('目标误差变化');
    exportgraphics(historyFigure, ...
        fullfile(outputDirectory,'optimization_history.png'),'Resolution',200);
    figureHandles(end+1) = historyFigure;
end
end
