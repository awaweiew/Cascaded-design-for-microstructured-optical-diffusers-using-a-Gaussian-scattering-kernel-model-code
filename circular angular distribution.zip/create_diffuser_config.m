function config = create_diffuser_config()
%CREATE_DIFFUSER_CONFIG 建立高斯核散射模型优化所需的统一参数配置。
%
% 本函数是全部模块共用的模块一：参数配置与合法性检查。
% 这里集中保存散射片的物理参数、数值参数、随机参数以及后续优化参数。
% 这样做的目的，是避免不同函数内部重复出现零散的常数，从而保证后续
% 高斯核计算、FWHM 测量和坐标优化始终使用同一套参数定义。
%
% 后续的表面生成、有效区域提取、非线性 Snell 映射、高斯核叠加、
% FWHM 测量和坐标优化都从本结构体读取参数。
%
% 输出：
%   config - 完整配置结构体。

%% ========================= 1. 几何口径参数 =========================

% diffuser 的有效口径尺寸，单位均为 mm。
% 与当前一阶段修正程序保持一致，默认口径为 0.5 mm x 0.5 mm。
config.geometry.Lx = 0.5;
config.geometry.Ly = 0.5;

% 每个方向的微结构单元数。总单元数为 Nx * Ny。
% 原始程序使用 N x N；这里拆分为 Nx 和 Ny，便于以后扩展非方形阵列。
config.geometry.Nx = 60;
config.geometry.Ny = 60;

% 微结构中心相对于规则单元中心的位置扰动比例。
% x 方向最大扰动为 (单元宽度/2) * positionJitterFraction，
% y 方向同理。该数值应位于 [0,1] 内。
config.geometry.positionJitterFraction = 0.4;

% 椭球长轴的随机旋转范围，单位为 rad。
% 旋转角按 [0, rotationRange] 均匀分布；pi 表示 0~180°。
config.geometry.rotationRange = pi;

%% ====================== 2. 凹深 h 的分布参数 ======================

% 凹深 h 的上下限，单位为 mm。
config.height.minimum = 0.018;
config.height.maximum = 0.030;

% 归一化变量 u_h 服从 Beta(alpha,beta)，再映射到上述有限区间：
% h = h_min + (h_max-h_min) * u_h。
config.height.alpha = 1.22;
config.height.beta  = 4.48;

%% ==================== 3. 宽深比 k_a 的分布参数 ====================

% k_a 的上下限。椭球长轴满足 a = k_a * h。
config.aspectKa.minimum = 0.60;
config.aspectKa.maximum = 0.85;

% 归一化变量 u_ka 服从 Beta(alpha,beta)，再映射至有限区间。
config.aspectKa.alpha = 1.62;
config.aspectKa.beta  = 2.05;

% k_b 为短轴与长轴之比，椭球短轴满足 b = k_b * a。
config.geometry.kb = 0.60;

%% ========================= 4. 数值计算参数 =========================

% 正式计算分辨率与当前一阶段程序一致，均为 5000。
% 若只想快速检查前三个模块，可在入口脚本中临时覆盖为较小数值。
config.numerical.resolutionX = 5000;
config.numerical.resolutionY = 5000;

% 多凹坑重叠时的 soft-min 平滑系数，单位为 1/mm。
% 该参数属于表面融合模型参数，不应在后续优化中被当作命中 30° 的
% 任意经验调节量。
config.numerical.softMinK = 2500;

% 是否保存每个像素曾被椭球帽覆盖的逻辑矩阵。
% 后续调试时该矩阵很有用；正式大规模优化若内存紧张可设为 false，
% 但表面生成内部仍会临时使用覆盖矩阵以保证融合逻辑正确。
config.numerical.returnCoverageMask = true;

% 优化阶段使用较低分辨率寻找参数邻域，最终确认时恢复正式分辨率。
% 降低分辨率只改变空间离散精度，不改变表面方程和角度计算原理。
config.numerical.searchResolutionX = 1200;
config.numerical.searchResolutionY = 1200;

%% ========================= 5. 光学目标参数 =========================

% 虽然前三个模块暂不执行 Snell 映射，但先在统一配置中保留折射率，
% 供后续角度映射模块直接读取。
config.optical.nAir = 1.0;
config.optical.nSubstrate = 1.49;

% 目标散射角为完整半高全宽 FWHM，单位为 degree。
config.target.fwhmDegree = 30.0;
config.target.angleToleranceDegree = 0.1;

% 后续默认以 theta_y 约等于 0 的水平中心截线 FWHM 为主目标。
config.target.metric = 'centerCutX';

%% ==================== 6. 有效区域和高斯核参数 ====================

% soft-min 会使最终表面比参与融合的候选面略低。绝对支配容差取 5/k，
% 与现有一阶段修正程序一致；相对容差再乘以当前微结构凹深 h。
config.effectiveRegion.dominationToleranceFactor = 5.0;
config.effectiveRegion.dominationToleranceRelative = 0.02;

% 去掉椭球帽最边缘接近零高度的浅环区域，防止边缘差分噪声进入统计。
config.effectiveRegion.edgeDepthFraction = 0.03;
config.effectiveRegion.minimumPixelCount = 5;

% 高斯核中心和协方差缩放因子。二者默认均为 1，表示不使用经验校准。
config.kernel.meanDirectionScale = 1.0;
config.kernel.sigmaScale = 1.15;
config.kernel.useEffectiveAreaWeight = true;

% 最小标准差等于角度网格间距的指定倍数，用于协方差正则化。
config.kernel.minimumSigmaGridFactor = 0.50;

% 二维角度网格直接使用采样中心，单位为 degree。
% 301 个点对应约 0.4° 间隔，并确保 0° 是一个准确采样点。
config.angular.minimumDegree = -60;
config.angular.maximumDegree = 60;
config.angular.sampleCount = 301;

% 径向平均只使用二维正方形角分布中的最大完整内切圆。
config.measurement.radialBinCount = 300;

%% ========================= 7. 随机控制参数 =========================

% 固定主随机种子，使公共随机样本可以精确复现。
config.random.seed = 1;

% 公共随机数策略：不同候选参数共用相同的均匀分位数，
% 只改变 Beta 逆变换所用的分布参数。该策略是后续稳定优化的基础。
config.random.useCommonRandomNumbers = true;

%% ========================= 8. 优化控制参数 =========================

% 每个元素表示一个候选优化参数。enabled=true 的参数才会按照其在数组
% 中的排列顺序依次优化；每次只改变当前参数，其他参数全部保持不变。
%
% kaScale 同时缩放 k_a 上下限：
%   ka_min_new = kaScale * ka_min_base
%   ka_max_new = kaScale * ka_max_base
% 这样可避免同时调节 k_a 上下限造成参数冗余。application='direct'
% 表示直接写入 targetPath 指定的配置字段；application='arrayN' 表示
% 同时改变 Nx、Ny。下列范围是可编辑示例，应在总控脚本中最终确认。
config.optimization.baseAspectKaMinimum = config.aspectKa.minimum;
config.optimization.baseAspectKaMaximum = config.aspectKa.maximum;
config.optimization.currentKaScale = 1.0;

config.optimization.parameters = struct( ...
    'name', { ...
        'kaScale', 'kb', 'alphaKa', 'betaKa', ...
        'heightMinimum', 'heightMaximum', 'alphaHeight', 'betaHeight', ...
        'positionJitter', 'rotationRange', 'arrayN'}, ...
    'enabled', { ...
        true, true, false, false, false, false, false, false, false, false, false}, ...
    'application', { ...
        'kaScale', 'direct', 'direct', 'direct', ...
        'direct', 'direct', 'direct', 'direct', ...
        'direct', 'direct', 'arrayN'}, ...
    'targetPath', { ...
        '', 'geometry.kb', 'aspectKa.alpha', 'aspectKa.beta', ...
        'height.minimum', 'height.maximum', 'height.alpha', 'height.beta', ...
        'geometry.positionJitterFraction', 'geometry.rotationRange', ''}, ...
    'lowerBound', { ...
        0.95, 0.55, 1.00, 1.00, 0.014, 0.026, 0.80, 2.00, 0.10, 0, 40}, ...
    'upperBound', { ...
        1.05, 0.70, 3.00, 4.00, 0.022, 0.036, 3.00, 7.00, 0.80, pi, 80}, ...
    'initialValue', { ...
        1.00, 0.60, 1.62, 2.05, 0.018, 0.030, 1.22, 4.48, 0.40, pi, 60}, ...
    'coarseStep', { ...
        0.01, 0.01, 0.20, 0.20, 0.001, 0.001, 0.20, 0.25, 0.10, pi/12, 5}, ...
    'fineStep', { ...
        0.002, 0.002, 0.05, 0.05, 0.0002, 0.0002, 0.05, 0.05, 0.02, pi/60, 1}, ...
    'isInteger', { ...
        false, false, false, false, false, false, false, false, false, false, true});

% 一轮是指按顺序将所有参数各优化一次。后续可执行 2~3 轮坐标搜索。
config.optimization.maximumSweeps = 3;
config.optimization.noImprovementPatience = 2;
config.optimization.maximumEvaluationsPerParameter = 50;

% 一整轮参数优化前后的目标误差改善量低于该值时结束多轮坐标搜索。
config.optimization.minimumSweepImprovementDegree = 0.01;

% 最终设计是否进行多随机种子稳健性验证及其种子列表。
config.optimization.performMultiSeedValidation = true;
config.optimization.validationSeeds = 1:5;

% 优化搜索默认不保留每个候选点的大型高度场和角分布，只保存标量结果。
config.optimization.failFast = false;

% 当主指标为中心截线时，搜索阶段只计算同一二维高斯混合在 theta_y=0
% 和 theta_x=0 上的精确截线，不构造完整二维矩阵。该操作不改变中心
% 截线 FWHM 公式，可显著减少数千个候选高斯核的计算量。最终评价仍
% 强制生成完整二维角分布。径向平均为主指标时会自动关闭该加速。
config.optimization.useTargetOnlyAngularDuringSearch = true;

%% ========================= 9. 统一合法性检查 =========================

% 配置创建完成后立即检查。若参数存在物理矛盾或数值风险，函数在真正
% 分配大型矩阵之前报错，避免浪费计算时间与内存。
validate_diffuser_config(config);
end
