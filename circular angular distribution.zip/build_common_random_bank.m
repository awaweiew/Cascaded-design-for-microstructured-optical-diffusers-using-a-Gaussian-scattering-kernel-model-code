function randomBank = build_common_random_bank(config)
%BUILD_COMMON_RANDOM_BANK 为全部候选参数建立固定的公共随机样本库。
%
% 本函数对应模块二：公共随机样本生成。
%
% 传统写法在每次候选参数计算时重新调用 rand 或 betarnd，会同时改变
% 表面的随机实现，使优化器无法区分“参数作用”和“随机波动”。本函数
% 只生成 [0,1] 上的均匀分位数；后续表面生成函数再根据当前 alpha、
% beta 参数执行 Beta 逆变换。因此，即使 Beta 分布参数发生变化，每个
% 微结构仍保持相同的随机分位身份。
%
% 输入：
%   config     - 已通过 validate_diffuser_config 检查的配置结构体。
%
% 输出：
%   randomBank - 公共随机样本结构体，主要字段如下：
%       .positionXQuantile  x 方向位置扰动分位数，范围 [0,1]
%       .positionYQuantile  y 方向位置扰动分位数，范围 [0,1]
%       .heightQuantile     高度 Beta 分布所用均匀分位数
%       .kaQuantile         k_a Beta 分布所用均匀分位数
%       .rotationQuantile   旋转角均匀分位数
%       .seed               生成样本所用随机种子
%       .unitCount          样本对应的微结构总数

validate_diffuser_config(config);

unitCount = config.geometry.Nx * config.geometry.Ny;

% 使用局部 RandStream，而不调用 rng(seed)。这样不会改写 MATLAB 全局
% 随机数状态，也不会影响用户在主程序其他位置的随机计算。
stream = RandStream('mt19937ar', 'Seed', config.random.seed);

% 每一种物理随机量分别保存。列向量的第 p 行始终对应第 p 个微结构。
randomBank.positionXQuantile = rand(stream, unitCount, 1);
randomBank.positionYQuantile = rand(stream, unitCount, 1);
randomBank.heightQuantile    = rand(stream, unitCount, 1);
randomBank.kaQuantile        = rand(stream, unitCount, 1);
randomBank.rotationQuantile  = rand(stream, unitCount, 1);

randomBank.seed = config.random.seed;
randomBank.unitCount = unitCount;
randomBank.arraySize = [config.geometry.Ny, config.geometry.Nx];
randomBank.generator = 'mt19937ar';

% 理论上 rand 不会返回 0 或 1，但在做逆 Beta 变换前仍主动限制开区间，
% 防止极端平台或外部修改导致 betaincinv 在端点返回精确 0/1。
quantileFloor = eps('double');
quantileCeiling = 1 - eps('double');
fieldsToClamp = { ...
    'heightQuantile', 'kaQuantile'};
for index = 1:numel(fieldsToClamp)
    fieldName = fieldsToClamp{index};
    values = randomBank.(fieldName);
    randomBank.(fieldName) = min(max(values, quantileFloor), quantileCeiling);
end

validate_random_bank(randomBank, config);
end

function validate_random_bank(randomBank, config)
% 对样本库执行轻量自检，避免维度错误延迟到大型表面计算阶段才暴露。
expectedCount = config.geometry.Nx * config.geometry.Ny;
requiredFields = { ...
    'positionXQuantile', 'positionYQuantile', 'heightQuantile', ...
    'kaQuantile', 'rotationQuantile'};

for index = 1:numel(requiredFields)
    fieldName = requiredFields{index};
    assert(isfield(randomBank, fieldName), ...
        '公共随机样本库缺少字段 %s。', fieldName);
    values = randomBank.(fieldName);
    assert(iscolumn(values) && numel(values) == expectedCount, ...
        '公共随机样本字段 %s 的长度应为 %d。', fieldName, expectedCount);
    assert(all(isfinite(values)) && all(values >= 0) && all(values <= 1), ...
        '公共随机样本字段 %s 必须全部位于 [0,1]。', fieldName);
end
end
