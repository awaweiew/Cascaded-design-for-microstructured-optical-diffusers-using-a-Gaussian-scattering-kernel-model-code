import gc
import hashlib
import os
import shutil
from dataclasses import dataclass, field, replace
from pathlib import Path
import argparse

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3,4,5,6,7"


import numpy as np
import torch
import torch.fft as tfft
import torch.multiprocessing as mp


rdtype = torch.float32
cdtype = torch.complex64


@dataclass(frozen=True)
class PropagationConfig:
    gsm_path: str = "uniform_angle_373_Lm0p5mm_c0p1_E95_thetaX0p0_thetaY0p0_compact.npz"
    diffuser_file: str = "D:\王威\最新双设计diffuser复相干度分析_550nm_n1p49\diffusers\diffuser_single_direction_0p5mm_res1280_N400_h0p018to0p03_bh1p22x4p48_ka0p28094183999999983to0p4495069439999998_bka0p4x0p4_kb0p66666_seed1.npz"

    use_diffuser: bool = True
    devices: list[str] = field(
        default_factory=lambda: [
            "cuda:0", "cuda:1", "cuda:2", "cuda:3",
            "cuda:4", "cuda:5", "cuda:6", "cuda:7",
        ]
    )
    max_test_modes: int | None = None
    gpu_batch_size: int = 1
    keep_temp_files: bool = False

    wavelength_mm: float = 550e-6
    f_mm: float = 10.0
    f_pupil_mm: float = 10.0
    NA_fft: float = 0.2

    Lm_mm: float = 0.5
    Ld_mm: float = 0.5
    N_mid: int = 1280
    N_src: int = 373
    pupil_oversample: int = 3

    z_back_mm: float = -3.0
    z_12_mm: float = 0.8
    z_2m_mm: float = 2.2

    n_diffuser: float = 1.49
    L_pad_mm: float | None = None

    ap_diffuser_radius_mm: float = 0.25
    ap_mask_radius_mm: float = 0.1

    out_dir: str = "ww_stats_results"
    tmp_dir: str = "tmp_stats_parts"
    result_tag: str = ""
    verbose: bool = True


def centered_coords(N, dx):
    return (np.arange(N) - (N - 1) / 2.0) * dx


def split_ranges(n_total, n_parts):
    edges = np.linspace(0, n_total, n_parts + 1, dtype=int)
    return [(int(edges[i]), int(edges[i + 1])) for i in range(n_parts) if edges[i] < edges[i + 1]]


def fft2c_t(U):
    return torch.fft.fftshift(
        tfft.fft2(torch.fft.ifftshift(U, dim=(-2, -1))),
        dim=(-2, -1),
    )


def ifft2c_t(U):
    return torch.fft.fftshift(
        tfft.ifft2(torch.fft.ifftshift(U, dim=(-2, -1))),
        dim=(-2, -1),
    )


def crop_center_t(U, N_crop):
    N = U.shape[-1]
    s = (N - N_crop) // 2
    return U[..., s:s + N_crop, s:s + N_crop]


def crop_center_aligned_t(U, N_crop):
    """Crop around the discrete zero-frequency sample, including mixed parity."""
    Ny, Nx = U.shape[-2:]
    if N_crop > Ny or N_crop > Nx:
        raise ValueError(f"N_crop={N_crop} exceeds input shape {(Ny, Nx)}")
    sy = Ny // 2 - N_crop // 2
    sx = Nx // 2 - N_crop // 2
    return U[..., sy:sy + N_crop, sx:sx + N_crop]


def pad_center_t(U, N_pad):
    N = U.shape[-1]
    out_shape = list(U.shape[:-2]) + [N_pad, N_pad]
    out = torch.zeros(out_shape, dtype=U.dtype, device=U.device)
    s = (N_pad - N) // 2
    out[..., s:s + N, s:s + N] = U
    return out


def get_npz_key(data, keys):
    for key in keys:
        if key in data:
            return key
    raise KeyError(f"None of these keys were found: {keys}")


def safe_tag(value):
    if isinstance(value, (float, np.floating)):
        text = format(float(value), ".12g")
    else:
        text = str(value)
    return text.replace(".", "p").replace("-", "m")


def compact_output_path(out_dir, filename, max_path_chars=240):
    """Shorten an overlong Windows output name while keeping it deterministic."""
    candidate = os.path.join(out_dir, filename)
    if os.name != "nt" or len(os.path.abspath(candidate)) <= max_path_chars:
        return candidate, False

    suffix = Path(filename).suffix
    stem = Path(filename).stem
    digest = hashlib.sha256(filename.encode("utf-8")).hexdigest()[:12]
    max_filename_chars = min(
        180,
        max_path_chars - len(os.path.abspath(out_dir)) - 1,
    )
    marker = f"__{digest}"
    keep_chars = max_filename_chars - len(suffix) - len(marker)
    if keep_chars < 32:
        raise OSError(
            "The output directory is too long for a portable Windows path. "
            "Use a shorter --out-dir value."
        )

    head_chars = (2 * keep_chars) // 3
    tail_chars = keep_chars - head_chars
    compact_name = f"{stem[:head_chars]}{marker}{stem[-tail_chars:]}{suffix}"
    compact_path = os.path.join(out_dir, compact_name)
    if len(os.path.abspath(compact_path)) > max_path_chars:
        raise OSError(
            "Unable to create a Windows-safe output path. "
            "Use a shorter --out-dir value."
        )
    return compact_path, True


def parse_sigmac_from_source_name(path):
    stem = Path(path).stem
    parts = stem.split("_")
    for part in parts:
        if part.startswith("c") and len(part) > 1:
            try:
                return float(part[1:].replace("p", "."))
            except ValueError:
                pass
    return np.nan


def make_params(config):
    pupil_oversample = int(config.pupil_oversample)
    if pupil_oversample < 1 or pupil_oversample != config.pupil_oversample:
        raise ValueError("pupil_oversample must be a positive integer")

    dxm = config.Lm_mm / config.N_mid
    dxs = config.wavelength_mm * config.f_mm / config.Lm_mm
    N_pupil_fft = pupil_oversample * config.N_mid
    N_pupil = pupil_oversample * (config.N_src - 1) + 1
    dx_pupil = config.wavelength_mm * config.f_pupil_mm / (N_pupil_fft * dxm)
    if N_pupil > N_pupil_fft:
        raise ValueError(
            f"N_pupil={N_pupil} exceeds final FFT grid N_pupil_fft={N_pupil_fft}"
        )
    if config.L_pad_mm is None:
        theta_max = np.arcsin(config.NA_fft)
        z_for_pad = max(
            abs(config.z_back_mm),
            abs(config.z_12_mm),
            abs(config.z_2m_mm),
        )
        L_pad_mm = max(
            1.5 * config.Lm_mm,
            config.Lm_mm + 2.0 * z_for_pad * np.tan(theta_max),
        )
    else:
        L_pad_mm = config.L_pad_mm

    N_pad = int(round(L_pad_mm / dxm))
    L_pad_real = N_pad * dxm

    return {
        "use_diffuser": bool(config.use_diffuser),
        "wavelength": float(config.wavelength_mm),
        "f": float(config.f_mm),
        "f_pupil": float(config.f_pupil_mm),
        "NA_fft": float(config.NA_fft),
        "Lm": float(config.Lm_mm),
        "Ld": float(config.Ld_mm),
        "N_mid": int(config.N_mid),
        "N_src": int(config.N_src),
        "pupil_oversample": pupil_oversample,
        "N_pupil_fft": int(N_pupil_fft),
        "N_pupil": int(N_pupil),
        "dxm": float(dxm),
        "dxs": float(dxs),
        "dx_pupil": float(dx_pupil),
        "z_back": float(config.z_back_mm),
        "z_12": float(config.z_12_mm),
        "z_2m": float(config.z_2m_mm),
        "n_diffuser": float(config.n_diffuser),
        "L_pad": float(L_pad_mm),
        "N_pad": int(N_pad),
        "L_pad_real": float(L_pad_real),
        "ap_diffuser_radius": float(config.ap_diffuser_radius_mm),
        "ap_mask_radius": float(config.ap_mask_radius_mm),
    }


def build_center_ref(N, x_arr, y_arr):
    iy = N // 2
    ix = N // 2
    return {
        "center": {
            "name": "center",
            "iy": int(iy),
            "ix": int(ix),
            "x": float(x_arr[ix]),
            "y": float(y_arr[iy]),
        }
    }


def crop_square_by_radius_np(A, x_arr, y_arr, radius):
    x_mask = np.abs(x_arr) <= radius
    y_mask = np.abs(y_arr) <= radius
    return A[np.ix_(y_mask, x_mask)], x_arr[x_mask], y_arr[y_mask]


def make_asm_H_torch(N, dx, wavelength, z, keep_evanescent=False, na_limit=None, device="cuda:0"):
    device = torch.device(device)

    fx = torch.fft.fftshift(torch.fft.fftfreq(N, d=dx, device=device, dtype=rdtype))
    fy = torch.fft.fftshift(torch.fft.fftfreq(N, d=dx, device=device, dtype=rdtype))
    FY, FX = torch.meshgrid(fy, fx, indexing="ij")

    FR = torch.sqrt(FX ** 2 + FY ** 2)
    arg = (1.0 / wavelength ** 2) - FX ** 2 - FY ** 2

    if keep_evanescent:
        kz = 2.0 * np.pi * torch.sqrt(arg.to(cdtype))
        H = torch.exp(1j * kz * z)
    else:
        H = torch.zeros((N, N), dtype=cdtype, device=device)
        mask_prop = arg >= 0
        kz = torch.zeros((N, N), dtype=rdtype, device=device)
        kz[mask_prop] = 2.0 * np.pi * torch.sqrt(arg[mask_prop])
        H[mask_prop] = torch.exp(1j * kz[mask_prop] * z)

    if na_limit is not None:
        H = H * (FR <= (na_limit / wavelength))

    return H.to(cdtype)


def angular_spectrum_with_H_t(U0, H):
    return ifft2c_t(fft2c_t(U0) * H).to(cdtype)


def make_diffuser_phase_torch(Z_final_np, wavelength, n_diffuser, device):
    Z = torch.as_tensor(Z_final_np, dtype=torch.float64, device=device)
    k = 2.0 * np.pi / wavelength
    phase_arg = k * (n_diffuser - 1.0) * Z
    return torch.exp(1j * phase_arg).to(cdtype)


def make_circular_aperture_torch(N, dx, radius, device):
    x = torch.as_tensor(centered_coords(N, dx), dtype=rdtype, device=device)
    y = torch.as_tensor(centered_coords(N, dx), dtype=rdtype, device=device)
    Y, X = torch.meshgrid(y, x, indexing="ij")
    return ((X ** 2 + Y ** 2) <= radius ** 2).to(rdtype)


@torch.no_grad()
def make_weighted_modes_batch_torch(phi_1d_x_t, phi_1d_y_t, mode_pairs_t, eigvals_2d_t, st, ed):
    pairs = mode_pairs_t[st:ed]
    ii = pairs[:, 0].long()
    jj = pairs[:, 1].long()

    phi_x_i = phi_1d_x_t[:, ii].T.contiguous()
    phi_y_j = phi_1d_y_t[:, jj].T.contiguous()

    lam = eigvals_2d_t[st:ed]
    amp = torch.sqrt(torch.clamp(lam, min=0.0)).to(rdtype)

    U = amp[:, None, None] * phi_y_j[:, :, None] * phi_x_i[:, None, :]
    return U.to(cdtype)


@torch.no_grad()
def propagate_batch_torch(U_src_batch, params, P_diffuser, P_mask, phase_diffuser, H_back, H_12, H_2m):
    N_mid = params["N_mid"]
    N_pad = params["N_pad"]
    N_pupil_fft = params["N_pupil_fft"]
    N_pupil = params["N_pupil"]

    dxs = params["dxs"]
    dxm = params["dxm"]
    wavelength = params["wavelength"]
    f = params["f"]
    f_pupil = params["f_pupil"]

    device = U_src_batch.device

    c1 = torch.tensor(
        np.exp(1j * 2.0 * np.pi / wavelength * f) / (1j * wavelength * f),
        dtype=cdtype,
        device=device,
    )
    c2 = torch.tensor(
        np.exp(1j * 2.0 * np.pi / wavelength * f_pupil) / (1j * wavelength * f_pupil),
        dtype=cdtype,
        device=device,
    )

    scale1 = torch.tensor(dxs * dxs, dtype=rdtype, device=device)
    scale2 = torch.tensor(dxm * dxm, dtype=rdtype, device=device)

    U = pad_center_t(U_src_batch.to(cdtype), N_mid)
    U = fft2c_t(U) * scale1 * c1

    U = pad_center_t(U, N_pad)
    U = angular_spectrum_with_H_t(U, H_back)
    U_diffuser_front = crop_center_t(U, N_mid)

    U_diffuser_front_ap = U_diffuser_front * P_diffuser
    U = U_diffuser_front_ap

    if params["use_diffuser"]:
        U = U * phase_diffuser

    U = pad_center_t(U, N_pad)
    U = angular_spectrum_with_H_t(U, H_12)
    U = crop_center_t(U, N_mid)

    U = U * P_diffuser
    if params["use_diffuser"]:
        U = U * phase_diffuser

    U = pad_center_t(U, N_pad)
    U = angular_spectrum_with_H_t(U, H_2m)
    U_mask_before_ap = crop_center_t(U, N_mid)

    U_mask_ap = U_mask_before_ap * P_mask
    U = pad_center_t(U_mask_ap, N_pupil_fft)
    U = fft2c_t(U) * scale2 * c2
    U_pupil = crop_center_aligned_t(U, N_pupil)

    return U_pupil.to(cdtype), U_diffuser_front_ap.to(cdtype), U_mask_ap.to(cdtype)


def load_source_for_worker(config, params, device):
    gsm_data = np.load(config.gsm_path, allow_pickle=True)

    phi_x_key = get_npz_key(gsm_data, ["phi_1d_x", "phi_1d"])
    phi_y_key = get_npz_key(gsm_data, ["phi_1d_y", "phi_1d"])
    pair_key = get_npz_key(gsm_data, ["mode_pairs"])
    eig_key = get_npz_key(gsm_data, ["eigvals_2d", "eigvals_2d_keep"])

    phi_1d_x_np = np.asarray(gsm_data[phi_x_key], dtype=np.complex64)
    phi_1d_y_np = np.asarray(gsm_data[phi_y_key], dtype=np.complex64)
    mode_pairs_np = np.asarray(gsm_data[pair_key], dtype=np.int64)
    eigvals_2d_np = np.asarray(gsm_data[eig_key], dtype=np.float32)

    if config.max_test_modes is not None:
        mode_pairs_np = mode_pairs_np[:config.max_test_modes]
        eigvals_2d_np = eigvals_2d_np[:config.max_test_modes]

    N_src = params["N_src"]
    if phi_1d_x_np.shape[0] != N_src:
        raise ValueError(f"phi_1d_x length {phi_1d_x_np.shape[0]} != N_src {N_src}")
    if phi_1d_y_np.shape[0] != N_src:
        raise ValueError(f"phi_1d_y length {phi_1d_y_np.shape[0]} != N_src {N_src}")

    return (
        torch.as_tensor(phi_1d_x_np, dtype=cdtype, device=device),
        torch.as_tensor(phi_1d_y_np, dtype=cdtype, device=device),
        torch.as_tensor(mode_pairs_np, dtype=torch.long, device=device),
        torch.as_tensor(eigvals_2d_np, dtype=rdtype, device=device),
    )


def load_diffuser_phase_for_worker(config, params, device):
    diff_data = np.load(config.diffuser_file, allow_pickle=True)
    if "Z_final" not in diff_data:
        raise KeyError(f"{config.diffuser_file} does not contain Z_final")

    Z_final = np.asarray(diff_data["Z_final"], dtype=np.float32)
    expected_shape = (params["N_mid"], params["N_mid"])
    if Z_final.shape != expected_shape:
        raise ValueError(f"Z_final.shape={Z_final.shape}, expected {expected_shape}")

    return make_diffuser_phase_torch(
        Z_final_np=Z_final,
        wavelength=params["wavelength"],
        n_diffuser=params["n_diffuser"],
        device=device,
    )


def worker_gpu_accumulate(dev, global_start, global_end, result_path, params, config):
    device = torch.device(dev)
    torch.cuda.set_device(device)

    print(f"[{dev}] modes {global_start} ~ {global_end - 1}")

    phi_1d_x_t, phi_1d_y_t, mode_pairs_t, eigvals_2d_t = load_source_for_worker(config, params, device)
    phase_diffuser = load_diffuser_phase_for_worker(config, params, device)

    P_diffuser = make_circular_aperture_torch(
        params["N_mid"], params["dxm"], params["ap_diffuser_radius"], device
    )
    P_mask = make_circular_aperture_torch(
        params["N_mid"], params["dxm"], params["ap_mask_radius"], device
    )

    H_back = make_asm_H_torch(
        N=params["N_pad"],
        dx=params["dxm"],
        wavelength=params["wavelength"],
        z=params["z_back"],
        keep_evanescent=False,
        na_limit=params["NA_fft"],
        device=device,
    )
    H_12 = make_asm_H_torch(
        N=params["N_pad"],
        dx=params["dxm"],
        wavelength=params["wavelength"],
        z=params["z_12"],
        keep_evanescent=False,
        na_limit=None,
        device=device,
    )
    H_2m = make_asm_H_torch(
        N=params["N_pad"],
        dx=params["dxm"],
        wavelength=params["wavelength"],
        z=params["z_2m"],
        keep_evanescent=False,
        na_limit=None,
        device=device,
    )
    torch.cuda.empty_cache()

    N_src = params["N_src"]
    N_pupil = params["N_pupil"]
    x_source = centered_coords(N_src, params["dxs"])
    x_pupil = centered_coords(N_pupil, params["dx_pupil"])
    source_refs = build_center_ref(N_src, x_source, x_source.copy())
    pupil_refs = build_center_ref(N_pupil, x_pupil, x_pupil.copy())
    iy_src = source_refs["center"]["iy"]
    ix_src = source_refs["center"]["ix"]
    iy_pup = pupil_refs["center"]["iy"]
    ix_pup = pupil_refs["center"]["ix"]

    I_source_acc = torch.zeros((N_src, N_src), dtype=rdtype, device=device)
    J_source_center_acc = torch.zeros((N_src, N_src), dtype=cdtype, device=device)
    I_pupil_acc = torch.zeros((N_pupil, N_pupil), dtype=rdtype, device=device)
    J_pupil_center_acc = torch.zeros((N_pupil, N_pupil), dtype=cdtype, device=device)

    I_diffuser_front_acc = torch.zeros((params["N_mid"], params["N_mid"]), dtype=rdtype, device=device)
    I_mask_acc = torch.zeros((params["N_mid"], params["N_mid"]), dtype=rdtype, device=device)

    local_total = global_end - global_start

    for g_st in range(global_start, global_end, config.gpu_batch_size):
        g_ed = min(g_st + config.gpu_batch_size, global_end)

        U_src_batch = make_weighted_modes_batch_torch(
            phi_1d_x_t=phi_1d_x_t,
            phi_1d_y_t=phi_1d_y_t,
            mode_pairs_t=mode_pairs_t,
            eigvals_2d_t=eigvals_2d_t,
            st=g_st,
            ed=g_ed,
        )

        I_source_acc += torch.sum(torch.abs(U_src_batch) ** 2, dim=0).to(rdtype)
        ref_source_center = U_src_batch[:, iy_src, ix_src]
        J_source_center_acc += torch.sum(
            torch.conj(ref_source_center)[:, None, None] * U_src_batch,
            dim=0,
        )

        U_pupil, U_diff_front, U_mask = propagate_batch_torch(
            U_src_batch=U_src_batch,
            params=params,
            P_diffuser=P_diffuser,
            P_mask=P_mask,
            phase_diffuser=phase_diffuser,
            H_back=H_back,
            H_12=H_12,
            H_2m=H_2m,
        )

        I_pupil_acc += torch.sum(torch.abs(U_pupil) ** 2, dim=0).to(rdtype)
        I_diffuser_front_acc += torch.sum(torch.abs(U_diff_front) ** 2, dim=0).to(rdtype)
        I_mask_acc += torch.sum(torch.abs(U_mask) ** 2, dim=0).to(rdtype)

        ref_pupil_center = U_pupil[:, iy_pup, ix_pup]
        J_pupil_center_acc += torch.sum(
            torch.conj(ref_pupil_center)[:, None, None] * U_pupil,
            dim=0,
        )

        done = g_ed - global_start
        if config.verbose and (done % max(1, config.gpu_batch_size * 10) == 0 or g_ed == global_end):
            print(f"[{dev}] done {done}/{local_total}")

        del U_src_batch, U_pupil, U_diff_front, U_mask
        del ref_source_center, ref_pupil_center
        torch.cuda.empty_cache()

    np.savez(
        result_path,
        global_start=np.int64(global_start),
        global_end=np.int64(global_end),
        I_source=I_source_acc.detach().cpu().numpy().astype(np.float32),
        J_source_center=J_source_center_acc.detach().cpu().numpy().astype(np.complex64),
        I_pupil=I_pupil_acc.detach().cpu().numpy().astype(np.float32),
        J_pupil_center=J_pupil_center_acc.detach().cpu().numpy().astype(np.complex64),
        I_diffuser_front=I_diffuser_front_acc.detach().cpu().numpy().astype(np.float32),
        I_mask=I_mask_acc.detach().cpu().numpy().astype(np.float32),
    )

    del I_source_acc, J_source_center_acc
    del I_pupil_acc, J_pupil_center_acc
    del I_diffuser_front_acc, I_mask_acc
    del H_back, H_12, H_2m, phase_diffuser, P_diffuser, P_mask
    del phi_1d_x_t, phi_1d_y_t, mode_pairs_t, eigvals_2d_t
    torch.cuda.empty_cache()
    gc.collect()

    print(f"[{dev}] saved partial: {result_path}")


def inspect_inputs(config, params):
    gsm_data = np.load(config.gsm_path, allow_pickle=True)
    eig_key = get_npz_key(gsm_data, ["eigvals_2d", "eigvals_2d_keep"])
    eigvals_2d = np.asarray(gsm_data[eig_key])
    M_all = len(eigvals_2d)
    M = min(int(config.max_test_modes), M_all) if config.max_test_modes is not None else M_all

    x_key = get_npz_key(gsm_data, ["x"])
    dx_key = get_npz_key(gsm_data, ["dx"])
    x_src = np.asarray(gsm_data[x_key])
    dx_src = float(gsm_data[dx_key])

    if len(x_src) != params["N_src"]:
        raise ValueError(f"source x length {len(x_src)} != N_src {params['N_src']}")
    if abs(dx_src - params["dxs"]) > 1e-12:
        raise ValueError(f"source dx={dx_src} != propagation dxs={params['dxs']}")

    diff_data = np.load(config.diffuser_file, allow_pickle=True)
    Z_final = np.asarray(diff_data["Z_final"], dtype=np.float32)
    expected_shape = (params["N_mid"], params["N_mid"])
    if Z_final.shape != expected_shape:
        raise ValueError(f"Z_final.shape={Z_final.shape}, expected {expected_shape}")

    return M_all, M


def merge_partial_results(result_paths, params):
    I_source = np.zeros((params["N_src"], params["N_src"]), dtype=np.float64)
    J_source_center = np.zeros((params["N_src"], params["N_src"]), dtype=np.complex128)
    I_pupil = np.zeros((params["N_pupil"], params["N_pupil"]), dtype=np.float64)
    J_pupil_center = np.zeros((params["N_pupil"], params["N_pupil"]), dtype=np.complex128)

    I_diffuser_front = np.zeros((params["N_mid"], params["N_mid"]), dtype=np.float64)
    I_mask = np.zeros((params["N_mid"], params["N_mid"]), dtype=np.float64)

    for result_path in result_paths:
        with np.load(result_path, allow_pickle=True) as part:
            I_source += part["I_source"].astype(np.float64)
            J_source_center += part["J_source_center"].astype(np.complex128)
            I_pupil += part["I_pupil"].astype(np.float64)
            J_pupil_center += part["J_pupil_center"].astype(np.complex128)
            I_diffuser_front += part["I_diffuser_front"].astype(np.float64)
            I_mask += part["I_mask"].astype(np.float64)

    return I_source, J_source_center, I_pupil, J_pupil_center, I_diffuser_front, I_mask


def save_merged_results(config, params, refs, M_all, M, merged):
    I_source, J_source_center, I_pupil, J_pupil_center, I_diffuser_front, I_mask = merged

    eps = 1e-30
    iy_c = refs["pupil_center"]["iy"]
    ix_c = refs["pupil_center"]["ix"]
    I_pupil_center = I_pupil[iy_c, ix_c]

    j_pupil_center = J_pupil_center / np.sqrt(np.maximum(I_pupil_center * I_pupil, eps))
    abs_j_pupil_center = np.abs(j_pupil_center).astype(np.float32)

    x_source = centered_coords(params["N_src"], params["dxs"])
    y_source = x_source.copy()
    x_pupil = centered_coords(params["N_pupil"], params["dx_pupil"])
    y_pupil = x_pupil.copy()
    x_mid = centered_coords(params["N_mid"], params["dxm"])
    y_mid = x_mid.copy()

    I_diffuser_front_eff, x_diffuser, y_diffuser = crop_square_by_radius_np(
        I_diffuser_front,
        x_mid,
        y_mid,
        params["ap_diffuser_radius"],
    )
    I_mask_eff, x_mask, y_mask = crop_square_by_radius_np(
        I_mask,
        x_mid,
        y_mid,
        params["ap_mask_radius"],
    )

    meta = {
        "script_name": "03_propagate_stats.py",
        "source_gsm_file": config.gsm_path,
        "source_stem": Path(config.gsm_path).stem,
        "source_sigma_c_mm": parse_sigmac_from_source_name(config.gsm_path),
        "diffuser_file": config.diffuser_file,
        "diffuser_stem": Path(config.diffuser_file).stem,
        "use_diffuser": bool(config.use_diffuser),
        "phase_model": "exp(i * 2pi/lambda * (n_diffuser - 1) * Z_final)",
        "M_all": int(M_all),
        "M_used": int(M),
        "max_test_modes": None if config.max_test_modes is None else int(config.max_test_modes),
        "gpu_batch_size": int(config.gpu_batch_size),
        "reference_point": "independent source/pupil array centers",
        "pupil_sampling_method": "zero-pad mask plane before final mask-to-pupil FFT",
        "saved_intensity_windows": "source full N_src; pupil full N_pupil; diffuser/mask cropped to aperture bounding square",
        **params,
    }

    os.makedirs(config.out_dir, exist_ok=True)
    gsm_stem = Path(config.gsm_path).stem
    diffuser_stem = Path(config.diffuser_file).stem
    descriptive_filename = (
        f"stats_{gsm_stem}_{diffuser_stem}_Ddiff{safe_tag(2.0 * params['ap_diffuser_radius'])}mm"
        f"{'_' + safe_tag(config.result_tag) if config.result_tag else ''}_NA0p2_Nmid{params['N_mid']}"
        f"_PupOS{params['pupil_oversample']}.npz"
    )
    save_path, filename_compacted = compact_output_path(
        config.out_dir,
        descriptive_filename,
    )
    meta["descriptive_output_filename"] = descriptive_filename
    meta["output_filename_compacted"] = bool(filename_compacted)

    np.savez(
        save_path,
        I_source=I_source.astype(np.float32),
        J_source_center=J_source_center.astype(np.complex64),
        I_diffuser_front=I_diffuser_front_eff.astype(np.float32),
        I_mask=I_mask_eff.astype(np.float32),
        I_pupil=I_pupil.astype(np.float32),
        J_pupil_center=J_pupil_center.astype(np.complex64),
        j_pupil_center=j_pupil_center.astype(np.complex64),
        abs_j_pupil_center=abs_j_pupil_center,
        x_source=x_source.astype(np.float64),
        y_source=y_source.astype(np.float64),
        x_diffuser=x_diffuser.astype(np.float64),
        y_diffuser=y_diffuser.astype(np.float64),
        x_mask=x_mask.astype(np.float64),
        y_mask=y_mask.astype(np.float64),
        x_pupil=x_pupil.astype(np.float64),
        y_pupil=y_pupil.astype(np.float64),
        refs=np.array([refs], dtype=object),
        meta=np.array([meta], dtype=object),
    )

    return save_path


def run_propagation(config):
    params = make_params(config)

    if not torch.cuda.is_available():
        raise RuntimeError("torch.cuda.is_available() = False")

    M_all, M = inspect_inputs(config, params)

    x_source = centered_coords(params["N_src"], params["dxs"])
    x_pupil = centered_coords(params["N_pupil"], params["dx_pupil"])
    source_ref = build_center_ref(params["N_src"], x_source, x_source.copy())["center"]
    pupil_ref = build_center_ref(params["N_pupil"], x_pupil, x_pupil.copy())["center"]
    refs = {
        "center": source_ref,
        "source_center": source_ref.copy(),
        "pupil_center": pupil_ref,
    }

    if config.verbose:
        print("========== propagation config ==========")
        print(f"torch version       = {torch.__version__}")
        print(f"cuda device count   = {torch.cuda.device_count()}")
        print(f"gsm_path            = {config.gsm_path}")
        print(f"diffuser_file       = {config.diffuser_file}")
        print(f"M_all               = {M_all}")
        print(f"M_used              = {M}")
        print(f"N_src               = {params['N_src']}")
        print(f"N_mid               = {params['N_mid']}")
        print(f"N_pad               = {params['N_pad']}")
        print(f"pupil oversample    = {params['pupil_oversample']}x")
        print(f"N_pupil_fft         = {params['N_pupil_fft']}")
        print(f"N_pupil             = {params['N_pupil']}")
        print(f"dxs                 = {params['dxs']:.12e} mm")
        print(f"dxm                 = {params['dxm']:.12e} mm")
        print(f"dx_pupil            = {params['dx_pupil']:.12e} mm")
        print(f"L_pad_real          = {params['L_pad_real']:.9f} mm")
        print(f"ap_diffuser_radius  = {params['ap_diffuser_radius']:.6f} mm")
        print(f"ap_mask_radius      = {params['ap_mask_radius']:.6f} mm")
        print(f"source center ref   = {refs['source_center']}")
        print(f"pupil center ref    = {refs['pupil_center']}")

    active_devices = config.devices[:min(len(config.devices), M, torch.cuda.device_count())]
    ranges = split_ranges(M, len(active_devices))

    os.makedirs(config.tmp_dir, exist_ok=True)
    result_paths = []
    procs = []
    diffuser_stem = Path(config.diffuser_file).stem

    for idx, (st, ed) in enumerate(ranges):
        result_path = os.path.join(config.tmp_dir, f"part_{diffuser_stem}_{idx:02d}_{st}_{ed}.npz")
        result_paths.append(result_path)

        p = mp.Process(
            target=worker_gpu_accumulate,
            args=(active_devices[idx], st, ed, result_path, params, config),
        )
        p.start()
        procs.append(p)

    for p in procs:
        p.join()

    for p in procs:
        if p.exitcode != 0:
            raise RuntimeError(f"A GPU subprocess failed, exitcode={p.exitcode}")

    if config.verbose:
        print("========== merging partial results ==========")

    merged = merge_partial_results(result_paths, params)
    save_path = save_merged_results(config, params, refs, M_all, M, merged)

    if not config.keep_temp_files:
        for result_path in result_paths:
            if os.path.exists(result_path):
                os.remove(result_path)
        shutil.rmtree(config.tmp_dir, ignore_errors=True)

    gc.collect()

    print("========== propagation saved ==========")
    print(save_path)
    return save_path


def parse_args():
    parser = argparse.ArgumentParser(description="Propagate coherent modes and save statistics.")
    parser.add_argument("--gsm-path", type=str, default=None)
    parser.add_argument("--diffuser-file", type=str, default=None)
    parser.add_argument("--Lm-mm", type=float, default=None)
    parser.add_argument("--Ld-mm", type=float, default=None)
    parser.add_argument("--N-mid", type=int, default=None)
    parser.add_argument("--N-src", type=int, default=None)
    parser.add_argument("--pupil-oversample", type=int, default=None)
    parser.add_argument("--ap-diffuser-radius-mm", type=float, default=None)
    parser.add_argument("--ap-mask-radius-mm", type=float, default=None)
    parser.add_argument("--out-dir", type=str, default=None)
    parser.add_argument("--tmp-dir", type=str, default=None)
    parser.add_argument("--result-tag", type=str, default=None)
    parser.add_argument("--z-back-mm", type=float, default=None)
    parser.add_argument("--z-12-mm", type=float, default=None)
    parser.add_argument("--z-2m-mm", type=float, default=None)
    parser.add_argument("--L-pad-mm", type=float, default=None)
    parser.add_argument("--max-test-modes", type=int, default=None)
    parser.add_argument("--gpu-batch-size", type=int, default=None)
    return parser.parse_args()


def main():
    mp.set_start_method("spawn", force=True)

    config = PropagationConfig()
    args = parse_args()
    updates = {}
    arg_to_field = {
        "gsm_path": "gsm_path",
        "diffuser_file": "diffuser_file",
        "Lm_mm": "Lm_mm",
        "Ld_mm": "Ld_mm",
        "N_mid": "N_mid",
        "N_src": "N_src",
        "pupil_oversample": "pupil_oversample",
        "ap_diffuser_radius_mm": "ap_diffuser_radius_mm",
        "ap_mask_radius_mm": "ap_mask_radius_mm",
        "out_dir": "out_dir",
        "tmp_dir": "tmp_dir",
        "result_tag": "result_tag",
        "z_back_mm": "z_back_mm",
        "z_12_mm": "z_12_mm",
        "z_2m_mm": "z_2m_mm",
        "L_pad_mm": "L_pad_mm",
        "max_test_modes": "max_test_modes",
        "gpu_batch_size": "gpu_batch_size",
    }
    for arg_name, field_name in arg_to_field.items():
        value = getattr(args, arg_name)
        if value is not None:
            updates[field_name] = value
    if updates:
        config = replace(config, **updates)

    run_propagation(config)


if __name__ == "__main__":
    main()
