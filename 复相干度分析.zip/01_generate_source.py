import gc
import os
from dataclasses import dataclass, replace
import argparse

import numpy as np


@dataclass(frozen=True)
class SourceConfig:
    wavelength_mm: float = 550e-6
    f_mm: float = 10.0
    NA: float = 0.2

    Lm_mm: float = 0.5
    Ld_mm: float = 0.5
    N_mid: int = 1280
    N_src: int = 373

    sigma_c_mm: float = 0.05
    theta_x_deg: float = 0.0
    theta_y_deg: float = 0.0

    energy_threshold: float = 0.95
    max_modes_keep: int = 10000

    verbose: bool = True


def centered_coords(N, dx):
    return (np.arange(N) - (N - 1) / 2.0) * dx


def mode_number_at_energy(cum_energy, threshold):
    idx = np.searchsorted(cum_energy, threshold, side="left")
    return None if idx >= len(cum_energy) else idx + 1


def safe_tag(value):
    return str(value).replace(".", "p").replace("-", "m")


def make_source_filename(config):
    lm_tag = safe_tag(config.Lm_mm)
    sc_tag = safe_tag(config.sigma_c_mm)
    etag = f"E{int(round(config.energy_threshold * 100))}"
    tx_tag = safe_tag(config.theta_x_deg)
    ty_tag = safe_tag(config.theta_y_deg)
    return (
        f"uniform_angle_{config.N_src}_Lm{lm_tag}mm_c{sc_tag}_{etag}"
        f"_thetaX{tx_tag}_thetaY{ty_tag}_compact.npz"
    )


def gaussian_mutual_intensity_1d(x, sigma_c):
    if sigma_c <= 0:
        raise ValueError("sigma_c must be positive.")

    X1, X2 = np.meshgrid(x, x, indexing="ij")
    dX = X2 - X1
    J = np.exp(-(dX ** 2) / (2.0 * sigma_c ** 2))
    J = 0.5 * (J + J.T)
    return J.astype(np.float64)


def tilt_frequency(wavelength_mm, theta_deg):
    theta = np.deg2rad(theta_deg)
    return np.sin(theta) / wavelength_mm


def apply_tilt_phase(phi_1d, x, f0):
    phase = np.exp(-1j * 2.0 * np.pi * f0 * x)
    return (phi_1d * phase[:, None]).astype(np.complex64)


def eig_decompose_real_symmetric_cpu(J1d, dx, verbose=True):
    K = J1d * dx
    K = 0.5 * (K + K.T)

    if verbose:
        print("\nstart np.linalg.eigh: untilted Gaussian mutual intensity")

    eigvals, eigvecs = np.linalg.eigh(K)

    idx = np.argsort(eigvals)[::-1]
    eigvals = np.real(eigvals[idx])
    eigvecs = eigvecs[:, idx]

    max_eig = np.max(eigvals)
    min_eig = np.min(eigvals)
    n_neg = int(np.sum(eigvals < 0))

    if verbose:
        print(f"eig max = {max_eig:.6e}")
        print(f"eig min = {min_eig:.6e}")
        print(f"negative eig count = {n_neg}")
        if n_neg > 0 and max_eig > 0:
            print(f"min/max = {min_eig / max_eig:.6e}")

    eigvals = np.maximum(eigvals, 0.0)

    norms = np.sqrt(np.sum(np.abs(eigvecs) ** 2, axis=0) * dx)
    if np.any(norms <= 0):
        raise RuntimeError("Found zero-norm eigenvectors.")

    phi_1d = eigvecs / norms[None, :]
    return eigvals.astype(np.float64), phi_1d.astype(np.float32)


def build_source(config):
    dxs_mm = config.wavelength_mm * config.f_mm / config.Lm_mm
    x = centered_coords(config.N_src, dxs_mm)
    y = x.copy()

    Ls_grid_mm = config.N_src * dxs_mm
    theta_na = np.arcsin(config.NA)
    Ls_eff_mm = 2.0 * config.f_mm * np.tan(theta_na)
    Ns_eff = Ls_eff_mm / dxs_mm

    pad_left = (config.N_mid - config.N_src) // 2
    pad_right = config.N_mid - config.N_src - pad_left

    if config.N_src > config.N_mid:
        raise ValueError("N_src cannot be larger than N_mid.")
    if config.sigma_c_mm <= 0:
        raise ValueError("sigma_c_mm must be positive.")

    if config.verbose:
        print("========== source sampling ==========")
        print(f"wavelength = {config.wavelength_mm:.12e} mm")
        print(f"f = {config.f_mm:.6f} mm")
        print(f"NA = {config.NA}")
        print(f"N_src = {config.N_src}")
        print(f"N_mid = {config.N_mid}")
        print(f"dxs = {dxs_mm:.12e} mm = {dxs_mm * 1e3:.6f} um")
        print(f"source grid width = {Ls_grid_mm:.9f} mm")
        print(f"NA effective source size = {Ls_eff_mm:.9f} mm")
        print(f"NA effective sample count = {Ns_eff:.2f}")
        print(f"embed padding left/right = {pad_left}/{pad_right}")
        print(f"sigma_c_mm = {config.sigma_c_mm}")
        print(f"theta_x_deg = {config.theta_x_deg}")
        print(f"theta_y_deg = {config.theta_y_deg}")

    fx0 = tilt_frequency(config.wavelength_mm, config.theta_x_deg)
    fy0 = tilt_frequency(config.wavelength_mm, config.theta_y_deg)
    J0 = gaussian_mutual_intensity_1d(x, config.sigma_c_mm)

    if config.verbose:
        print("\n========== mutual intensity ==========")
        print("using one real untilted Gaussian eigendecomposition")
        print(f"fx0 = {fx0:.6e} cycles/mm")
        print(f"fy0 = {fy0:.6e} cycles/mm")
        print(
            "predicted mask shift x = "
            f"{config.f_mm * np.sin(np.deg2rad(config.theta_x_deg)):.6f} mm"
        )
        print(
            "predicted mask shift y = "
            f"{config.f_mm * np.sin(np.deg2rad(config.theta_y_deg)):.6f} mm"
        )
        print(f"J0.shape = {J0.shape}, memory = {J0.nbytes / 1024**3:.3f} GB")
        print(f"J0 symmetric err = {np.max(np.abs(J0 - J0.T)):.3e}")

    eigvals_1d_0, phi_1d_0 = eig_decompose_real_symmetric_cpu(
        J0, dxs_mm, verbose=config.verbose
    )
    eigvals_1d_x = eigvals_1d_0.copy()
    eigvals_1d_y = eigvals_1d_0.copy()
    phi_1d_x = apply_tilt_phase(phi_1d_0, x, fx0)
    phi_1d_y = apply_tilt_phase(phi_1d_0, y, fy0)

    del J0, phi_1d_0
    gc.collect()

    if eigvals_1d_x.size != eigvals_1d_y.size:
        raise RuntimeError("x/y direction 1D mode counts are inconsistent.")

    n1d = eigvals_1d_x.size
    sum1d_x = np.sum(eigvals_1d_x)
    sum1d_y = np.sum(eigvals_1d_y)

    if sum1d_x <= 0 or sum1d_y <= 0:
        raise RuntimeError("1D eigenvalue sum must be positive.")

    cum1d_x = np.cumsum(eigvals_1d_x) / sum1d_x
    cum1d_y = np.cumsum(eigvals_1d_y) / sum1d_y

    if config.verbose:
        print("\n========== 1D cumulative energy ==========")
        for th in [0.50, 0.70, 0.90, 0.95, 0.99]:
            nx = mode_number_at_energy(cum1d_x, th)
            ny = mode_number_at_energy(cum1d_y, th)
            print(f"{th * 100:.1f}% energy: x n = {nx}, y n = {ny}")

    lam2d = np.outer(eigvals_1d_x, eigvals_1d_y)
    lam2d = np.maximum(lam2d, 0.0)

    ii, jj = np.meshgrid(
        np.arange(n1d, dtype=np.int32),
        np.arange(n1d, dtype=np.int32),
        indexing="ij",
    )

    ii_flat = ii.ravel()
    jj_flat = jj.ravel()
    lam2d_flat = lam2d.ravel()

    M_available = lam2d_flat.size

    if config.verbose:
        print("\n========== 2D mode weights ==========")
        print(f"M_available = {M_available}")
        print(f"lam2d_flat memory = {lam2d_flat.nbytes / 1024**3:.3f} GB")
        print("sorting 2D eigenvalues...")

    order = np.argsort(lam2d_flat)[::-1]
    lam2d_sorted = lam2d_flat[order]
    ii_sorted = ii_flat[order]
    jj_sorted = jj_flat[order]

    del lam2d, lam2d_flat, ii, jj, ii_flat, jj_flat, order
    gc.collect()

    sum2d = np.sum(lam2d_sorted)
    if sum2d <= 0:
        raise RuntimeError("2D eigenvalue sum must be positive.")

    cum2d = np.cumsum(lam2d_sorted) / sum2d
    M_energy = mode_number_at_energy(cum2d, config.energy_threshold)
    if M_energy is None:
        M_energy = M_available

    M_keep = min(int(M_energy), int(config.max_modes_keep), M_available)
    M_keep = max(M_keep, 1)

    eigvals_2d_keep = lam2d_sorted[:M_keep].astype(np.float64)
    mode_pairs = np.column_stack([ii_sorted[:M_keep], jj_sorted[:M_keep]]).astype(np.int32)

    energy_actual = float(cum2d[M_keep - 1])
    energy_loss = 1.0 - energy_actual
    is_capped = int(M_energy) > int(config.max_modes_keep)

    if config.verbose:
        print("\n========== 2D mode selection ==========")
        print(f"energy_threshold = {config.energy_threshold}")
        print(f"M_energy = {M_energy}")
        print(f"max_modes_keep = {config.max_modes_keep}")
        print(f"M_keep = {M_keep}")
        print(f"is_capped = {is_capped}")
        print(f"energy_actual = {energy_actual:.12f}")
        print(f"energy_loss = {energy_loss:.6e}")
        if is_capped:
            print("WARNING: M_energy is larger than max_modes_keep.")

    del lam2d_sorted, ii_sorted, jj_sorted, cum2d
    gc.collect()

    meta = {
        "model": "Uniform intensity Schell-model source with tilted mutual intensity phase",
        "generation_method": "One real eigendecomposition of untilted Gaussian mutual intensity, then apply x/y tilt phases",
        "compact_save": True,
        "script_name": "01_generate_source.py",
        "wavelength_mm": float(config.wavelength_mm),
        "f_mm": float(config.f_mm),
        "NA": float(config.NA),
        "Lm_mm": float(config.Lm_mm),
        "Ld_mm": float(config.Ld_mm),
        "N_mid_for_propagation": int(config.N_mid),
        "N_src": int(config.N_src),
        "dx_mm": float(dxs_mm),
        "dy_mm": float(dxs_mm),
        "Ls_grid_mm": float(Ls_grid_mm),
        "Ls_eff_mm": float(Ls_eff_mm),
        "Ns_eff_estimated": float(Ns_eff),
        "embed_to_N_mid": True,
        "embed_pad_left": int(pad_left),
        "embed_pad_right": int(pad_right),
        "intensity_model": "uniform_inside_source_window",
        "sigma_c_mm": float(config.sigma_c_mm),
        "mutual_intensity_phase_model": "exp[i2pi(fx*(x2-x1)+fy*(y2-y1))]",
        "tilt_mode_relation": "phi_tilt(x) = phi_untilted(x) * exp[-i2pi*f0*x]",
        "theta_x_deg": float(config.theta_x_deg),
        "theta_y_deg": float(config.theta_y_deg),
        "fx0_cycles_per_mm": float(fx0),
        "fy0_cycles_per_mm": float(fy0),
        "predicted_mask_shift_x_mm": float(config.f_mm * np.sin(np.deg2rad(config.theta_x_deg))),
        "predicted_mask_shift_y_mm": float(config.f_mm * np.sin(np.deg2rad(config.theta_y_deg))),
        "n1d": int(n1d),
        "M_available": int(M_available),
        "selection_strategy": "energy_threshold_with_max_modes_cap",
        "energy_threshold": float(config.energy_threshold),
        "M_energy": int(M_energy),
        "max_modes_keep": int(config.max_modes_keep),
        "M_keep": int(M_keep),
        "is_capped_by_max_modes": bool(is_capped),
        "energy_actual_of_kept_modes": float(energy_actual),
        "energy_loss": float(energy_loss),
        "eigvals_1d_x_dtype": "float64",
        "eigvals_1d_y_dtype": "float64",
        "phi_1d_x_dtype": "complex64",
        "phi_1d_y_dtype": "complex64",
        "eigvals_2d_dtype": "float64",
        "mode_pairs_dtype": "int32",
        "saved_arrays": [
            "eigvals_1d_x",
            "eigvals_1d_y",
            "phi_1d_x",
            "phi_1d_y",
            "eigvals_2d",
            "mode_pairs",
            "cum_energy_1d_x",
            "cum_energy_1d_y",
            "x",
            "y",
            "dx",
            "dy",
            "meta",
        ],
    }

    return {
        "eigvals_1d_x": eigvals_1d_x.astype(np.float64),
        "eigvals_1d_y": eigvals_1d_y.astype(np.float64),
        "phi_1d_x": phi_1d_x.astype(np.complex64),
        "phi_1d_y": phi_1d_y.astype(np.complex64),
        "eigvals_2d": eigvals_2d_keep.astype(np.float64),
        "mode_pairs": mode_pairs.astype(np.int32),
        "cum_energy_1d_x": cum1d_x.astype(np.float64),
        "cum_energy_1d_y": cum1d_y.astype(np.float64),
        "x": x.astype(np.float64),
        "y": y.astype(np.float64),
        "dx": np.float64(dxs_mm),
        "dy": np.float64(dxs_mm),
        "meta": np.array([meta], dtype=object),
    }


def save_source(source_data, save_path):
    np.savez(save_path, **source_data)
    return os.path.getsize(save_path) / 1024**3


def parse_args():
    parser = argparse.ArgumentParser(description="Generate GSM source modes.")
    parser.add_argument("--Lm-mm", type=float, default=None)
    parser.add_argument("--Ld-mm", type=float, default=None)
    parser.add_argument("--N-mid", type=int, default=None)
    parser.add_argument("--N-src", type=int, default=None)
    parser.add_argument("--sigma-c-mm", type=float, default=None)
    parser.add_argument("--theta-x-deg", type=float, default=None)
    parser.add_argument("--theta-y-deg", type=float, default=None)
    parser.add_argument("--save-path", type=str, default=None)
    return parser.parse_args()


def main():
    config = SourceConfig()
    args = parse_args()
    updates = {}
    if args.Lm_mm is not None:
        updates["Lm_mm"] = args.Lm_mm
    if args.Ld_mm is not None:
        updates["Ld_mm"] = args.Ld_mm
    if args.N_mid is not None:
        updates["N_mid"] = args.N_mid
    if args.N_src is not None:
        updates["N_src"] = args.N_src
    if args.sigma_c_mm is not None:
        updates["sigma_c_mm"] = args.sigma_c_mm
    if args.theta_x_deg is not None:
        updates["theta_x_deg"] = args.theta_x_deg
    if args.theta_y_deg is not None:
        updates["theta_y_deg"] = args.theta_y_deg
    if updates:
        config = replace(config, **updates)

    save_path = args.save_path or make_source_filename(config)

    source_data = build_source(config)
    file_size_gb = save_source(source_data, save_path)

    meta = source_data["meta"][0]
    print("\n========== source saved ==========")
    print(f"save_path = {os.path.abspath(save_path)}")
    print(f"file_size = {file_size_gb:.3f} GB")
    print(f"M_energy = {meta['M_energy']}")
    print(f"M_keep = {meta['M_keep']}")
    print(f"energy_actual = {meta['energy_actual_of_kept_modes']:.12f}")
    print(f"is_capped = {meta['is_capped_by_max_modes']}")
    print(f"theta_x_deg = {meta['theta_x_deg']}")
    print(f"theta_y_deg = {meta['theta_y_deg']}")
    print(f"predicted_mask_shift_x_mm = {meta['predicted_mask_shift_x_mm']:.6f}")
    print(f"predicted_mask_shift_y_mm = {meta['predicted_mask_shift_y_mm']:.6f}")


if __name__ == "__main__":
    main()
