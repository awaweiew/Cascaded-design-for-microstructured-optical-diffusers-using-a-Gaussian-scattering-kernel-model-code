# 两个最新 diffuser 的复相干度分析（550 nm，n = 1.49）

本目录是独立计算副本，原始代码、JSON 和既有结果均不会被覆盖。计算对象为最新的单方向设计与双方向设计。

## 参数来源

- `configs/single_direction_best_config_snell.json`：单方向最终 Snell 设计，400 × 400 个微结构。
- `configs/dual_direction_best_config_snell_refined.json`：双方向最终 Snell 设计，60 × 60 个微结构。
- 两份 JSON 的来源校验值及公共光学参数记录在 `design_manifest.json`。
- 波长为 550 nm；传播程序中的 diffuser 折射率为 1.49。
- diffuser 表面输出分辨率保持 1280 × 1280，以匹配原复相干传播程序的 `N_mid`。



## 在计算服务器上运行

服务器需具备支持 CUDA 的 PyTorch、NumPy 和 Matplotlib。若 `python` 不指向所需环境，可先设置环境变量 `DIFFUSER_PYTHON` 为 Python 可执行文件的完整路径，然后执行：

```powershell
powershell -ExecutionPolicy Bypass -File .\run_pipeline.ps1
```

也可只生成两块 diffuser：

```powershell
python .\02_generate_diffuser.py
```

脚本依次输出到 `diffusers`，传播统计写入 `stats`，期刊绘图写入 `figures`。临时目录按设计分别命名，避免结果交叉覆盖。

## JSON 读取与随机实现说明

最终几何与分布参数直接来自 JSON。随机实现仍沿用原 Python 程序的 `numpy.random.default_rng(seed)`；因此在相同 Python/NumPy 环境下可重复，但它与 MATLAB 随机数发生器不保证逐点一致。该差异不改变指定的参数分布或表面生成公式。

