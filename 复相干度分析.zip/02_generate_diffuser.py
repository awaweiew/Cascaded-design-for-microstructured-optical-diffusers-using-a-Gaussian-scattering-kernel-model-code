import gc
import hashlib
import json
import os
import shutil
from dataclasses import dataclass, field, replace
import argparse
from pathlib import Path

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"

import multiprocessing as mp

import numpy as np
import torch


@dataclass(frozen=True)
class DiffuserConfig:
    Lx_mm: float = 0.5
    Ly_mm: float = 0.5
    resx: int = 1280
    resy: int = 1280

    caps_per_axis: int = 60

    # 凹深 h 的截断 Beta 分布，与 MATLAB 模型一致
    h_min_mm: float = 0.018
    h_max_mm: float = 0.030
    h_beta_alpha: float = 1.22
    h_beta_beta: float = 4.48

    # 宽深比 ka 的截断 Beta 分布，与 MATLAB 模型一致
    ka_min: float = 0.60
    ka_max: float = 0.85
    ka_beta_alpha: float = 1.62
    ka_beta_beta: float = 2.05

    kb: float = 0.6

    pos_jitter_frac: float = 0.4
    rot_jitter_rad: float = np.pi
    is_convex: bool = False
    smooth_k: float = 2500.0
    seed: int = 1

    # 仅用于记录 JSON 设计来源；不参与表面模型的数学计算。
    design_name: str = "design"
    source_json: str = ""
    n_substrate: float = 1.49

    gpu_ids: list[int] = field(default_factory=lambda: list(range(8)))
    tmp_dir: str = "tmp_diffuser_parts"
    keep_temp_files: bool = False
    verbose: bool = True


def safe_tag(value):
    return str(value).replace(".", "p").replace("-", "m")


def make_diffuser_filename(config):
    size_tag = safe_tag(config.Lx_mm)
    h_range_tag = f"{safe_tag(config.h_min_mm)}to{safe_tag(config.h_max_mm)}"
    h_beta_tag = f"{safe_tag(config.h_beta_alpha)}x{safe_tag(config.h_beta_beta)}"
    ka_range_tag = f"{safe_tag(config.ka_min)}to{safe_tag(config.ka_max)}"
    ka_beta_tag = f"{safe_tag(config.ka_beta_alpha)}x{safe_tag(config.ka_beta_beta)}"
    kb_tag = safe_tag(config.kb)
    return (
        f"diffuser_{config.design_name}_{size_tag}mm_res{config.resx}_N{config.caps_per_axis}"
        f"_h{h_range_tag}_bh{h_beta_tag}"
        f"_ka{ka_range_tag}_bka{ka_beta_tag}"
        f"_kb{kb_tag}_seed{config.seed}.npz"
    )


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_config_from_json(json_path, base_config=None, design_name=None):
    """Map a finalized optimization JSON directly to the unchanged cap model."""
    json_path = Path(json_path).resolve()
    with json_path.open("r", encoding="utf-8-sig") as stream:
        data = json.load(stream)

    geometry = data["geometry"]
    height = data["height"]
    aspect_ka = data["aspectKa"]
    numerical = data["numerical"]
    random_cfg = data["random"]
    optical = data["optical"]

    nx = int(geometry["Nx"])
    ny = int(geometry["Ny"])
    if nx != ny:
        raise ValueError(
            "The current propagation-compatible generator requires geometry.Nx "
            f"to equal geometry.Ny, but received Nx={nx}, Ny={ny}."
        )

    config = base_config or DiffuserConfig()
    name = design_name or json_path.stem
    return replace(
        config,
        Lx_mm=float(geometry["Lx"]),
        Ly_mm=float(geometry["Ly"]),
        caps_per_axis=nx,
        h_min_mm=float(height["minimum"]),
        h_max_mm=float(height["maximum"]),
        h_beta_alpha=float(height["alpha"]),
        h_beta_beta=float(height["beta"]),
        ka_min=float(aspect_ka["minimum"]),
        ka_max=float(aspect_ka["maximum"]),
        ka_beta_alpha=float(aspect_ka["alpha"]),
        ka_beta_beta=float(aspect_ka["beta"]),
        kb=float(geometry["kb"]),
        pos_jitter_frac=float(geometry["positionJitterFraction"]),
        rot_jitter_rad=float(geometry["rotationRange"]),
        smooth_k=float(numerical["softMinK"]),
        seed=int(random_cfg["seed"]),
        design_name=name,
        source_json=str(json_path),
        n_substrate=float(optical["nSubstrate"]),
    )


def validate_config(config):
    if config.Lx_mm <= 0 or config.Ly_mm <= 0:
        raise ValueError("Diffuser size must be positive.")
    if config.resx <= 1 or config.resy <= 1:
        raise ValueError("resx/resy must be larger than 1.")
    if config.caps_per_axis <= 0:
        raise ValueError("caps_per_axis must be positive.")

    if config.h_min_mm <= 0 or config.h_max_mm <= 0:
        raise ValueError("height range must be positive.")
    if config.h_min_mm > config.h_max_mm:
        raise ValueError("h_min_mm cannot be larger than h_max_mm.")

    if config.h_beta_alpha <= 0 or config.h_beta_beta <= 0:
        raise ValueError("height beta distribution parameters must be positive.")
    if config.ka_min <= 0 or config.ka_max <= 0:
        raise ValueError("ka range must be positive.")
    if config.ka_min > config.ka_max:
        raise ValueError("ka_min cannot be larger than ka_max.")
    if config.ka_beta_alpha <= 0 or config.ka_beta_beta <= 0:
        raise ValueError("ka beta distribution parameters must be positive.")
    if config.kb <= 0:
        raise ValueError("kb must be positive.")
    if config.pos_jitter_frac < 0:
        raise ValueError("pos_jitter_frac cannot be negative.")
    if config.smooth_k <= 0:
        raise ValueError("smooth_k must be positive.")
    if not np.isclose(config.n_substrate, 1.49, rtol=0.0, atol=1e-12):
        raise ValueError(
            f"The requested substrate index is 1.49, but JSON contains {config.n_substrate}."
        )


def generate_cap_params(config):
    rng = np.random.default_rng(config.seed)

    N = config.caps_per_axis
    px = config.Lx_mm / N
    py = config.Ly_mm / N

    cx_base = np.linspace(px / 2, config.Lx_mm - px / 2, N)
    cy_base = np.linspace(py / 2, config.Ly_mm - py / 2, N)

    jx_max = (px / 2) * config.pos_jitter_frac
    jy_max = (py / 2) * config.pos_jitter_frac

    M = N * N

    cx_all = np.zeros(M, dtype=np.float32)
    cy_all = np.zeros(M, dtype=np.float32)
    h_all = np.zeros(M, dtype=np.float32)
    ka_all = np.zeros(M, dtype=np.float32)
    theta_all = np.zeros(M, dtype=np.float32)

    idx = 0
    for i in range(N):
        for j in range(N):
            cx0 = cx_base[i]
            cy0 = cy_base[j]

            dx_jit = (2.0 * rng.random() - 1.0) * jx_max
            dy_jit = (2.0 * rng.random() - 1.0) * jy_max

            cx = np.clip(cx0 + dx_jit, px / 2, config.Lx_mm - px / 2)
            cy = np.clip(cy0 + dy_jit, py / 2, config.Ly_mm - py / 2)

            # 与 MATLAB 一致：分别独立抽样凹深 h 和宽深比 ka，
            # 再由 a = ka * h、b = kb * a 确定横向尺度。
            u_h = rng.beta(config.h_beta_alpha, config.h_beta_beta)
            h = config.h_min_mm + (config.h_max_mm - config.h_min_mm) * u_h

            u_ka = rng.beta(config.ka_beta_alpha, config.ka_beta_beta)
            ka = config.ka_min + (config.ka_max - config.ka_min) * u_ka

            theta = rng.random() * config.rot_jitter_rad

            cx_all[idx] = cx
            cy_all[idx] = cy
            h_all[idx] = h
            ka_all[idx] = ka
            theta_all[idx] = theta

            idx += 1

    return cx_all, cy_all, h_all, ka_all, theta_all


def worker_generate_partial(
    gpu_id,
    cap_indices,
    cx_all,
    cy_all,
    h_all,
    ka_all,
    theta_all,
    config,
    result_path,
):
    torch.cuda.set_device(gpu_id)
    device = torch.device(f"cuda:{gpu_id}")

    dx_grid = config.Lx_mm / (config.resx - 1)
    dy_grid = config.Ly_mm / (config.resy - 1)

    x_gpu = torch.linspace(0.0, config.Lx_mm, config.resx, device=device, dtype=torch.float32)
    y_gpu = torch.linspace(0.0, config.Ly_mm, config.resy, device=device, dtype=torch.float32)

    log_acc = torch.full(
        (config.resy, config.resx),
        -float("inf"),
        device=device,
        dtype=torch.float32,
    )

    k = torch.tensor(config.smooth_k, device=device, dtype=torch.float32)

    def update_one_cap(cx, cy, h, ka, theta):
        nonlocal log_acc

        # 长、短半轴由随机凹深和随机宽深比共同确定。
        a = ka * h
        b = config.kb * a
        r = a

        ix0 = max(0, int(np.floor((cx - r) / dx_grid)) - 2)
        ix1 = min(config.resx - 1, int(np.ceil((cx + r) / dx_grid)) + 2)
        iy0 = max(0, int(np.floor((cy - r) / dy_grid)) - 2)
        iy1 = min(config.resy - 1, int(np.ceil((cy + r) / dy_grid)) + 2)

        xs = x_gpu[ix0:ix1 + 1]
        ys = y_gpu[iy0:iy1 + 1]
        Ys, Xs = torch.meshgrid(ys, xs, indexing="ij")

        dx = Xs - cx
        dy = Ys - cy

        ct = np.cos(theta)
        st = np.sin(theta)

        xp = ct * dx + st * dy
        yp = -st * dx + ct * dy

        r2 = (xp / a) ** 2 + (yp / b) ** 2
        inside = r2 <= 1.0

        cap = torch.full_like(r2, -float("inf"))
        cap[inside] = k * h * torch.sqrt(torch.clamp(1.0 - r2[inside], min=0.0))

        old = log_acc[iy0:iy1 + 1, ix0:ix1 + 1]
        log_acc[iy0:iy1 + 1, ix0:ix1 + 1] = torch.logaddexp(old, cap)

    total = len(cap_indices)
    if config.verbose:
        print(f"[GPU {gpu_id}] start {total} caps")

    with torch.no_grad():
        for n, idx in enumerate(cap_indices):
            update_one_cap(
                float(cx_all[idx]),
                float(cy_all[idx]),
                float(h_all[idx]),
                float(ka_all[idx]),
                float(theta_all[idx]),
            )

            if config.verbose and ((n + 1) % 500 == 0 or (n + 1) == total):
                torch.cuda.synchronize(device)
                print(f"[GPU {gpu_id}] done {n + 1}/{total}")

    torch.cuda.synchronize(device)

    partial = log_acc.cpu().numpy().astype(np.float32)
    np.save(result_path, partial)

    if config.verbose:
        print(f"[GPU {gpu_id}] saved partial: {result_path}")


def merge_partials(gpu_ids_use, config):
    log_acc_total = np.full((config.resy, config.resx), -np.inf, dtype=np.float32)

    for gpu_id in gpu_ids_use:
        path = os.path.join(config.tmp_dir, f"partial_logacc_gpu{gpu_id}.npy")
        partial = np.load(path)
        log_acc_total = np.logaddexp(log_acc_total, partial).astype(np.float32)
        if config.verbose:
            print(f"merged GPU {gpu_id}")

    depth = np.logaddexp(0.0, log_acc_total).astype(np.float32) / np.float32(config.smooth_k)
    Z_final = depth if config.is_convex else -depth
    return Z_final.astype(np.float32)


def build_meta(config, gpu_ids_use, h_all, ka_all):
    M = config.caps_per_axis * config.caps_per_axis
    a_all = h_all * ka_all
    return {
        "script_name": "02_generate_diffuser.py",
        "design_name": config.design_name,
        "source_json": config.source_json,
        "source_json_sha256": file_sha256(config.source_json),
        "model": "smooth maximum of randomized ellipsoidal caps",
        "Lx_mm": float(config.Lx_mm),
        "Ly_mm": float(config.Ly_mm),
        "resx": int(config.resx),
        "resy": int(config.resy),
        "caps_per_axis": int(config.caps_per_axis),
        "M_caps": int(M),

        "h_min_mm": float(config.h_min_mm),
        "h_max_mm": float(config.h_max_mm),
        "h_beta_alpha": float(config.h_beta_alpha),
        "h_beta_beta": float(config.h_beta_beta),
        "h_min_actual_mm": float(np.min(h_all)),
        "h_max_actual_mm": float(np.max(h_all)),
        "h_mean_actual_mm": float(np.mean(h_all)),

        "ka_min": float(config.ka_min),
        "ka_max": float(config.ka_max),
        "ka_beta_alpha": float(config.ka_beta_alpha),
        "ka_beta_beta": float(config.ka_beta_beta),
        "ka_min_actual": float(np.min(ka_all)),
        "ka_max_actual": float(np.max(ka_all)),
        "ka_mean_actual": float(np.mean(ka_all)),

        "a_min_actual_mm": float(np.min(a_all)),
        "a_max_actual_mm": float(np.max(a_all)),
        "a_mean_actual_mm": float(np.mean(a_all)),
        "kb": float(config.kb),

        "h_definition": (
            "h = h_min_mm + (h_max_mm - h_min_mm) "
            "* Beta(h_beta_alpha, h_beta_beta)"
        ),
        "ka_definition": (
            "ka = ka_min + (ka_max - ka_min) "
            "* Beta(ka_beta_alpha, ka_beta_beta)"
        ),
        "a_definition": "a = ka * h",
        "b_definition": "b = kb * a",

        "pos_jitter_frac": float(config.pos_jitter_frac),
        "rot_jitter_rad": float(config.rot_jitter_rad),
        "is_convex": bool(config.is_convex),
        "smooth_k": float(config.smooth_k),
        "seed": int(config.seed),
        "wavelength_mm_for_following_propagation": 550e-6,
        "n_substrate_for_following_propagation": float(config.n_substrate),
        "gpu_ids": list(gpu_ids_use),
    }


def save_diffuser(save_name, Z_final, cx_all, cy_all, h_all, ka_all, theta_all, meta):
    np.savez(
        save_name,
        Z_final=Z_final.astype(np.float32),
        h_all=h_all.astype(np.float32),
        ka_all=ka_all.astype(np.float32),
        cx_all=cx_all.astype(np.float32),
        cy_all=cy_all.astype(np.float32),
        theta_all=theta_all.astype(np.float32),
        meta=np.array([meta], dtype=object),
    )
    return os.path.getsize(save_name) / 1024**3


def generate_diffuser(config):
    validate_config(config)
    os.makedirs(config.tmp_dir, exist_ok=True)

    if not torch.cuda.is_available():
        raise RuntimeError("PyTorch did not detect CUDA GPU.")

    n_gpu = torch.cuda.device_count()
    gpu_ids_use = [g for g in config.gpu_ids if g < n_gpu]

    if len(gpu_ids_use) == 0:
        raise RuntimeError("No usable GPU found.")

    if config.verbose:
        print("========== diffuser config ==========")
        print(f"GPU count detected = {n_gpu}")
        print(f"GPUs used = {gpu_ids_use}")
        print(f"Lx/Ly = {config.Lx_mm}/{config.Ly_mm} mm")
        print(f"resx/resy = {config.resx}/{config.resy}")
        print(f"caps_per_axis = {config.caps_per_axis}")
        print(f"h range = {config.h_min_mm} ~ {config.h_max_mm} mm")
        print(
            "h beta(alpha, beta) = "
            f"({config.h_beta_alpha}, {config.h_beta_beta})"
        )
        print(f"ka range = {config.ka_min} ~ {config.ka_max}")
        print(
            "ka beta(alpha, beta) = "
            f"({config.ka_beta_alpha}, {config.ka_beta_beta})"
        )
        print(f"kb = {config.kb}")
        print(f"seed = {config.seed}")

    cx_all, cy_all, h_all, ka_all, theta_all = generate_cap_params(config)

    M = config.caps_per_axis * config.caps_per_axis
    all_indices = np.arange(M)
    chunks = np.array_split(all_indices, len(gpu_ids_use))

    if config.verbose:
        print("========== task split ==========")
        for gpu_id, chunk in zip(gpu_ids_use, chunks):
            print(f"GPU {gpu_id}: {len(chunk)} caps")

    procs = []

    for gpu_id, chunk in zip(gpu_ids_use, chunks):
        result_path = os.path.join(config.tmp_dir, f"partial_logacc_gpu{gpu_id}.npy")
        p = mp.Process(
            target=worker_generate_partial,
            args=(gpu_id, chunk, cx_all, cy_all, h_all, ka_all, theta_all, config, result_path),
        )
        p.start()
        procs.append(p)

    for p in procs:
        p.join()

    for p in procs:
        if p.exitcode != 0:
            raise RuntimeError(f"A GPU subprocess failed, exitcode={p.exitcode}")

    if config.verbose:
        print("========== merging GPU partials ==========")

    Z_final = merge_partials(gpu_ids_use, config)
    meta = build_meta(config, gpu_ids_use, h_all, ka_all)

    if not config.keep_temp_files:
        shutil.rmtree(config.tmp_dir, ignore_errors=True)

    gc.collect()

    return Z_final, cx_all, cy_all, h_all, ka_all, theta_all, meta


def parse_args():
    parser = argparse.ArgumentParser(
        description="Generate one or both diffuser surfaces from finalized optimization JSON files."
    )
    parser.add_argument(
        "--config-json",
        action="append",
        default=None,
        help="Finalized design JSON. Repeat this option to generate multiple designs.",
    )
    parser.add_argument(
        "--design-name",
        action="append",
        default=None,
        help="Optional output tag paired by position with --config-json.",
    )
    parser.add_argument("--Lx-mm", type=float, default=None)
    parser.add_argument("--Ly-mm", type=float, default=None)
    parser.add_argument("--resx", type=int, default=None)
    parser.add_argument("--resy", type=int, default=None)
    parser.add_argument("--caps-per-axis", type=int, default=None)
    parser.add_argument("--h-min-mm", type=float, default=None)
    parser.add_argument("--h-max-mm", type=float, default=None)
    parser.add_argument("--h-beta-alpha", type=float, default=None)
    parser.add_argument("--h-beta-beta", type=float, default=None)
    parser.add_argument("--ka-min", type=float, default=None)
    parser.add_argument("--ka-max", type=float, default=None)
    parser.add_argument("--ka-beta-alpha", type=float, default=None)
    parser.add_argument("--ka-beta-beta", type=float, default=None)
    parser.add_argument("--kb", type=float, default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--save-name", type=str, default=None)
    return parser.parse_args()


def main():
    mp.set_start_method("spawn", force=True)

    args = parse_args()
    updates = {}

    if args.Lx_mm is not None:
        updates["Lx_mm"] = args.Lx_mm
    if args.Ly_mm is not None:
        updates["Ly_mm"] = args.Ly_mm
    if args.resx is not None:
        updates["resx"] = args.resx
    if args.resy is not None:
        updates["resy"] = args.resy
    if args.caps_per_axis is not None:
        updates["caps_per_axis"] = args.caps_per_axis
    if args.h_min_mm is not None:
        updates["h_min_mm"] = args.h_min_mm
    if args.h_max_mm is not None:
        updates["h_max_mm"] = args.h_max_mm
    if args.h_beta_alpha is not None:
        updates["h_beta_alpha"] = args.h_beta_alpha
    if args.h_beta_beta is not None:
        updates["h_beta_beta"] = args.h_beta_beta
    if args.ka_min is not None:
        updates["ka_min"] = args.ka_min
    if args.ka_max is not None:
        updates["ka_max"] = args.ka_max
    if args.ka_beta_alpha is not None:
        updates["ka_beta_alpha"] = args.ka_beta_alpha
    if args.ka_beta_beta is not None:
        updates["ka_beta_beta"] = args.ka_beta_beta
    if args.kb is not None:
        updates["kb"] = args.kb
    if args.seed is not None:
        updates["seed"] = args.seed

    script_dir = Path(__file__).resolve().parent
    json_paths = args.config_json or [
        str(script_dir / "configs" / "single_direction_best_config_snell.json"),
        str(script_dir / "configs" / "dual_direction_best_config_snell_refined.json"),
    ]
    default_names = ["single_direction", "dual_direction"]
    design_names = args.design_name or default_names[:len(json_paths)]
    if len(design_names) != len(json_paths):
        raise ValueError("--design-name must be supplied once per --config-json.")
    if args.save_name is not None and len(json_paths) != 1:
        raise ValueError("--save-name can only be used when exactly one JSON is supplied.")

    for json_path, design_name in zip(json_paths, design_names):
        config = load_config_from_json(
            json_path,
            base_config=DiffuserConfig(),
            design_name=design_name,
        )
        if updates:
            config = replace(config, **updates)
        config = replace(
            config,
            tmp_dir=str(script_dir / f"tmp_diffuser_parts_{design_name}"),
        )
        save_name = args.save_name or str(
            script_dir / "diffusers" / make_diffuser_filename(config)
        )
        os.makedirs(os.path.dirname(os.path.abspath(save_name)), exist_ok=True)

        Z_final, cx_all, cy_all, h_all, ka_all, theta_all, meta = generate_diffuser(config)
        file_size_gb = save_diffuser(
            save_name, Z_final, cx_all, cy_all, h_all, ka_all, theta_all, meta
        )

        print("\n========== diffuser saved ==========")
        print(f"design_name = {config.design_name}")
        print(f"source_json = {config.source_json}")
        print(f"save_name = {os.path.abspath(save_name)}")
        print(f"file_size = {file_size_gb:.3f} GB")
        print(f"Z_final.shape = {Z_final.shape}")
        print(f"Z_final dtype = {Z_final.dtype}")
        print(f"Z range = {Z_final.min() * 1e3:.6f} ~ {Z_final.max() * 1e3:.6f} um")
        print(f"h min = {h_all.min() * 1e3:.6f} um")
        print(f"h max = {h_all.max() * 1e3:.6f} um")
        print(f"h mean = {h_all.mean() * 1e3:.6f} um")
        print(f"ka min = {ka_all.min():.6f}")
        print(f"ka max = {ka_all.max():.6f}")
        print(f"ka mean = {ka_all.mean():.6f}")
        print(f"kb = {config.kb}")


if __name__ == "__main__":
    main()
