% Run Snell coordinate optimization.
function result = run_snell_coordinate_optimization(userControl)

if nargin < 1 || isempty(userControl)
    userControl = struct();
end

% Point to the saved configuration from a previous coordinate optimization.
defaults.bestConfigJsonPath = fullfile(fileparts(mfilename('fullpath')), ...
    'results','20260922_165713','best_config.json');

defaults.rayCount = 1e7;

defaults.rayChunkSize = 2.5e5;

defaults.raySamplingMode = 'random';
defaults.rayRandomSeed = 104729;

defaults.surfaceResolutionX = [];
defaults.surfaceResolutionY = [];

defaults.angularSmoothingSigmaBins = 0;

defaults.startScale = [];
defaults.scaleLowerBound = [];
defaults.scaleUpperBound = [];
defaults.coarseStep = [];
defaults.fineStep = [];
defaults.maximumEvaluations = [];
defaults.noImprovementPatience = [];

defaults.createFigures = true;
defaults.saveMatFile = true;
defaults.saveAngularCsv = true;
defaults.outputRootDirectory = '';

control = merge_control_local(defaults,userControl);
validate_control_local(control);

assert(isfile(control.bestConfigJsonPath), ...
    'best_config.json not found: %s',control.bestConfigJsonPath);
bestConfig = jsondecode(fileread(control.bestConfigJsonPath));

resultDirectory = fileparts(control.bestConfigJsonPath);
optimizationResultRoot = fileparts(resultDirectory);
modelDirectory = fileparts(optimizationResultRoot);
addpath(modelDirectory);

requiredFunctions = { ...
    'validate_diffuser_config','build_common_random_bank', ...
    'generate_diffuser_surface','refract_vectors_snell', ...
    'measure_scattering_fwhm'};
for functionIndex = 1:numel(requiredFunctions)
    assert(exist(requiredFunctions{functionIndex},'file') == 2, ...
        'Missing required function %s.m; run this file from the coordinate-optimization directory.', ...
        requiredFunctions{functionIndex});
end

[baseKaMinimum,baseKaMaximum,savedScale,parameterDefaults] = ...
    read_ka_defaults_local(bestConfig);
control = fill_search_defaults_local(control,savedScale,parameterDefaults);

if isempty(control.surfaceResolutionX)
    control.surfaceResolutionX = bestConfig.numerical.resolutionX;
end
if isempty(control.surfaceResolutionY)
    control.surfaceResolutionY = bestConfig.numerical.resolutionY;
end

templateConfig = bestConfig;
templateConfig.numerical.resolutionX = control.surfaceResolutionX;
templateConfig.numerical.resolutionY = control.surfaceResolutionY;
templateConfig.numerical.returnCoverageMask = false;
templateConfig.optimization.baseAspectKaMinimum = baseKaMinimum;
templateConfig.optimization.baseAspectKaMaximum = baseKaMaximum;
validate_diffuser_config(templateConfig);

geometryRandomBank = build_common_random_bank(templateConfig);

if isempty(control.outputRootDirectory)
    control.outputRootDirectory = fullfile(modelDirectory,'Snellresults');
end
timeStamp = char(datetime('now','Format','yyyyMMdd_HHmmss'));
outputDirectory = fullfile(control.outputRootDirectory,timeStamp);
if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end

fprintf('\n============================================================\n');
fprintf('Snell ray-tracing kaScale coordinate optimization\n');
fprintf('Input configuration: %s\n',control.bestConfigJsonPath);
fprintf('Initial kaScale: %.9g\n',control.startScale);
fprintf('Base k_a range: [%.9g, %.9g]\n',baseKaMinimum,baseKaMaximum);
fprintf('Ray count: %.0f; chunk size: %.0f; sampling: %s\n', ...
    control.rayCount,control.rayChunkSize,control.raySamplingMode);
fprintf('Surface grid: %d x %d\n', ...
    control.surfaceResolutionX,control.surfaceResolutionY);
fprintf('Target: %s FWHM = %.6f +/- %.6f deg\n', ...
    bestConfig.target.metric,bestConfig.target.fwhmDegree, ...
    bestConfig.target.angleToleranceDegree);
fprintf('Output directory: %s\n',outputDirectory);
fprintf('============================================================\n');

context.templateConfig = templateConfig;
context.geometryRandomBank = geometryRandomBank;
context.baseKaMinimum = baseKaMinimum;
context.baseKaMaximum = baseKaMaximum;
context.control = control;

searchResult = search_scale_local(context);
bestScale = searchResult.bestScale;
bestEvaluation = searchResult.bestEvaluation;
bestSnellConfig = apply_scale_local( ...
    templateConfig,baseKaMinimum,baseKaMaximum,bestScale);

historyTable = struct2table(searchResult.history,'AsArray',true);
writetable(historyTable,fullfile(outputDirectory,'snell_optimization_history.csv'));

summaryTable = table( ...
    control.startScale,bestScale, ...
    baseKaMinimum*bestScale,baseKaMaximum*bestScale, ...
    bestEvaluation.metrics.primaryFwhmDegree, ...
    bestEvaluation.metrics.absoluteErrorDegree, ...
    bestEvaluation.metrics.withinTolerance, ...
    string(searchResult.stopReason), ...
    'VariableNames',{ ...
    'startScale','bestScale','bestKaMinimum','bestKaMaximum', ...
    'primaryFwhmDegree','absoluteErrorDegree','withinTolerance','stopReason'});
writetable(summaryTable,fullfile(outputDirectory,'snell_parameter_summary.csv'));

write_json_local(fullfile(outputDirectory,'best_config_snell.json'),bestSnellConfig);

if control.saveAngularCsv
    writematrix(bestEvaluation.angularDistribution.normalized, ...
        fullfile(outputDirectory,'snell_final_angular_distribution_normalized.csv'));
end

if control.saveMatFile
    save(fullfile(outputDirectory,'complete_snell_optimization_result.mat'), ...
        'bestSnellConfig','bestEvaluation','searchResult','control', ...
        'outputDirectory','-v7.3');
end

if control.createFigures
    plot_results_local(bestEvaluation,searchResult,bestSnellConfig,outputDirectory);
end

result.bestConfig = bestSnellConfig;
result.bestEvaluation = bestEvaluation;
result.searchResult = searchResult;
result.control = control;
result.outputDirectory = outputDirectory;

fprintf('\nSnell optimization complete.\n');
fprintf('Best kaScale: %.9g\n',bestScale);
fprintf('Best k_a range: [%.9g, %.9g]\n', ...
    bestSnellConfig.aspectKa.minimum,bestSnellConfig.aspectKa.maximum);
fprintf('Primary FWHM: %.6f deg\n',bestEvaluation.metrics.primaryFwhmDegree);
fprintf('Absolute target error: %.6f deg\n',bestEvaluation.metrics.absoluteErrorDegree);
fprintf('Stop reason: %s\n',searchResult.stopReason);
fprintf('Results directory: %s\n',outputDirectory);
end

function searchResult = search_scale_local(context)
control = context.control;
history = repmat(empty_record_local(),0,1);
evaluationCache = containers.Map('KeyType','char','ValueType','any');
stopReason = 'maximum_evaluations';

currentRecord = evaluate_at_local(control.startScale,'initial');
bestRecord = currentRecord;
bestEvaluation = get_cached_evaluation_local(control.startScale);

if currentRecord.withinTolerance
    stopReason = 'target_tolerance_reached_at_initial_value';
    finish_local();
    return;
end

probeValues = [ ...
    control.startScale-control.coarseStep, ...
    control.startScale+control.coarseStep];
probeValues = probeValues( ...
    probeValues >= control.scaleLowerBound-10*eps & ...
    probeValues <= control.scaleUpperBound+10*eps);

probeRecords = repmat(empty_record_local(),0,1);
bracketFound = false;
bracketFirst = empty_record_local();
bracketSecond = empty_record_local();

for probeIndex = 1:numel(probeValues)
    if numel(history) >= control.maximumEvaluations
        break;
    end
    probeRecord = evaluate_at_local(probeValues(probeIndex),'direction_probe');
    probeRecords(end+1,1) = probeRecord; %#ok<AGROW>
    update_best_local(probeRecord);

    if probeRecord.withinTolerance
        stopReason = 'target_tolerance_reached_during_direction_probe';
        finish_local();
        return;
    end
    if crosses_target_local(currentRecord,probeRecord)
        bracketFound = true;
        bracketFirst = currentRecord;
        bracketSecond = probeRecord;
        break;
    end
end

if bracketFound
    refine_bracket_local(bracketFirst,bracketSecond);
    if bestRecord.withinTolerance
        stopReason = 'target_tolerance_reached_during_refinement';
    else
        stopReason = 'target_bracket_refined_to_parameter_resolution';
    end
    finish_local();
    return;
end

if isempty(probeRecords)
    stopReason = 'initial_value_is_at_both_boundaries';
    finish_local();
    return;
end

[bestProbeObjective,bestProbeIndex] = min([probeRecords.objectiveDegree]);
if ~(bestProbeObjective < currentRecord.objectiveDegree)
    stopReason = 'no_improving_search_direction';
    finish_local();
    return;
end

selectedProbe = probeRecords(bestProbeIndex);
searchDirection = sign(selectedProbe.scale-currentRecord.scale);
previousRecord = selectedProbe;
noImprovementCount = 0;

while numel(history) < control.maximumEvaluations
    nextScale = previousRecord.scale+searchDirection*control.coarseStep;
    if nextScale < control.scaleLowerBound-10*eps || ...
       nextScale > control.scaleUpperBound+10*eps
        stopReason = 'parameter_boundary_reached';
        break;
    end

    nextRecord = evaluate_at_local(nextScale,'coarse_traversal');
    oldBestObjective = bestRecord.objectiveDegree;
    update_best_local(nextRecord);

    if nextRecord.withinTolerance
        stopReason = 'target_tolerance_reached_during_coarse_traversal';
        break;
    end

    if crosses_target_local(previousRecord,nextRecord)
        refine_bracket_local(previousRecord,nextRecord);
        if bestRecord.withinTolerance
            stopReason = 'target_tolerance_reached_during_refinement';
        else
            stopReason = 'target_bracket_refined_to_parameter_resolution';
        end
        break;
    end

    if bestRecord.objectiveDegree < oldBestObjective
        noImprovementCount = 0;
    else
        noImprovementCount = noImprovementCount+1;
    end
    if noImprovementCount >= control.noImprovementPatience
        stopReason = 'no_improvement_patience_reached';
        break;
    end
    previousRecord = nextRecord;
end

finish_local();

    function record = evaluate_at_local(scale,phase)
        scale = min(max(scale,control.scaleLowerBound),control.scaleUpperBound);
        key = scale_key_local(scale);
        fromCache = isKey(evaluationCache,key);
        if fromCache
            evaluation = evaluationCache(key);
        else
            try
                evaluation = evaluate_scale_snell_local(context,scale);
            catch exception
                evaluation = invalid_evaluation_local(exception.message);
            end
            evaluationCache(key) = evaluation;
        end
        record = record_from_evaluation_local(evaluation,scale,phase,fromCache);
        history(end+1,1) = record;

        fprintf(['[%02d] %-18s scale=%9.6f, FWHM=%10.6f deg, ', ...
            '|error|=%9.6f deg, valid rays=%d, time=%.2f s%s\n'], ...
            numel(history),phase,scale,record.primaryFwhmDegree, ...
            record.objectiveDegree,record.validRayCount, ...
            record.elapsedSecond,ternary_local(fromCache,' [cache]',''));
    end

    function evaluation = get_cached_evaluation_local(scale)
        evaluation = evaluationCache(scale_key_local(scale));
    end

    function update_best_local(candidateRecord)
        if candidateRecord.objectiveDegree < bestRecord.objectiveDegree
            bestRecord = candidateRecord;
            bestEvaluation = get_cached_evaluation_local(candidateRecord.scale);
        end
    end

    function refine_bracket_local(firstRecord,secondRecord)
        lowerScale = min(firstRecord.scale,secondRecord.scale);
        upperScale = max(firstRecord.scale,secondRecord.scale);
        fineScales = (lowerScale+control.fineStep): ...
            control.fineStep:(upperScale-control.fineStep);
        if isempty(fineScales) && upperScale-lowerScale > 10*eps
            fineScales = 0.5*(lowerScale+upperScale);
        end

        for fineIndex = 1:numel(fineScales)
            if numel(history) >= control.maximumEvaluations
                return;
            end
            fineRecord = evaluate_at_local(fineScales(fineIndex),'fine_refinement');
            update_best_local(fineRecord);
            if fineRecord.withinTolerance
                return;
            end
        end
    end

    function finish_local()
        searchResult.bestScale = bestRecord.scale;
        searchResult.bestEvaluation = bestEvaluation;
        searchResult.bestRecord = bestRecord;
        searchResult.history = history;
        searchResult.stopReason = stopReason;
        searchResult.evaluationCount = numel(history);
    end
end

function evaluation = evaluate_scale_snell_local(context,scale)
startTime = tic;
control = context.control;
config = apply_scale_local( ...
    context.templateConfig,context.baseKaMinimum,context.baseKaMaximum,scale);

surface = generate_diffuser_surface(config,context.geometryRandomBank);
[slopeXGrid,slopeYGrid] = gradient(surface.Z,surface.dx,surface.dy);
normalGridLength = sqrt(1+slopeXGrid.^2+slopeYGrid.^2);
normalXGrid = slopeXGrid./normalGridLength;
normalYGrid = slopeYGrid./normalGridLength;
normalZGrid = -1./normalGridLength;
clear slopeXGrid slopeYGrid normalGridLength;

theta = linspace( ...
    config.angular.minimumDegree,config.angular.maximumDegree, ...
    config.angular.sampleCount).';
dTheta = theta(2)-theta(1);
angleEdges = [ ...
    theta(1)-0.5*dTheta; ...
    0.5*(theta(1:end-1)+theta(2:end)); ...
    theta(end)+0.5*dTheta];

angularCounts = zeros(numel(theta),numel(theta));
processedRayCount = 0;
validSnellRayCount = 0;
inAngularRangeRayCount = 0;

if strcmp(control.raySamplingMode,'random')
    rayStream = RandStream('mt19937ar','Seed',control.rayRandomSeed);
else
    rayStream = [];
end

while processedRayCount < control.rayCount
    currentCount = min( ...
        control.rayChunkSize,control.rayCount-processedRayCount);
    firstRayIndex = processedRayCount+1;
    [rayX,rayY] = generate_ray_positions_local( ...
        control,rayStream,firstRayIndex,currentCount, ...
        config.geometry.Lx,config.geometry.Ly);

    [rayNormalX,rayNormalY,rayNormalZ] = bilinear_sample_normals_local( ...
        normalXGrid,normalYGrid,normalZGrid,rayX,rayY, ...
        config.geometry.Lx,config.geometry.Ly);

    [thetaX,thetaY,validSnell] = normal_to_output_angles_snell_local( ...
        rayNormalX,rayNormalY,rayNormalZ, ...
        config.optical.nAir,config.optical.nSubstrate);
    thetaX = thetaX(validSnell);
    thetaY = thetaY(validSnell);

    chunkCounts = histcounts2(thetaX,thetaY,angleEdges,angleEdges);
    angularCounts = angularCounts+chunkCounts;
    validSnellRayCount = validSnellRayCount+nnz(validSnell);
    inAngularRangeRayCount = inAngularRangeRayCount+sum(chunkCounts(:));
    processedRayCount = processedRayCount+currentCount;
end

if control.angularSmoothingSigmaBins > 0
    countsForMeasurement = gaussian_smooth_2d_local( ...
        angularCounts,control.angularSmoothingSigmaBins);
else
    countsForMeasurement = angularCounts;
end

assert(any(countsForMeasurement(:) > 0), ...
    'No valid output rays are available in the current angular range.');

angularDistribution.mode = 'full';
angularDistribution.thetaDegree = theta;
angularDistribution.counts = angularCounts;
angularDistribution.normalized = countsForMeasurement/ ...
    (max(countsForMeasurement(:))+eps);
angularDistribution.angleSpacingDegree = dTheta;

metrics = measure_scattering_fwhm(config,angularDistribution);
if ~isfinite(metrics.primaryFwhmDegree)
    error('Unable to obtain a valid primary FWHM with the current angular range and ray statistics.');
end

evaluation.status = 'valid';
evaluation.scale = scale;
evaluation.config = config;
evaluation.metrics = metrics;
evaluation.angularDistribution = angularDistribution;
evaluation.objectiveDegree = metrics.absoluteErrorDegree;
evaluation.signedErrorDegree = metrics.signedErrorDegree;
evaluation.withinTolerance = metrics.withinTolerance;
evaluation.totalRayCount = control.rayCount;
evaluation.validSnellRayCount = validSnellRayCount;
evaluation.invalidSnellRayCount = control.rayCount-validSnellRayCount;
evaluation.inAngularRangeRayCount = inAngularRangeRayCount;
evaluation.outsideAngularRangeRayCount = ...
    validSnellRayCount-inAngularRangeRayCount;
evaluation.surfaceMinimumHeight_mm = surface.minimumHeight;
evaluation.surfaceMaximumHeight_mm = surface.maximumHeight;
evaluation.surfaceCoveredFraction = surface.coveredFraction;
evaluation.surfaceResolutionX = surface.resolutionX;
evaluation.surfaceResolutionY = surface.resolutionY;
evaluation.elapsedSecond = toc(startTime);
evaluation.errorMessage = '';
end

function [rayX,rayY] = generate_ray_positions_local( ...
        control,rayStream,firstRayIndex,count,Lx,Ly)
switch control.raySamplingMode
    case 'random'
        uv = rand(rayStream,2*count,1);
        rayX = Lx*uv(1:2:end);
        rayY = Ly*uv(2:2:end);

    case 'r2'
        rayIndex = (firstRayIndex:(firstRayIndex+count-1)).';
        plasticConstant = 1.32471795724474602596;
        alphaX = 1/plasticConstant;
        alphaY = 1/(plasticConstant^2);
        rayX = Lx*mod(0.5+rayIndex*alphaX,1);
        rayY = Ly*mod(0.5+rayIndex*alphaY,1);

    otherwise
        error('Unknown raySamplingMode: %s.',control.raySamplingMode);
end
end

function [sampleX,sampleY,sampleZ] = bilinear_sample_normals_local( ...
        normalX,normalY,normalZ,rayX,rayY,Lx,Ly)
[resolutionY,resolutionX] = size(normalX);

coordinateX = (rayX/Lx)*(resolutionX-1);
coordinateY = (rayY/Ly)*(resolutionY-1);
indexX = floor(coordinateX)+1;
indexY = floor(coordinateY)+1;
weightX = coordinateX-floor(coordinateX);
weightY = coordinateY-floor(coordinateY);

indexX = min(max(indexX,1),resolutionX-1);
indexY = min(max(indexY,1),resolutionY-1);

index00 = indexY+(indexX-1)*resolutionY;
index10 = indexY+indexX*resolutionY;
index01 = indexY+1+(indexX-1)*resolutionY;
index11 = indexY+1+indexX*resolutionY;

sampleX = interpolate_field_local(normalX);
sampleY = interpolate_field_local(normalY);
sampleZ = interpolate_field_local(normalZ);
sampleLength = sqrt(sampleX.^2+sampleY.^2+sampleZ.^2);
sampleX = sampleX./sampleLength;
sampleY = sampleY./sampleLength;
sampleZ = sampleZ./sampleLength;

    function sample = interpolate_field_local(field)
        sample = (1-weightX).*(1-weightY).*field(index00)+ ...
                 weightX.*(1-weightY).*field(index10)+ ...
                 (1-weightX).*weightY.*field(index01)+ ...
                 weightX.*weightY.*field(index11);
    end
end

function [thetaX,thetaY,valid] = normal_to_output_angles_snell_local( ...
        normalX,normalY,normalZ,refractiveIndexAir,refractiveIndexSubstrate)
rayCount = numel(normalX);
incidentDirection = zeros(rayCount,3);
incidentDirection(:,3) = -1;
roughNormal = [normalX(:),normalY(:),normalZ(:)];

insideDirection = refract_vectors_snell( ...
    incidentDirection,roughNormal,refractiveIndexAir,refractiveIndexSubstrate);
validFirst = all(isfinite(insideDirection),2);

finalDirection = nan(rayCount,3);
if any(validFirst)
    flatNormal = zeros(nnz(validFirst),3);
    flatNormal(:,3) = -1;
    finalDirection(validFirst,:) = refract_vectors_snell( ...
        insideDirection(validFirst,:),flatNormal, ...
        refractiveIndexSubstrate,refractiveIndexAir);
end

valid = all(isfinite(finalDirection),2);
thetaX = nan(rayCount,1);
thetaY = nan(rayCount,1);
thetaX(valid) = atan2d(finalDirection(valid,1),-finalDirection(valid,3));
thetaY(valid) = atan2d(finalDirection(valid,2),-finalDirection(valid,3));
end

function smoothed = gaussian_smooth_2d_local(values,sigmaBins)
radius = max(1,ceil(4*sigmaBins));
coordinate = (-radius:radius).';
kernel = exp(-0.5*(coordinate/sigmaBins).^2);
kernel = kernel/sum(kernel);
smoothed = conv2(conv2(values,kernel,'same'),kernel.','same');
end

function config = apply_scale_local(config,baseMinimum,baseMaximum,scale)
config.aspectKa.minimum = baseMinimum*scale;
config.aspectKa.maximum = baseMaximum*scale;
config.optimization.baseAspectKaMinimum = baseMinimum;
config.optimization.baseAspectKaMaximum = baseMaximum;
config.optimization.currentKaScale = scale;
validate_diffuser_config(config);
end

function [baseMinimum,baseMaximum,currentScale,parameterDefaults] = ...
        read_ka_defaults_local(config)
assert(isfield(config,'optimization'), ...
    'best_config is missing the optimization field.');

if isfield(config.optimization,'currentKaScale')
    currentScale = config.optimization.currentKaScale;
else
    currentScale = 1;
end

if isfield(config.optimization,'baseAspectKaMinimum') && ...
   isfield(config.optimization,'baseAspectKaMaximum')
    baseMinimum = config.optimization.baseAspectKaMinimum;
    baseMaximum = config.optimization.baseAspectKaMaximum;
else
    baseMinimum = config.aspectKa.minimum/currentScale;
    baseMaximum = config.aspectKa.maximum/currentScale;
end

parameters = config.optimization.parameters;
parameterNames = {parameters.name};
parameterIndex = find(strcmp(parameterNames,'kaScale'),1);
assert(~isempty(parameterIndex),'best_config does not define kaScale.');
parameterDefaults = parameters(parameterIndex);
end

function control = fill_search_defaults_local(control,savedScale,parameter)
if isempty(control.startScale)
    control.startScale = savedScale;
end
if isempty(control.scaleLowerBound)
    control.scaleLowerBound = parameter.lowerBound;
end
if isempty(control.scaleUpperBound)
    control.scaleUpperBound = parameter.upperBound;
end
if isempty(control.coarseStep)
    control.coarseStep = parameter.coarseStep;
end
if isempty(control.fineStep)
    control.fineStep = parameter.fineStep;
end
if isempty(control.maximumEvaluations)
    control.maximumEvaluations = 100;
end
if isempty(control.noImprovementPatience)
    control.noImprovementPatience = 5;
end

assert(control.startScale >= control.scaleLowerBound && ...
       control.startScale <= control.scaleUpperBound, ...
    'Initial kaScale is outside search bounds.');
assert(control.coarseStep > 0 && control.fineStep > 0, ...
    'Coarse and fine search steps must be positive.');
end

function control = merge_control_local(defaults,userControl)
control = defaults;
userFields = fieldnames(userControl);
defaultFields = fieldnames(defaults);
for fieldIndex = 1:numel(userFields)
    fieldName = userFields{fieldIndex};
    assert(any(strcmp(defaultFields,fieldName)), ...
        'Unknown control field: %s.',fieldName);
    control.(fieldName) = userControl.(fieldName);
end
end

function validate_control_local(control)
assert(ischar(control.bestConfigJsonPath) || isstring(control.bestConfigJsonPath), ...
    'bestConfigJsonPath must be a text path.');
assert(isscalar(control.rayCount) && isfinite(control.rayCount) && ...
       control.rayCount >= 1 && control.rayCount == floor(control.rayCount), ...
    'rayCount must be a positive integer.');
assert(isscalar(control.rayChunkSize) && isfinite(control.rayChunkSize) && ...
       control.rayChunkSize >= 1 && ...
       control.rayChunkSize == floor(control.rayChunkSize), ...
    'rayChunkSize must be a positive integer.');
assert(any(strcmp(control.raySamplingMode,{'random','r2'})), ...
    'raySamplingMode must be random or r2.');
assert(isscalar(control.rayRandomSeed) && isfinite(control.rayRandomSeed) && ...
       control.rayRandomSeed >= 0 && control.rayRandomSeed == floor(control.rayRandomSeed), ...
    'rayRandomSeed must be a nonnegative integer.');
assert(isscalar(control.angularSmoothingSigmaBins) && ...
       isfinite(control.angularSmoothingSigmaBins) && ...
       control.angularSmoothingSigmaBins >= 0, ...
    'angularSmoothingSigmaBins must be a nonnegative finite scalar.');
end

function record = record_from_evaluation_local(evaluation,scale,phase,fromCache)
record = empty_record_local();
record.scale = scale;
record.phase = phase;
record.status = evaluation.status;
record.fromCache = fromCache;
record.errorMessage = evaluation.errorMessage;
record.elapsedSecond = evaluation.elapsedSecond;

if strcmp(evaluation.status,'valid')
    record.primaryMetric = evaluation.metrics.primaryMetric;
    record.primaryFwhmDegree = evaluation.metrics.primaryFwhmDegree;
    record.fwhmCenterXDegree = evaluation.metrics.fwhmCenterXDegree;
    record.fwhmCenterYDegree = evaluation.metrics.fwhmCenterYDegree;
    record.fwhmRadialDegree = evaluation.metrics.fwhmRadialDegree;
    record.anisotropyDegree = evaluation.metrics.anisotropyDegree;
    record.objectiveDegree = evaluation.metrics.absoluteErrorDegree;
    record.signedErrorDegree = evaluation.metrics.signedErrorDegree;
    record.withinTolerance = evaluation.metrics.withinTolerance;
    record.validRayCount = evaluation.validSnellRayCount;
    record.invalidSnellRayCount = evaluation.invalidSnellRayCount;
    record.outsideAngularRangeRayCount = evaluation.outsideAngularRangeRayCount;
else
    record.objectiveDegree = Inf;
end
end

function record = empty_record_local()
record = struct( ...
    'scale',NaN,'phase','','status','invalid','primaryMetric','', ...
    'primaryFwhmDegree',NaN,'fwhmCenterXDegree',NaN, ...
    'fwhmCenterYDegree',NaN,'fwhmRadialDegree',NaN, ...
    'anisotropyDegree',NaN,'objectiveDegree',Inf, ...
    'signedErrorDegree',NaN,'withinTolerance',false, ...
    'validRayCount',0,'invalidSnellRayCount',0, ...
    'outsideAngularRangeRayCount',0,'elapsedSecond',NaN, ...
    'fromCache',false,'errorMessage','');
end

function evaluation = invalid_evaluation_local(message)
evaluation.status = 'invalid';
evaluation.metrics = struct();
evaluation.objectiveDegree = Inf;
evaluation.signedErrorDegree = NaN;
evaluation.withinTolerance = false;
evaluation.validSnellRayCount = 0;
evaluation.invalidSnellRayCount = 0;
evaluation.outsideAngularRangeRayCount = 0;
evaluation.elapsedSecond = 0;
evaluation.errorMessage = message;
end

function result = crosses_target_local(firstRecord,secondRecord)
result = isfinite(firstRecord.signedErrorDegree) && ...
         isfinite(secondRecord.signedErrorDegree) && ...
         firstRecord.signedErrorDegree*secondRecord.signedErrorDegree <= 0;
end

function key = scale_key_local(scale)
key = sprintf('%.15g',scale);
end

function output = ternary_local(condition,trueText,falseText)
if condition
    output = trueText;
else
    output = falseText;
end
end

function write_json_local(pathName,structure)
try
    jsonText = jsonencode(structure,'PrettyPrint',true);
catch
    jsonText = jsonencode(structure);
end
fileId = fopen(pathName,'w','n','UTF-8');
assert(fileId >= 0,'Unable to create JSON file: %s',pathName);
cleanup = onCleanup(@() fclose(fileId));
fwrite(fileId,jsonText,'char');
end

function plot_results_local(evaluation,searchResult,config,outputDirectory)
theta = evaluation.metrics.thetaDegree;
H = evaluation.angularDistribution.normalized;
metrics = evaluation.metrics;

angularFigure = figure('Color','w','Name','Snell final two-dimensional angular distribution');
imagesc(theta,theta,H.');
axis image;
set(gca,'YDir','normal');
xlabel('\theta_x (deg)');
ylabel('\theta_y (deg)');
title(sprintf('Snell ray tracing, %s FWHM = %.4f^\circ', ...
    metrics.primaryMetric,metrics.primaryFwhmDegree));
colorbar;
colormap turbo;
exportgraphics(angularFigure, ...
    fullfile(outputDirectory,'snell_final_angular_distribution.png'), ...
    'Resolution',180);

profileFigure = figure('Color','w','Name','Snell Final FWHM profiles');
plot(theta,metrics.centerCutXNormalized,'LineWidth',2); hold on;
plot(theta,metrics.centerCutYNormalized,'--','LineWidth',2);
if ~isempty(metrics.radialRadiusDegree)
    plot(metrics.radialRadiusDegree,metrics.radialProfileNormalized, ...
        '-.','LineWidth',2);
end
yline(0.5,':','Half maximum','LineWidth',1.5);
grid on;
xlabel('Angle (deg)');
ylabel('Peak-normalized ray count');
legend( ...
    sprintf('x cut, FWHM %.4f^\circ',metrics.fwhmCenterXDegree), ...
    sprintf('y cut, FWHM %.4f^\circ',metrics.fwhmCenterYDegree), ...
    sprintf('radial, FWHM %.4f^\circ',metrics.fwhmRadialDegree), ...
    'Half maximum','Location','best');
title('Center profiles and radial average of the Snell output-angle distribution');
exportgraphics(profileFigure, ...
    fullfile(outputDirectory,'snell_final_fwhm_profiles.png'), ...
    'Resolution',180);

history = searchResult.history;
valid = strcmp({history.status},'valid');
validHistory = history(valid);
historyFigure = figure('Color','w','Name','Snell coordinate-search history');
tiledlayout(2,1);
nexttile;
plot(1:numel(validHistory),[validHistory.primaryFwhmDegree],'-o','LineWidth',1.6);
yline(config.target.fwhmDegree,'--','Target','LineWidth',1.4);
grid on;
ylabel('FWHM (deg)');
title('Primary FWHM of Snell candidate structures');
nexttile;
semilogy(1:numel(validHistory), ...
    max([validHistory.objectiveDegree],eps),'-o','LineWidth',1.6);
yline(config.target.angleToleranceDegree,'--','Tolerance','LineWidth',1.4);
grid on;
xlabel('Valid evaluation index');
ylabel('|FWHM-target| (deg)');
exportgraphics(historyFigure, ...
    fullfile(outputDirectory,'snell_optimization_history.png'), ...
    'Resolution',180);
end
