% Assemble Gaussian angular distributions.
function angularDistribution = assemble_gaussian_distribution(config, kernelStats, mode)

if nargin < 3
    mode = 'full';
end
assert(any(strcmp(mode,{'full','targetOnly'})), ...
    'Gaussian angular-distribution mode must be full or targetOnly.');

theta = linspace( ...
    config.angular.minimumDegree, ...
    config.angular.maximumDegree, ...
    config.angular.sampleCount);
angleSpacing = abs(theta(2)-theta(1));
if strcmp(mode,'full')
    [thetaXGrid,thetaYGrid] = ndgrid(theta,theta);
    rawDistribution = zeros(numel(theta),numel(theta));
else
    rawCenterCutX = zeros(numel(theta),1);
    rawCenterCutY = zeros(numel(theta),1);
end

statsTable = kernelStats.table;
validIndices = find(statsTable.validKernel);
assert(~isempty(validIndices), ...
    'The candidate surface produced no valid Gaussian kernels; check resolution and valid-region thresholds.');

for localIndex = 1:numel(validIndices)
    row = validIndices(localIndex);
    covariance = [ ...
        statsTable.cov11_deg2(row),statsTable.cov12_deg2(row); ...
        statsTable.cov12_deg2(row),statsTable.cov22_deg2(row)];
    determinant = det(covariance);
    if ~isfinite(determinant) || determinant <= 0
        continue;
    end

    inverseCovariance = [ ...
        covariance(2,2),-covariance(1,2); ...
        -covariance(2,1),covariance(1,1)]/determinant;

    normalization = 2*pi*sqrt(determinant);
    if strcmp(mode,'full')
        deltaThetaX = thetaXGrid-statsTable.meanThetaX_deg(row);
        deltaThetaY = thetaYGrid-statsTable.meanThetaY_deg(row);
        quadraticForm = ...
            inverseCovariance(1,1).*deltaThetaX.^2 + ...
            2*inverseCovariance(1,2).*deltaThetaX.*deltaThetaY + ...
            inverseCovariance(2,2).*deltaThetaY.^2;
        gaussianDensity = exp(-0.5*quadraticForm)/normalization;
        rawDistribution = rawDistribution + ...
            statsTable.weight(row).*gaussianDensity;
    else
        deltaX = theta(:)-statsTable.meanThetaX_deg(row);
        fixedDeltaY = -statsTable.meanThetaY_deg(row);
        quadraticX = inverseCovariance(1,1).*deltaX.^2 + ...
            2*inverseCovariance(1,2).*deltaX.*fixedDeltaY + ...
            inverseCovariance(2,2).*fixedDeltaY.^2;
        rawCenterCutX = rawCenterCutX + statsTable.weight(row).* ...
            exp(-0.5*quadraticX)/normalization;

        fixedDeltaX = -statsTable.meanThetaX_deg(row);
        deltaY = theta(:)-statsTable.meanThetaY_deg(row);
        quadraticY = inverseCovariance(1,1).*fixedDeltaX.^2 + ...
            2*inverseCovariance(1,2).*fixedDeltaX.*deltaY + ...
            inverseCovariance(2,2).*deltaY.^2;
        rawCenterCutY = rawCenterCutY + statsTable.weight(row).* ...
            exp(-0.5*quadraticY)/normalization;
    end
end

angularDistribution.thetaDegree = theta;
angularDistribution.angleSpacingDegree = angleSpacing;
angularDistribution.validKernelCount = kernelStats.validCount;
angularDistribution.mode = mode;

if strcmp(mode,'full')
    discreteIntegral = sum(rawDistribution(:))*angleSpacing^2;
    assert(isfinite(discreteIntegral) && discreteIntegral > 0, ...
        'The Gaussian-kernel sum has an invalid total integral.');
    probabilityDensity = rawDistribution/discreteIntegral;
    peakValue = max(probabilityDensity(:));
    assert(isfinite(peakValue) && peakValue > 0, 'Gaussian angular-distribution peak is invalid.');
    angularDistribution.raw = rawDistribution;
    angularDistribution.pdf = probabilityDensity;
    angularDistribution.normalized = probabilityDensity/peakValue;
    angularDistribution.discreteIntegralBeforeNormalization = discreteIntegral;
else
    assert(max(rawCenterCutX) > 0 && max(rawCenterCutY) > 0, ...
        'Gaussian-kernel sum for the target profile is invalid.');
    angularDistribution.centerCutXNormalized = ...
        rawCenterCutX/max(rawCenterCutX);
    angularDistribution.centerCutYNormalized = ...
        rawCenterCutY/max(rawCenterCutY);
end
end
