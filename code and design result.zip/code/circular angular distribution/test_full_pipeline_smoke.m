% Run full-pipeline smoke tests.

clear;
clc;

config = create_diffuser_config();
config.geometry.Nx = 8;
config.geometry.Ny = 8;
config.numerical.resolutionX = 240;
config.numerical.resolutionY = 240;
config.numerical.searchResolutionX = 240;
config.numerical.searchResolutionY = 240;
config.angular.sampleCount = 101;
config.measurement.radialBinCount = 100;
config.numerical.returnCoverageMask = false;
validate_diffuser_config(config);

bank = build_common_random_bank(config);
options.resolutionX = 240;
options.resolutionY = 240;
options.retainLargeData = true;
options.failFast = true;
evaluation = evaluate_diffuser_candidate(config,bank,options);

assert(strcmp(evaluation.status,'valid'), 'Full forward pipeline returned an invalid status.');
assert(isfinite(evaluation.primaryFwhmDegree) && ...
       evaluation.primaryFwhmDegree > 0, 'Primary FWHM is invalid.');
assert(evaluation.validKernelCount > 0, 'No valid Gaussian kernels were generated.');
assert(all(isfinite(evaluation.angularDistribution.normalized(:))), ...
    'Normalized two-dimensional angular distribution contains NaN or Inf.');
assert(abs(max(evaluation.angularDistribution.normalized(:))-1) < 1e-12, ...
    'Two-dimensional angular distribution is not peak normalized.');

targetOnlyAngular = assemble_gaussian_distribution( ...
    config,evaluation.kernelStats,'targetOnly');
targetOnlyMetrics = measure_scattering_fwhm(config,targetOnlyAngular);
assert(abs(targetOnlyMetrics.fwhmCenterXDegree- ...
           evaluation.metrics.fwhmCenterXDegree) < 1e-10, ...
    'targetOnly x-center-profile FWHM does not match the full distribution.');
assert(abs(targetOnlyMetrics.fwhmCenterYDegree- ...
           evaluation.metrics.fwhmCenterYDegree) < 1e-10, ...
    'targetOnly y-center-profile FWHM does not match the full distribution.');

fprintf('Full forward-pipeline smoke test passed.\n');
fprintf('Valid Gaussian kernels: %d, primary FWHM: %.6f deg.\n', ...
    evaluation.validKernelCount,evaluation.primaryFwhmDegree);
