% Save optimization results.
function save_optimization_results( ...
        outputDirectory,searchResult,finalEvaluation,validation)

if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end

save(fullfile(outputDirectory,'complete_optimization_result.mat'), ...
    'searchResult','finalEvaluation','validation','-v7.3');

if ~isempty(searchResult)
    writetable(searchResult.history, ...
        fullfile(outputDirectory,'optimization_history.csv'));
    writetable(searchResult.parameterResults, ...
        fullfile(outputDirectory,'parameter_summary.csv'));
end

if ~isempty(validation) && isfield(validation,'perSeed')
    writetable(validation.perSeed, ...
        fullfile(outputDirectory,'multi_seed_validation.csv'));
end

if isfield(finalEvaluation,'angularDistribution')
    thetaDegree = finalEvaluation.angularDistribution.thetaDegree;
    angularDistributionNormalized = ...
        finalEvaluation.angularDistribution.normalized;
    angularDistributionPdf = finalEvaluation.angularDistribution.pdf;
    save(fullfile(outputDirectory,'final_angular_distribution.mat'), ...
        'thetaDegree','angularDistributionNormalized', ...
        'angularDistributionPdf','-v7.3');
    writematrix(angularDistributionNormalized, ...
        fullfile(outputDirectory,'final_angular_distribution_normalized.csv'));
end

if isfield(finalEvaluation,'config')
    configJson = jsonencode(finalEvaluation.config);
    writelines(string(configJson),fullfile(outputDirectory,'best_config.json'));
end
end

