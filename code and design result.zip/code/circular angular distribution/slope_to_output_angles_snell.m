% Map slopes to output angles.
function [thetaX, thetaY, valid] = slope_to_output_angles_snell( ...
        slopeX, slopeY, refractiveIndexAir, refractiveIndexSubstrate)

slopeX = slopeX(:);
slopeY = slopeY(:);
assert(numel(slopeX) == numel(slopeY), 'x and y slope sample counts must match.');

sampleCount = numel(slopeX);
thetaX = nan(sampleCount,1);
thetaY = nan(sampleCount,1);
valid = false(sampleCount,1);

finiteSlope = isfinite(slopeX) & isfinite(slopeY);
if ~any(finiteSlope)
    return;
end

sx = slopeX(finiteSlope);
sy = slopeY(finiteSlope);
normalLength = sqrt(1+sx.^2+sy.^2);
roughNormal = [sx./normalLength, sy./normalLength, -1./normalLength];
incidentDirection = repmat([0,0,-1], numel(sx), 1);

insideDirection = refract_vectors_snell( ...
    incidentDirection, roughNormal, refractiveIndexAir, refractiveIndexSubstrate);
validFirstInterface = all(isfinite(insideDirection),2);
if ~any(validFirstInterface)
    return;
end

finalDirection = nan(size(insideDirection));
flatNormal = repmat([0,0,-1], nnz(validFirstInterface), 1);
finalDirection(validFirstInterface,:) = refract_vectors_snell( ...
    insideDirection(validFirstInterface,:), flatNormal, ...
    refractiveIndexSubstrate, refractiveIndexAir);
validLocal = all(isfinite(finalDirection),2);

thetaXLocal = nan(size(sx));
thetaYLocal = nan(size(sy));
thetaXLocal(validLocal) = atan2d( ...
    finalDirection(validLocal,1), -finalDirection(validLocal,3));
thetaYLocal(validLocal) = atan2d( ...
    finalDirection(validLocal,2), -finalDirection(validLocal,3));

originalIndex = find(finiteSlope);
thetaX(originalIndex(validLocal)) = thetaXLocal(validLocal);
thetaY(originalIndex(validLocal)) = thetaYLocal(validLocal);
valid(originalIndex(validLocal)) = true;
end

