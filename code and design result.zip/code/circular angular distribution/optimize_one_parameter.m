% Optimize one parameter.
function [updatedConfig,result] = optimize_one_parameter( ...
        currentConfig,randomBank,parameter,evaluationOptions,evaluationCache)

if nargin < 5 || isempty(evaluationCache)
    evaluationCache = containers.Map('KeyType','char','ValueType','any');
end

records = repmat(empty_record_local(),0,1);
maximumEvaluations = currentConfig.optimization.maximumEvaluationsPerParameter;
patience = currentConfig.optimization.noImprovementPatience;
currentValue = get_optimization_parameter_value(currentConfig,parameter);
stopReason = 'maximum_evaluations';

currentRecord = evaluate_value_local(currentValue,'initial');
bestRecord = currentRecord;

if currentRecord.withinTolerance
    stopReason = 'target_tolerance_reached_at_initial_value';
    finish_result_local();
    return;
end

leftValue = currentValue-parameter.coarseStep;
rightValue = currentValue+parameter.coarseStep;
probeValues = [leftValue,rightValue];
probeValues = probeValues( ...
    probeValues >= parameter.lowerBound-10*eps & ...
    probeValues <= parameter.upperBound+10*eps);

probeRecords = repmat(empty_record_local(),0,1);
bracketFound = false;
bracketFirst = empty_record_local();
bracketSecond = empty_record_local();

for probeIndex = 1:numel(probeValues)
    if numel(records) >= maximumEvaluations
        break;
    end
    probeRecord = evaluate_value_local(probeValues(probeIndex),'direction_probe');
    probeRecords(end+1,1) = probeRecord; %#ok<AGROW>
    update_best_local(probeRecord);

    if probeRecord.withinTolerance
        stopReason = 'target_tolerance_reached_during_direction_probe';
        finish_result_local();
        return;
    end
    if crosses_target_local(currentRecord,probeRecord)
        bracketFound = true;
        bracketFirst = currentRecord;
        bracketSecond = probeRecord;
        break;
    end
end

if bracketFound
    refine_bracket_local(bracketFirst,bracketSecond);
    if bestRecord.withinTolerance
        stopReason = 'target_tolerance_reached_during_refinement';
    else
        stopReason = 'target_bracket_refined_to_parameter_resolution';
    end
    finish_result_local();
    return;
end

if isempty(probeRecords)
    stopReason = 'initial_value_is_at_both_boundaries';
    finish_result_local();
    return;
end

[bestProbeObjective,bestProbeIndex] = min([probeRecords.objectiveDegree]);
if ~(bestProbeObjective < currentRecord.objectiveDegree)
    stopReason = 'no_improving_search_direction';
    finish_result_local();
    return;
end

selectedProbe = probeRecords(bestProbeIndex);
searchDirection = sign(selectedProbe.parameterValue-currentValue);
previousRecord = selectedProbe;
noImprovementCount = 0;

while numel(records) < maximumEvaluations
    nextValue = previousRecord.parameterValue + ...
        searchDirection*parameter.coarseStep;
    if nextValue < parameter.lowerBound-10*eps || ...
       nextValue > parameter.upperBound+10*eps
        stopReason = 'parameter_boundary_reached';
        break;
    end

    nextRecord = evaluate_value_local(nextValue,'coarse_traversal');
    oldBestObjective = bestRecord.objectiveDegree;
    update_best_local(nextRecord);

    if nextRecord.withinTolerance
        stopReason = 'target_tolerance_reached_during_coarse_traversal';
        break;
    end

    if crosses_target_local(previousRecord,nextRecord)
        refine_bracket_local(previousRecord,nextRecord);
        if bestRecord.withinTolerance
            stopReason = 'target_tolerance_reached_during_refinement';
        else
            stopReason = 'target_bracket_refined_to_parameter_resolution';
        end
        break;
    end

    if bestRecord.objectiveDegree < oldBestObjective
        noImprovementCount = 0;
    else
        noImprovementCount = noImprovementCount+1;
    end
    if noImprovementCount >= patience
        stopReason = 'no_improvement_patience_reached';
        break;
    end
    previousRecord = nextRecord;
end

finish_result_local();

    function record = evaluate_value_local(value,phase)
        value = min(max(value,parameter.lowerBound),parameter.upperBound);
        if parameter.isInteger
            value = round(value);
        end
        try
            candidateConfig = apply_optimization_parameter( ...
                currentConfig,parameter,value);
            cacheKey = build_cache_key_local( ...
                candidateConfig,evaluationOptions,randomBank);
            if isKey(evaluationCache,cacheKey)
                evaluation = evaluationCache(cacheKey);
                evaluation.fromCache = true;
            else
                evaluation = evaluate_diffuser_candidate( ...
                    candidateConfig,randomBank,evaluationOptions);
                evaluationCache(cacheKey) = evaluation;
            end
        catch exception
            evaluation = invalid_evaluation_local(exception.message);
        end

        record = empty_record_local();
        record.parameterValue = value;
        record.phase = phase;
        record.status = evaluation.status;
        record.objectiveDegree = evaluation.objectiveDegree;
        record.signedErrorDegree = evaluation.signedErrorDegree;
        record.primaryFwhmDegree = evaluation.primaryFwhmDegree;
        record.fwhmCenterXDegree = evaluation.fwhmCenterXDegree;
        record.fwhmCenterYDegree = evaluation.fwhmCenterYDegree;
        record.fwhmRadialDegree = evaluation.fwhmRadialDegree;
        record.anisotropyDegree = evaluation.anisotropyDegree;
        record.withinTolerance = evaluation.withinTolerance;
        record.validKernelCount = evaluation.validKernelCount;
        record.skippedKernelCount = evaluation.skippedKernelCount;
        record.elapsedSecond = evaluation.elapsedSecond;
        record.fromCache = evaluation.fromCache;
        record.errorMessage = evaluation.errorMessage;
        records(end+1,1) = record;
    end

    function update_best_local(candidateRecord)
        if candidateRecord.objectiveDegree < bestRecord.objectiveDegree
            bestRecord = candidateRecord;
        end
    end

    function refine_bracket_local(firstRecord,secondRecord)
        lowerValue = min(firstRecord.parameterValue,secondRecord.parameterValue);
        upperValue = max(firstRecord.parameterValue,secondRecord.parameterValue);
        fineValues = (lowerValue+parameter.fineStep): ...
            parameter.fineStep:(upperValue-parameter.fineStep);
        if isempty(fineValues) && upperValue-lowerValue > 10*eps
            fineValues = 0.5*(lowerValue+upperValue);
        end
        if parameter.isInteger
            fineValues = unique(round(fineValues));
        end

        for fineIndex = 1:numel(fineValues)
            if numel(records) >= maximumEvaluations
                return;
            end
            fineRecord = evaluate_value_local(fineValues(fineIndex),'fine_refinement');
            update_best_local(fineRecord);
            if fineRecord.withinTolerance
                return;
            end
        end
    end

    function finish_result_local()
        updatedConfig = apply_optimization_parameter( ...
            currentConfig,parameter,bestRecord.parameterValue);
        result.parameterName = char(parameter.name);
        result.initialValue = currentValue;
        result.bestValue = bestRecord.parameterValue;
        result.bestObjectiveDegree = bestRecord.objectiveDegree;
        result.bestFwhmDegree = bestRecord.primaryFwhmDegree;
        result.stopReason = stopReason;
        result.evaluations = records;
        result.evaluationCount = numel(records);
        result.bestEvaluation = bestRecord;
    end
end

function result = crosses_target_local(firstRecord,secondRecord)
result = isfinite(firstRecord.signedErrorDegree) && ...
         isfinite(secondRecord.signedErrorDegree) && ...
         firstRecord.signedErrorDegree*secondRecord.signedErrorDegree <= 0;
end

function key = build_cache_key_local(config,options,randomBank)
keyData.geometry = config.geometry;
keyData.height = config.height;
keyData.aspectKa = config.aspectKa;
keyData.numerical = config.numerical;
keyData.optical = config.optical;
keyData.effectiveRegion = config.effectiveRegion;
keyData.kernel = config.kernel;
keyData.angular = config.angular;
keyData.measurement = config.measurement;
keyData.target = config.target;
keyData.seed = config.random.seed;
keyData.bankSeed = randomBank.seed;
keyData.resolutionX = options.resolutionX;
keyData.resolutionY = options.resolutionY;
keyData.angularMode = options.angularMode;
key = jsonencode(keyData);
end

function record = empty_record_local()
record = struct( ...
    'parameterValue',NaN,'phase','', 'status','invalid', ...
    'objectiveDegree',Inf,'signedErrorDegree',NaN, ...
    'primaryFwhmDegree',NaN,'fwhmCenterXDegree',NaN, ...
    'fwhmCenterYDegree',NaN,'fwhmRadialDegree',NaN, ...
    'anisotropyDegree',NaN,'withinTolerance',false, ...
    'validKernelCount',0,'skippedKernelCount',0, ...
    'elapsedSecond',NaN,'fromCache',false,'errorMessage','');
end

function evaluation = invalid_evaluation_local(message)
evaluation = struct( ...
    'status','invalid','objectiveDegree',Inf,'signedErrorDegree',NaN, ...
    'primaryFwhmDegree',NaN,'fwhmCenterXDegree',NaN, ...
    'fwhmCenterYDegree',NaN,'fwhmRadialDegree',NaN, ...
    'anisotropyDegree',NaN,'withinTolerance',false, ...
    'validKernelCount',0,'skippedKernelCount',0, ...
    'coveredFraction',NaN,'minimumSurfaceHeight_mm',NaN, ...
    'errorMessage',message,'elapsedSecond',0, ...
    'resolutionX',NaN,'resolutionY',NaN,'fromCache',false);
end
