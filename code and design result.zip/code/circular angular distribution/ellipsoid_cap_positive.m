% Compute positive ellipsoid caps.
function [positiveCap, insideCap] = ellipsoid_cap_positive( ...
        X, Y, centerX, centerY, semiMajorA, semiMinorB, height, rotation)

deltaX = X-centerX;
deltaY = Y-centerY;
cosRotation = cos(rotation);
sinRotation = sin(rotation);

xPrime =  cosRotation.*deltaX + sinRotation.*deltaY;
yPrime = -sinRotation.*deltaX + cosRotation.*deltaY;

normalizedRadiusSquared = ...
    (xPrime./semiMajorA).^2 + (yPrime./semiMinorB).^2;
insideCap = normalizedRadiusSquared <= 1;

positiveCap = zeros(size(X));
positiveCap(insideCap) = height .* sqrt(max( ...
    0, 1-normalizedRadiusSquared(insideCap)));
end

