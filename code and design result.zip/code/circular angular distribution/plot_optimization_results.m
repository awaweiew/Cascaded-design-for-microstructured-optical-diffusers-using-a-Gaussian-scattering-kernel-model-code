% Plot optimization results.
function figureHandles = plot_optimization_results( ...
        finalEvaluation,searchResult,outputDirectory)

if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end
assert(isfield(finalEvaluation,'surfaceData') && ...
       isfield(finalEvaluation,'angularDistribution') && ...
       isfield(finalEvaluation,'metrics'), ...
    'Plotting requires final evaluation with retainLargeData=true.');

figureHandles = gobjects(0);
surfaceData = finalEvaluation.surfaceData;
angular = finalEvaluation.angularDistribution;
metrics = finalEvaluation.metrics;

plotStride = max(1,ceil(max( ...
    surfaceData.resolutionX,surfaceData.resolutionY)/800));
rows = 1:plotStride:surfaceData.resolutionY;
columns = 1:plotStride:surfaceData.resolutionX;
surfaceFigure = figure('Color','w','Name','Final optimized diffuser surface');
surf(1e3*surfaceData.x(columns),1e3*surfaceData.y(rows), ...
    1e3*surfaceData.Z(rows,columns),1e3*surfaceData.Z(rows,columns), ...
    'EdgeColor','none');
axis equal tight;
xlabel('x (\mum)'); ylabel('y (\mum)'); zlabel('z (\mum)');
title('Continuous diffuser surface from final parameters');
colormap turbo; colorbar; view(45,45); light; lighting gouraud;
exportgraphics(surfaceFigure,fullfile(outputDirectory,'final_surface.png'), ...
    'Resolution',200);
figureHandles(end+1) = surfaceFigure;

angularFigure = figure('Color','w','Name','Final two-dimensional Gaussian angular distribution');
imagesc(angular.thetaDegree,angular.thetaDegree,angular.normalized.');
axis image; set(gca,'YDir','normal');
xlabel('\theta_x (deg)'); ylabel('\theta_y (deg)');
title(sprintf('Gaussian angular distribution, FWHM = %.4f^\\circ', ...
    metrics.primaryFwhmDegree));
colormap turbo; colorbar;
exportgraphics(angularFigure, ...
    fullfile(outputDirectory,'final_angular_distribution.png'),'Resolution',200);
figureHandles(end+1) = angularFigure;

profileFigure = figure('Color','w','Name','Final FWHM profiles');
plot(metrics.thetaDegree,metrics.centerCutXNormalized,'LineWidth',1.8); hold on;
plot(metrics.thetaDegree,metrics.centerCutYNormalized,'--','LineWidth',1.8);
plot(metrics.radialRadiusDegree,metrics.radialProfileNormalized, ...
    '-.','LineWidth',1.8);
yline(0.5,':','Half maximum','LineWidth',1.2);
grid on; ylim([0,1.05]);
xlabel('Angle (deg)'); ylabel('Peak-normalized intensity');
legend( ...
    sprintf('x cut, FWHM %.4f^\\circ',metrics.fwhmCenterXDegree), ...
    sprintf('y cut, FWHM %.4f^\\circ',metrics.fwhmCenterYDegree), ...
    sprintf('radial, FWHM %.4f^\\circ',metrics.fwhmRadialDegree), ...
    'Half maximum','Location','best');
title('Center profiles and radial average of the final angular distribution');
exportgraphics(profileFigure,fullfile(outputDirectory,'final_fwhm_profiles.png'), ...
    'Resolution',200);
figureHandles(end+1) = profileFigure;

if ~isempty(searchResult) && isfield(searchResult,'history') && ...
        ~isempty(searchResult.history)
    history = searchResult.history;
    validRow = isfinite(history.primaryFwhmDegree);
    evaluationIndex = find(validRow);
    historyFigure = figure('Color','w','Name','Coordinate-search history');
    tiledlayout(2,1,'TileSpacing','compact');
    nexttile;
    plot(evaluationIndex,history.primaryFwhmDegree(validRow),'o-','LineWidth',1.2);
    yline(finalEvaluation.config.target.fwhmDegree,'--','Target');
    grid on; ylabel('FWHM (deg)'); title('Primary FWHM from candidate evaluations');
    nexttile;
    semilogy(evaluationIndex,max(history.objectiveDegree(validRow),eps), ...
        'o-','LineWidth',1.2);
    grid on; xlabel('Valid evaluation index'); ylabel('|FWHM-target| (deg)');
    title('Target-error evolution');
    exportgraphics(historyFigure, ...
        fullfile(outputDirectory,'optimization_history.png'),'Resolution',200);
    figureHandles(end+1) = historyFigure;
end
end
