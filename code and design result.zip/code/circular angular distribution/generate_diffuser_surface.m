% Generate diffuser surfaces.
function [surface, units] = generate_diffuser_surface(config, randomBank)

validate_diffuser_config(config);
validate_bank_for_surface(randomBank, config);

Lx = config.geometry.Lx;
Ly = config.geometry.Ly;
Nx = config.geometry.Nx;
Ny = config.geometry.Ny;
resX = config.numerical.resolutionX;
resY = config.numerical.resolutionY;

x = linspace(0, Lx, resX);
y = linspace(0, Ly, resY);
dx = x(2) - x(1);
dy = y(2) - y(1);

Z = zeros(resY, resX);
coveredMask = false(resY, resX);

periodX = Lx / Nx;
periodY = Ly / Ny;
centerXBase = linspace(periodX/2, Lx-periodX/2, Nx);
centerYBase = linspace(periodY/2, Ly-periodY/2, Ny);

jitterFraction = config.geometry.positionJitterFraction;
maximumJitterX = (periodX/2) * jitterFraction;
maximumJitterY = (periodY/2) * jitterFraction;

unitCount = Nx * Ny;

centerX = zeros(unitCount, 1);
centerY = zeros(unitCount, 1);
height = zeros(unitCount, 1);
ka = zeros(unitCount, 1);
semiMajorA = zeros(unitCount, 1);
semiMinorB = zeros(unitCount, 1);
rotation = zeros(unitCount, 1);

heightNormalized = betaincinv( ...
    randomBank.heightQuantile, config.height.alpha, config.height.beta);
kaNormalized = betaincinv( ...
    randomBank.kaQuantile, config.aspectKa.alpha, config.aspectKa.beta);

height(:) = config.height.minimum + ...
    (config.height.maximum-config.height.minimum) .* heightNormalized;
ka(:) = config.aspectKa.minimum + ...
    (config.aspectKa.maximum-config.aspectKa.minimum) .* kaNormalized;

semiMajorA(:) = ka .* height;
semiMinorB(:) = config.geometry.kb .* semiMajorA;
rotation(:) = config.geometry.rotationRange .* randomBank.rotationQuantile;

softMinK = config.numerical.softMinK;
unitIndex = 0;

for indexX = 1:Nx
    for indexY = 1:Ny
        unitIndex = unitIndex + 1;

        cx = centerXBase(indexX) + ...
            (2*randomBank.positionXQuantile(unitIndex)-1) * maximumJitterX;
        cy = centerYBase(indexY) + ...
            (2*randomBank.positionYQuantile(unitIndex)-1) * maximumJitterY;

        cx = min(max(cx, periodX/2), Lx-periodX/2);
        cy = min(max(cy, periodY/2), Ly-periodY/2);

        centerX(unitIndex) = cx;
        centerY(unitIndex) = cy;

        currentHeight = height(unitIndex);
        currentA = semiMajorA(unitIndex);
        currentB = semiMinorB(unitIndex);
        currentRotation = rotation(unitIndex);

        maximumRadius = max(currentA, currentB);
        xIndices = find(x >= cx-maximumRadius & x <= cx+maximumRadius);
        yIndices = find(y >= cy-maximumRadius & y <= cy+maximumRadius);

        if isempty(xIndices) || isempty(yIndices)
            continue;
        end

        [Xlocal, Ylocal] = meshgrid(x(xIndices), y(yIndices));

        [positiveCap, insideCap] = ellipsoid_cap_positive( ...
            Xlocal, Ylocal, cx, cy, currentA, currentB, ...
            currentHeight, currentRotation);
        negativeCap = -positiveCap;

        oldLocalSurface = Z(yIndices, xIndices);
        oldLocalCoverage = coveredMask(yIndices, xIndices);
        newLocalSurface = oldLocalSurface;

        firstCoverage = insideCap & ~oldLocalCoverage;
        overlapCoverage = insideCap & oldLocalCoverage;

        newLocalSurface(firstCoverage) = negativeCap(firstCoverage);

        if any(overlapCoverage(:))
            newLocalSurface(overlapCoverage) = stable_softmin_two( ...
                oldLocalSurface(overlapCoverage), ...
                negativeCap(overlapCoverage), softMinK);
        end

        Z(yIndices, xIndices) = newLocalSurface;
        coveredMask(yIndices, xIndices) = oldLocalCoverage | insideCap;
    end
end

surface.x = x;
surface.y = y;
surface.Z = Z;
surface.dx = dx;
surface.dy = dy;
surface.sizeX = Lx;
surface.sizeY = Ly;
surface.resolutionX = resX;
surface.resolutionY = resY;
surface.coveredFraction = nnz(coveredMask) / numel(coveredMask);
surface.minimumHeight = min(Z(:));
surface.maximumHeight = max(Z(:));

if config.numerical.returnCoverageMask
    surface.coveredMask = coveredMask;
else
    surface.coveredMask = [];
end

unitId = (1:unitCount).';
gridIndexX = repelem((1:Nx).', Ny, 1);
gridIndexY = repmat((1:Ny).', Nx, 1);
units = table( ...
    unitId, gridIndexX(:), gridIndexY(:), centerX, centerY, ...
    height, ka, semiMajorA, semiMinorB, rotation, ...
    'VariableNames', { ...
    'unitId', 'gridIndexX', 'gridIndexY', 'centerX_mm', 'centerY_mm', ...
    'height_mm', 'ka', 'semiMajorA_mm', 'semiMinorB_mm', 'rotation_rad'});
end

function result = stable_softmin_two(firstSurface, secondSurface, k)
maximumExponent = max(-k.*firstSurface, -k.*secondSurface);
result = -(maximumExponent + log( ...
    exp(-k.*firstSurface-maximumExponent) + ...
    exp(-k.*secondSurface-maximumExponent))) ./ k;
end

function validate_bank_for_surface(randomBank, config)
expectedCount = config.geometry.Nx * config.geometry.Ny;
requiredFields = { ...
    'positionXQuantile', 'positionYQuantile', 'heightQuantile', ...
    'kaQuantile', 'rotationQuantile', 'unitCount'};

for index = 1:numel(requiredFields)
    assert(isfield(randomBank, requiredFields{index}), ...
        'Common random-sample bank is missing field %s.', requiredFields{index});
end

assert(randomBank.unitCount == expectedCount, ...
    'Random-sample bank contains %d units, but the current configuration requires %d.', ...
    randomBank.unitCount, expectedCount);

quantileFields = requiredFields(1:5);
for index = 1:numel(quantileFields)
    values = randomBank.(quantileFields{index});
    assert(iscolumn(values) && numel(values) == expectedCount, ...
        'Random-sample field %s size does not match the current array.', quantileFields{index});
    assert(all(isfinite(values)) && all(values >= 0) && all(values <= 1), ...
        'Random-sample field %s must contain finite values within [0,1].', quantileFields{index});
end
end
