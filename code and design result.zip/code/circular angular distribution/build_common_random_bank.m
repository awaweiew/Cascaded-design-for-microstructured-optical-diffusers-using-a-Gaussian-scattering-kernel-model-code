% Build common random samples.
function randomBank = build_common_random_bank(config)

validate_diffuser_config(config);

unitCount = config.geometry.Nx * config.geometry.Ny;

stream = RandStream('mt19937ar', 'Seed', config.random.seed);

randomBank.positionXQuantile = rand(stream, unitCount, 1);
randomBank.positionYQuantile = rand(stream, unitCount, 1);
randomBank.heightQuantile    = rand(stream, unitCount, 1);
randomBank.kaQuantile        = rand(stream, unitCount, 1);
randomBank.rotationQuantile  = rand(stream, unitCount, 1);

randomBank.seed = config.random.seed;
randomBank.unitCount = unitCount;
randomBank.arraySize = [config.geometry.Ny, config.geometry.Nx];
randomBank.generator = 'mt19937ar';

quantileFloor = eps('double');
quantileCeiling = 1 - eps('double');
fieldsToClamp = { ...
    'heightQuantile', 'kaQuantile'};
for index = 1:numel(fieldsToClamp)
    fieldName = fieldsToClamp{index};
    values = randomBank.(fieldName);
    randomBank.(fieldName) = min(max(values, quantileFloor), quantileCeiling);
end

validate_random_bank(randomBank, config);
end

function validate_random_bank(randomBank, config)
expectedCount = config.geometry.Nx * config.geometry.Ny;
requiredFields = { ...
    'positionXQuantile', 'positionYQuantile', 'heightQuantile', ...
    'kaQuantile', 'rotationQuantile'};

for index = 1:numel(requiredFields)
    fieldName = requiredFields{index};
    assert(isfield(randomBank, fieldName), ...
        'Common random-sample bank is missing field %s.', fieldName);
    values = randomBank.(fieldName);
    assert(iscolumn(values) && numel(values) == expectedCount, ...
        'Common random-sample field %s must have length %d.', fieldName, expectedCount);
    assert(all(isfinite(values)) && all(values >= 0) && all(values <= 1), ...
        'Common random-sample field %s must lie within [0,1].', fieldName);
end
end
