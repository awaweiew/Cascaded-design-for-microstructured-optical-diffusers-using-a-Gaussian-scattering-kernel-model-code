% Run first-module tests.

clear;
clc;

config = create_diffuser_config();
config.numerical.resolutionX = 240;
config.numerical.resolutionY = 220;
validate_diffuser_config(config);

bankFirst = build_common_random_bank(config);
bankSecond = build_common_random_bank(config);

assert(isequal(bankFirst.heightQuantile, bankSecond.heightQuantile), ...
    'Identical seed did not reproduce height common random quantiles.');
assert(isequal(bankFirst.kaQuantile, bankSecond.kaQuantile), ...
    'Identical seed did not reproduce k_a common random quantiles.');

[surfaceFirst, unitsFirst] = generate_diffuser_surface(config, bankFirst);
[surfaceSecond, unitsSecond] = generate_diffuser_surface(config, bankSecond);

assert(isequal(surfaceFirst.Z, surfaceSecond.Z), ...
    'Identical configuration and common samples did not reproduce the same surface.');
assert(isequal(unitsFirst, unitsSecond), ...
    'Identical configuration and common samples did not reproduce the same microstructure parameters.');

assert(all(surfaceFirst.Z(:) <= 0), 'Surface contains positive heights, violating the concave-surface convention.');
assert(any(surfaceFirst.Z(:) < 0), 'Surface contains no concavities.');

assert(all(unitsFirst.height_mm >= config.height.minimum) && ...
       all(unitsFirst.height_mm <= config.height.maximum), ...
    'Generated heights are outside configured bounds.');
assert(all(unitsFirst.ka >= config.aspectKa.minimum) && ...
       all(unitsFirst.ka <= config.aspectKa.maximum), ...
    'Generated k_a values are outside configured bounds.');
assert(all(abs(unitsFirst.semiMajorA_mm - ...
       unitsFirst.ka.*unitsFirst.height_mm) < 100*eps), ...
    'Semi-major axis does not satisfy a=k_a*h.');
assert(all(abs(unitsFirst.semiMinorB_mm - ...
       config.geometry.kb.*unitsFirst.semiMajorA_mm) < 100*eps), ...
    'Semi-minor axis does not satisfy b=k_b*a.');

fprintf('All first-three-module checks passed.\n');

