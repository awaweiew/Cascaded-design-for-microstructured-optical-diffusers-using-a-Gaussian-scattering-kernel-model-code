% Extract Gaussian kernel statistics.
function kernelStats = extract_gaussian_kernel_stats(config, surfaceData, units)

validate_diffuser_config(config);

x = surfaceData.x;
y = surfaceData.y;
Z = surfaceData.Z;
dx = surfaceData.dx;
dy = surfaceData.dy;

[slopeXFull, slopeYFull] = gradient(Z, dx, dy);

unitCount = height(units);
validKernel = false(unitCount,1);
effectivePixelCount = zeros(unitCount,1);
effectiveArea = zeros(unitCount,1);
effectiveMajorWidth = zeros(unitCount,1);
effectiveMinorWidth = zeros(unitCount,1);
meanThetaX = nan(unitCount,1);
meanThetaY = nan(unitCount,1);
covariance11 = nan(unitCount,1);
covariance12 = nan(unitCount,1);
covariance22 = nan(unitCount,1);
sigmaMajor = nan(unitCount,1);
sigmaMinor = nan(unitCount,1);
weight = zeros(unitCount,1);

angleSpacing = (config.angular.maximumDegree-config.angular.minimumDegree)/ ...
    (config.angular.sampleCount-1);
minimumSigmaDegree = config.kernel.minimumSigmaGridFactor*angleSpacing;

absoluteDominationTolerance = ...
    config.effectiveRegion.dominationToleranceFactor/config.numerical.softMinK;
relativeDominationTolerance = ...
    config.effectiveRegion.dominationToleranceRelative;
edgeDepthFraction = config.effectiveRegion.edgeDepthFraction;
minimumPixelCount = config.effectiveRegion.minimumPixelCount;

for unitIndex = 1:unitCount
    cx = units.centerX_mm(unitIndex);
    cy = units.centerY_mm(unitIndex);
    h = units.height_mm(unitIndex);
    a = units.semiMajorA_mm(unitIndex);
    b = units.semiMinorB_mm(unitIndex);
    rotation = units.rotation_rad(unitIndex);

    maximumRadius = max(a,b);
    xIndices = find(x >= cx-maximumRadius & x <= cx+maximumRadius);
    yIndices = find(y >= cy-maximumRadius & y <= cy+maximumRadius);
    if isempty(xIndices) || isempty(yIndices)
        continue;
    end

    [Xlocal,Ylocal] = meshgrid(x(xIndices),y(yIndices));
    Zlocal = Z(yIndices,xIndices);
    candidateCap = -ellipsoid_cap_positive( ...
        Xlocal,Ylocal,cx,cy,a,b,h,rotation);

    insideCandidate = candidateCap < -edgeDepthFraction*h;
    dominationTolerance = absoluteDominationTolerance + ...
        relativeDominationTolerance*h;
    dominatedByUnit = abs(Zlocal-candidateCap) <= dominationTolerance;
    effectiveMask = insideCandidate & dominatedByUnit;

    rawEffectiveCount = nnz(effectiveMask);
    if rawEffectiveCount < minimumPixelCount
        continue;
    end

    slopeXLocal = slopeXFull(yIndices,xIndices);
    slopeYLocal = slopeYFull(yIndices,xIndices);
    slopeX = slopeXLocal(effectiveMask);
    slopeY = slopeYLocal(effectiveMask);

    [thetaSampleX,thetaSampleY,validSnell] = slope_to_output_angles_snell( ...
        slopeX,slopeY,config.optical.nAir,config.optical.nSubstrate);
    thetaSampleX = thetaSampleX(validSnell);
    thetaSampleY = thetaSampleY(validSnell);
    transmittedCount = numel(thetaSampleX);
    if transmittedCount < minimumPixelCount
        continue;
    end

    rawMeanX = mean(thetaSampleX,'omitnan');
    rawMeanY = mean(thetaSampleY,'omitnan');
    meanThetaX(unitIndex) = config.kernel.meanDirectionScale*rawMeanX;
    meanThetaY(unitIndex) = config.kernel.meanDirectionScale*rawMeanY;

    centeredAngles = [thetaSampleX-rawMeanX,thetaSampleY-rawMeanY];
    if size(centeredAngles,1) >= 2
        covariance = cov(centeredAngles,'omitrows');
    else
        covariance = minimumSigmaDegree^2*eye(2);
    end

    if any(~isfinite(covariance(:))) || rank(covariance) < 2
        covariance = minimumSigmaDegree^2*eye(2);
    end

    covariance = config.kernel.sigmaScale^2*covariance + ...
        minimumSigmaDegree^2*eye(2);
    covariance = 0.5*(covariance+covariance.');
    [eigenvectors,eigenvalues] = eig(covariance);
    eigenvalueVector = max(diag(eigenvalues),minimumSigmaDegree^2);
    covariance = eigenvectors*diag(eigenvalueVector)*eigenvectors.';

    covariance11(unitIndex) = covariance(1,1);
    covariance12(unitIndex) = covariance(1,2);
    covariance22(unitIndex) = covariance(2,2);
    sigmaValues = sort(sqrt(eig(covariance)),'descend');
    sigmaMajor(unitIndex) = sigmaValues(1);
    sigmaMinor(unitIndex) = sigmaValues(end);

    effectivePixelCount(unitIndex) = transmittedCount;
    effectiveArea(unitIndex) = transmittedCount*dx*dy;
    if config.kernel.useEffectiveAreaWeight
        weight(unitIndex) = effectiveArea(unitIndex);
    else
        weight(unitIndex) = 1;
    end

    xEffective = Xlocal(effectiveMask);
    yEffective = Ylocal(effectiveMask);
    centeredPosition = [ ...
        xEffective-mean(xEffective),yEffective-mean(yEffective)];
    if size(centeredPosition,1) >= 2
        positionCovariance = cov(centeredPosition,'omitrows');
        if all(isfinite(positionCovariance(:)))
            positionEigenvalues = sort(eig( ...
                0.5*(positionCovariance+positionCovariance.')),'descend');
            effectiveMajorWidth(unitIndex) = ...
                2*sqrt(max(positionEigenvalues(1),0));
            effectiveMinorWidth(unitIndex) = ...
                2*sqrt(max(positionEigenvalues(end),0));
        end
    end

    validKernel(unitIndex) = true;
end

kernelStats.table = table( ...
    units.unitId,validKernel,effectivePixelCount,effectiveArea, ...
    effectiveMajorWidth,effectiveMinorWidth,meanThetaX,meanThetaY, ...
    covariance11,covariance12,covariance22,sigmaMajor,sigmaMinor,weight, ...
    'VariableNames',{ ...
    'unitId','validKernel','effectivePixelCount','effectiveArea_mm2', ...
    'effectiveMajorWidth_mm','effectiveMinorWidth_mm', ...
    'meanThetaX_deg','meanThetaY_deg','cov11_deg2','cov12_deg2', ...
    'cov22_deg2','sigmaMajor_deg','sigmaMinor_deg','weight'});
kernelStats.validCount = nnz(validKernel);
kernelStats.skippedCount = unitCount-kernelStats.validCount;
kernelStats.minimumSigmaDegree = minimumSigmaDegree;
kernelStats.absoluteDominationTolerance_mm = absoluteDominationTolerance;
end
