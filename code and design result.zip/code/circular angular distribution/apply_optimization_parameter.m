% Apply optimization parameters.
function updatedConfig = apply_optimization_parameter(config, parameter, value, skipValidation)

if nargin < 4
    skipValidation = false;
end

assert(isscalar(value) && isfinite(value), 'Candidate parameter value must be a finite scalar.');
assert(value >= parameter.lowerBound-10*eps && ...
       value <= parameter.upperBound+10*eps, ...
    'Candidate value for %s is outside the configured range.',parameter.name);

if parameter.isInteger
    value = round(value);
end

updatedConfig = config;
switch parameter.application
    case 'kaScale'
        updatedConfig.aspectKa.minimum = ...
            config.optimization.baseAspectKaMinimum*value;
        updatedConfig.aspectKa.maximum = ...
            config.optimization.baseAspectKaMaximum*value;
        updatedConfig.optimization.currentKaScale = value;

    case 'direct'
        pathParts = strsplit(char(parameter.targetPath),'.');
        updatedConfig = set_nested_field_local(updatedConfig,pathParts,value);

    case 'arrayN'
        updatedConfig.geometry.Nx = value;
        updatedConfig.geometry.Ny = value;

    otherwise
        error('Unsupported parameter application type: %s.',parameter.application);
end

if ~skipValidation
    validate_diffuser_config(updatedConfig);
end
end

function structure = set_nested_field_local(structure,pathParts,value)
fieldName = pathParts{1};
assert(isfield(structure,fieldName), 'Configuration field path does not exist: %s.',fieldName);
if isscalar(pathParts)
    structure.(fieldName) = value;
else
    structure.(fieldName) = set_nested_field_local( ...
        structure.(fieldName),pathParts(2:end),value);
end
end
