% Read optimization parameter values.
function value = get_optimization_parameter_value(config, parameter)

switch parameter.application
    case 'kaScale'
        value = config.optimization.currentKaScale;
    case 'direct'
        pathParts = strsplit(char(parameter.targetPath),'.');
        value = get_nested_field_local(config,pathParts);
    case 'arrayN'
        assert(config.geometry.Nx == config.geometry.Ny, ...
            'arrayN requires Nx and Ny to be equal.');
        value = config.geometry.Nx;
    otherwise
        error('Unsupported parameter retrieval type: %s.',parameter.application);
end
end

function value = get_nested_field_local(structure,pathParts)
fieldName = pathParts{1};
assert(isfield(structure,fieldName), 'Configuration field path does not exist: %s.',fieldName);
if isscalar(pathParts)
    value = structure.(fieldName);
else
    value = get_nested_field_local(structure.(fieldName),pathParts(2:end));
end
end
