% Evaluate a diffuser candidate.
function evaluation = evaluate_diffuser_candidate(config, randomBank, options)

if nargin < 3
    options = struct();
end
options = fill_evaluation_options_local(config,options);

evaluation = empty_evaluation_local();
startTime = tic;

try
    candidateConfig = config;
    candidateConfig.numerical.resolutionX = options.resolutionX;
    candidateConfig.numerical.resolutionY = options.resolutionY;

    if ~options.retainLargeData
        candidateConfig.numerical.returnCoverageMask = false;
    end
    validate_diffuser_config(candidateConfig);

    expectedUnitCount = candidateConfig.geometry.Nx*candidateConfig.geometry.Ny;
    if randomBank.unitCount ~= expectedUnitCount || ...
       randomBank.seed ~= candidateConfig.random.seed
        candidateBank = build_common_random_bank(candidateConfig);
    else
        candidateBank = randomBank;
    end

    [surfaceData,units] = generate_diffuser_surface(candidateConfig,candidateBank);
    kernelStats = extract_gaussian_kernel_stats(candidateConfig,surfaceData,units);
    angularDistribution = assemble_gaussian_distribution( ...
        candidateConfig,kernelStats,options.angularMode);
    metrics = measure_scattering_fwhm(candidateConfig,angularDistribution);

    if ~isfinite(metrics.primaryFwhmDegree)
        error('Unable to obtain a valid primary FWHM on the current angular grid.');
    end

    evaluation.status = 'valid';
    evaluation.objectiveDegree = metrics.absoluteErrorDegree;
    evaluation.signedErrorDegree = metrics.signedErrorDegree;
    evaluation.primaryFwhmDegree = metrics.primaryFwhmDegree;
    evaluation.fwhmCenterXDegree = metrics.fwhmCenterXDegree;
    evaluation.fwhmCenterYDegree = metrics.fwhmCenterYDegree;
    evaluation.fwhmRadialDegree = metrics.fwhmRadialDegree;
    evaluation.anisotropyDegree = metrics.anisotropyDegree;
    evaluation.withinTolerance = metrics.withinTolerance;
    evaluation.validKernelCount = kernelStats.validCount;
    evaluation.skippedKernelCount = kernelStats.skippedCount;
    evaluation.coveredFraction = surfaceData.coveredFraction;
    evaluation.minimumSurfaceHeight_mm = surfaceData.minimumHeight;
    evaluation.errorMessage = '';

    if options.retainLargeData
        evaluation.config = candidateConfig;
        evaluation.randomBank = candidateBank;
        evaluation.surfaceData = surfaceData;
        evaluation.units = units;
        evaluation.kernelStats = kernelStats;
        evaluation.angularDistribution = angularDistribution;
        evaluation.metrics = metrics;
    end
catch exception
    evaluation.status = 'invalid';
    evaluation.objectiveDegree = Inf;
    evaluation.errorMessage = exception.message;
    if options.failFast
        rethrow(exception);
    end
end

evaluation.elapsedSecond = toc(startTime);
evaluation.resolutionX = options.resolutionX;
evaluation.resolutionY = options.resolutionY;
evaluation.fromCache = false;
end

function options = fill_evaluation_options_local(config,options)
if ~isfield(options,'resolutionX')
    options.resolutionX = config.numerical.resolutionX;
end
if ~isfield(options,'resolutionY')
    options.resolutionY = config.numerical.resolutionY;
end
if ~isfield(options,'retainLargeData')
    options.retainLargeData = false;
end
if ~isfield(options,'failFast')
    options.failFast = config.optimization.failFast;
end
if ~isfield(options,'angularMode')
    options.angularMode = 'full';
end
if strcmp(config.target.metric,'radialAverage')
    options.angularMode = 'full';
end
end

function evaluation = empty_evaluation_local()
evaluation = struct( ...
    'status','invalid', ...
    'objectiveDegree',Inf, ...
    'signedErrorDegree',NaN, ...
    'primaryFwhmDegree',NaN, ...
    'fwhmCenterXDegree',NaN, ...
    'fwhmCenterYDegree',NaN, ...
    'fwhmRadialDegree',NaN, ...
    'anisotropyDegree',NaN, ...
    'withinTolerance',false, ...
    'validKernelCount',0, ...
    'skippedKernelCount',0, ...
    'coveredFraction',NaN, ...
    'minimumSurfaceHeight_mm',NaN, ...
    'errorMessage','', ...
    'elapsedSecond',NaN, ...
    'resolutionX',NaN, ...
    'resolutionY',NaN, ...
    'fromCache',false);
end
