% Validate designs across random seeds.
function validation = validate_design_across_seeds(config,seeds,resolutionX,resolutionY)

seedCount = numel(seeds);
seedColumn = seeds(:);
status = strings(seedCount,1);
primaryFwhmDegree = nan(seedCount,1);
objectiveDegree = inf(seedCount,1);
fwhmCenterXDegree = nan(seedCount,1);
fwhmCenterYDegree = nan(seedCount,1);
fwhmRadialDegree = nan(seedCount,1);
validKernelCount = zeros(seedCount,1);
elapsedSecond = nan(seedCount,1);
errorMessage = strings(seedCount,1);

options.resolutionX = resolutionX;
options.resolutionY = resolutionY;
options.retainLargeData = false;
options.failFast = false;

for seedIndex = 1:seedCount
    seedConfig = config;
    seedConfig.random.seed = seedColumn(seedIndex);
    bank = build_common_random_bank(seedConfig);
    evaluation = evaluate_diffuser_candidate(seedConfig,bank,options);

    status(seedIndex) = string(evaluation.status);
    primaryFwhmDegree(seedIndex) = evaluation.primaryFwhmDegree;
    objectiveDegree(seedIndex) = evaluation.objectiveDegree;
    fwhmCenterXDegree(seedIndex) = evaluation.fwhmCenterXDegree;
    fwhmCenterYDegree(seedIndex) = evaluation.fwhmCenterYDegree;
    fwhmRadialDegree(seedIndex) = evaluation.fwhmRadialDegree;
    validKernelCount(seedIndex) = evaluation.validKernelCount;
    elapsedSecond(seedIndex) = evaluation.elapsedSecond;
    errorMessage(seedIndex) = string(evaluation.errorMessage);
end

validation.perSeed = table( ...
    seedColumn,status,primaryFwhmDegree,objectiveDegree, ...
    fwhmCenterXDegree,fwhmCenterYDegree,fwhmRadialDegree, ...
    validKernelCount,elapsedSecond,errorMessage);

validValues = primaryFwhmDegree(isfinite(primaryFwhmDegree));
if isempty(validValues)
    validation.meanFwhmDegree = NaN;
    validation.standardDeviationDegree = NaN;
    validation.meanAbsoluteErrorDegree = Inf;
    validation.maximumAbsoluteErrorDegree = Inf;
else
    validation.meanFwhmDegree = mean(validValues);
    validation.standardDeviationDegree = std(validValues);
    validation.meanAbsoluteErrorDegree = ...
        mean(abs(validValues-config.target.fwhmDegree));
    validation.maximumAbsoluteErrorDegree = ...
        max(abs(validValues-config.target.fwhmDegree));
end
validation.validSeedCount = numel(validValues);
validation.totalSeedCount = seedCount;
end

