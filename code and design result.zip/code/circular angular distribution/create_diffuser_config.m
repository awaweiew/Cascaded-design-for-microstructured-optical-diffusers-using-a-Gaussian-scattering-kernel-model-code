% Create diffuser configuration.
function config = create_diffuser_config()


config.geometry.Lx = 0.5;
config.geometry.Ly = 0.5;

config.geometry.Nx = 60;
config.geometry.Ny = 60;

config.geometry.positionJitterFraction = 0.4;

config.geometry.rotationRange = pi;


config.height.minimum = 0.018;
config.height.maximum = 0.030;

config.height.alpha = 1.22;
config.height.beta  = 4.48;


config.aspectKa.minimum = 0.60;
config.aspectKa.maximum = 0.85;

config.aspectKa.alpha = 1.62;
config.aspectKa.beta  = 2.05;

config.geometry.kb = 0.60;


config.numerical.resolutionX = 5000;
config.numerical.resolutionY = 5000;

config.numerical.softMinK = 2500;

config.numerical.returnCoverageMask = true;

config.numerical.searchResolutionX = 1200;
config.numerical.searchResolutionY = 1200;


config.optical.nAir = 1.0;
config.optical.nSubstrate = 1.49;

config.target.fwhmDegree = 30.0;
config.target.angleToleranceDegree = 0.1;

config.target.metric = 'centerCutX';


config.effectiveRegion.dominationToleranceFactor = 5.0;
config.effectiveRegion.dominationToleranceRelative = 0.02;

config.effectiveRegion.edgeDepthFraction = 0.03;
config.effectiveRegion.minimumPixelCount = 5;

config.kernel.meanDirectionScale = 1.0;
config.kernel.sigmaScale = 1.15;
config.kernel.useEffectiveAreaWeight = true;

config.kernel.minimumSigmaGridFactor = 0.50;

config.angular.minimumDegree = -60;
config.angular.maximumDegree = 60;
config.angular.sampleCount = 301;

config.measurement.radialBinCount = 300;


config.random.seed = 1;

config.random.useCommonRandomNumbers = true;


config.optimization.baseAspectKaMinimum = config.aspectKa.minimum;
config.optimization.baseAspectKaMaximum = config.aspectKa.maximum;
config.optimization.currentKaScale = 1.0;

config.optimization.parameters = struct( ...
    'name', { ...
        'kaScale', 'kb', 'alphaKa', 'betaKa', ...
        'heightMinimum', 'heightMaximum', 'alphaHeight', 'betaHeight', ...
        'positionJitter', 'rotationRange', 'arrayN'}, ...
    'enabled', { ...
        true, true, false, false, false, false, false, false, false, false, false}, ...
    'application', { ...
        'kaScale', 'direct', 'direct', 'direct', ...
        'direct', 'direct', 'direct', 'direct', ...
        'direct', 'direct', 'arrayN'}, ...
    'targetPath', { ...
        '', 'geometry.kb', 'aspectKa.alpha', 'aspectKa.beta', ...
        'height.minimum', 'height.maximum', 'height.alpha', 'height.beta', ...
        'geometry.positionJitterFraction', 'geometry.rotationRange', ''}, ...
    'lowerBound', { ...
        0.95, 0.55, 1.00, 1.00, 0.014, 0.026, 0.80, 2.00, 0.10, 0, 40}, ...
    'upperBound', { ...
        1.05, 0.70, 3.00, 4.00, 0.022, 0.036, 3.00, 7.00, 0.80, pi, 80}, ...
    'initialValue', { ...
        1.00, 0.60, 1.62, 2.05, 0.018, 0.030, 1.22, 4.48, 0.40, pi, 60}, ...
    'coarseStep', { ...
        0.01, 0.01, 0.20, 0.20, 0.001, 0.001, 0.20, 0.25, 0.10, pi/12, 5}, ...
    'fineStep', { ...
        0.002, 0.002, 0.05, 0.05, 0.0002, 0.0002, 0.05, 0.05, 0.02, pi/60, 1}, ...
    'isInteger', { ...
        false, false, false, false, false, false, false, false, false, false, true});

config.optimization.maximumSweeps = 3;
config.optimization.noImprovementPatience = 2;
config.optimization.maximumEvaluationsPerParameter = 50;

config.optimization.minimumSweepImprovementDegree = 0.01;

config.optimization.performMultiSeedValidation = true;
config.optimization.validationSeeds = 1:5;

config.optimization.failFast = false;

config.optimization.useTargetOnlyAngularDuringSearch = true;


validate_diffuser_config(config);
end
