% Run the first three modules.

clear;
clc;
close all;

config = create_diffuser_config();


validate_diffuser_config(config);

randomBank = build_common_random_bank(config);

tic;
[surface, units] = generate_diffuser_surface(config, randomBank);
elapsedTime = toc;

fprintf('\nFirst three modules complete.\n');
fprintf('Microstructure count: %d\n', height(units));
fprintf('Spatial resolution: %d x %d\n', ...
    surface.resolutionX, surface.resolutionY);
fprintf('Minimum surface height: %.9f mm\n', surface.minimumHeight);
fprintf('Surface coverage fraction: %.6f\n', surface.coveredFraction);
fprintf('Surface-generation time: %.3f s\n', elapsedTime);

plotStride = max(1, ceil(max( ...
    surface.resolutionX, surface.resolutionY)/800));
rows = 1:plotStride:surface.resolutionY;
columns = 1:plotStride:surface.resolutionX;

figure('Color', 'w', 'Name', 'Diffuser surface from the first three modules');
surf( ...
    1e3*surface.x(columns), ...
    1e3*surface.y(rows), ...
    1e3*surface.Z(rows, columns), ...
    1e3*surface.Z(rows, columns), ...
    'EdgeColor', 'none');
axis equal tight;
xlabel('x (\mum)');
ylabel('y (\mum)');
zlabel('z (\mum)');
title('Random concave ellipsoidal diffuser from common samples');
colormap turbo;
colorbar;
view(45, 45);
light;
lighting gouraud;

