% Refract vectors using Snell's law.
function transmittedDirection = refract_vectors_snell( ...
        incidentDirection, interfaceNormal, refractiveIndex1, refractiveIndex2)

assert(size(incidentDirection,2) == 3 && size(interfaceNormal,2) == 3, ...
    'Incident directions and interface normals must be N-by-3 arrays.');
assert(size(incidentDirection,1) == size(interfaceNormal,1), ...
    'Incident directions and interface normals must have matching row counts.');

eta = refractiveIndex1/refractiveIndex2;
normalProjection = sum(incidentDirection.*interfaceNormal, 2);
incidentTangent = incidentDirection-normalProjection.*interfaceNormal;
transmittedTangent = eta.*incidentTangent;
transmittedTangentSquared = sum(transmittedTangent.^2, 2);

valid = isfinite(transmittedTangentSquared) & transmittedTangentSquared <= 1;
transmittedDirection = nan(size(incidentDirection));

transmittedDirection(valid,:) = transmittedTangent(valid,:) + ...
    sqrt(max(0,1-transmittedTangentSquared(valid))).*interfaceNormal(valid,:);

normValue = vecnorm(transmittedDirection(valid,:), 2, 2);
transmittedDirection(valid,:) = ...
    transmittedDirection(valid,:)./normValue;
end

