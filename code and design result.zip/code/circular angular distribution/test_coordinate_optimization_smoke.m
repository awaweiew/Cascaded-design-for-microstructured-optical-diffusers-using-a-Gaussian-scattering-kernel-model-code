% Run coordinate-search smoke tests.

clear;
clc;

config = create_diffuser_config();
config.geometry.Nx = 6;
config.geometry.Ny = 6;
config.numerical.resolutionX = 160;
config.numerical.resolutionY = 160;
config.numerical.searchResolutionX = 160;
config.numerical.searchResolutionY = 160;
config.angular.sampleCount = 81;
config.measurement.radialBinCount = 80;
config.optimization.maximumSweeps = 1;
config.optimization.maximumEvaluationsPerParameter = 5;
config.optimization.noImprovementPatience = 1;
config.optimization.performMultiSeedValidation = false;

for index = 1:numel(config.optimization.parameters)
    config.optimization.parameters(index).enabled = false;
end
index = find(strcmp({config.optimization.parameters.name},'kaScale'),1);
config.optimization.parameters(index).enabled = true;
config.optimization.parameters(index).lowerBound = 0.98;
config.optimization.parameters(index).upperBound = 1.02;
config.optimization.parameters(index).initialValue = 1.00;
config.optimization.parameters(index).coarseStep = 0.02;
config.optimization.parameters(index).fineStep = 0.01;

validate_diffuser_config(config);
bank = build_common_random_bank(config);
searchResult = run_coordinate_search(config,bank,'');

assert(~isempty(searchResult.history), 'Optimization history is empty.');
assert(height(searchResult.parameterResults) == 1, ...
    'Single-parameter single-sweep test must produce one parameter summary.');
bestScale = searchResult.parameterResults.bestValue(1);
assert(bestScale >= 0.98 && bestScale <= 1.02, ...
    'Best parameter is outside the configured range.');
assert(abs(searchResult.bestConfig.optimization.currentKaScale-bestScale) < 1e-12, ...
    'Best kaScale was not applied to the final configuration.');

fprintf('Single-parameter coordinate-search smoke test passed; kaScale = %.6f.\n',bestScale);

