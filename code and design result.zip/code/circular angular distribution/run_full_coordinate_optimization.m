% Run full coordinate optimization.

clear;
clc;
close all;

projectDirectory = fileparts(mfilename('fullpath'));
addpath(projectDirectory);


control.action = 'optimize';

control.runFinalFullResolution = false;

control.runMultiSeedValidation = false;
control.validationUseFullResolution = false;

control.createFigures = true;

config = create_diffuser_config();

config.geometry.Lx = 0.5;
config.geometry.Ly = 0.5;
config.geometry.Nx = 400;
config.geometry.Ny = 400;

config.height.minimum = 0.018;
config.height.maximum = 0.030;
config.height.alpha = 1.22;
config.height.beta = 4.48;

config.aspectKa.minimum = 0.5   .*0.93.*0.984;
config.aspectKa.maximum = 0.8   .*0.93.*0.984;
config.aspectKa.alpha = 0.4;
config.aspectKa.beta = 0.4;
config.optimization.baseAspectKaMinimum = config.aspectKa.minimum;
config.optimization.baseAspectKaMaximum = config.aspectKa.maximum;
config.optimization.currentKaScale = 1.0;

config.geometry.kb = 0.666660;
config.geometry.positionJitterFraction = 0.40;
config.geometry.rotationRange = pi;
config.numerical.softMinK = 2500;
config.optical.nAir = 1.0;
config.optical.nSubstrate = 1.49;

config.target.fwhmDegree = 30.0;
config.target.angleToleranceDegree = 0.10;
config.target.metric = 'centerCutX';

config.numerical.searchResolutionX = 600;
config.numerical.searchResolutionY = 600;
config.numerical.resolutionX = 5000;
config.numerical.resolutionY = 5000;

config.angular.minimumDegree = -60;
config.angular.maximumDegree = 60;
config.angular.sampleCount = 301;

for parameterIndex = 1:numel(config.optimization.parameters)
    config.optimization.parameters(parameterIndex).enabled = false;
end

index = find(strcmp({config.optimization.parameters.name},'kaScale'),1);
config.optimization.parameters(index).enabled = true;
config.optimization.parameters(index).lowerBound = 0.1;
config.optimization.parameters(index).upperBound = 2.0;
config.optimization.parameters(index).initialValue = 1.00;
config.optimization.parameters(index).coarseStep = 0.01;
config.optimization.parameters(index).fineStep = 0.002;

index = find(strcmp({config.optimization.parameters.name},'kb'),1);
config.optimization.parameters(index).enabled = false;
config.optimization.parameters(index).lowerBound = 0.55;
config.optimization.parameters(index).upperBound = 0.70;
config.optimization.parameters(index).initialValue = 0.60;
config.optimization.parameters(index).coarseStep = 0.01;
config.optimization.parameters(index).fineStep = 0.002;


config.optimization.maximumSweeps = 3;
config.optimization.noImprovementPatience = 5;
config.optimization.maximumEvaluationsPerParameter = 100;
config.optimization.minimumSweepImprovementDegree = 0.01;
config.optimization.validationSeeds = 1:5;
config.optimization.performMultiSeedValidation = control.runMultiSeedValidation;

validate_diffuser_config(config);

timeStamp = char(datetime('now','Format','yyyyMMdd_HHmmss'));
outputDirectory = fullfile(projectDirectory,'results',timeStamp);
if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end
fprintf('Output directory: %s\n',outputDirectory);

searchResult = [];
validation = [];

switch control.action
    case 'smokeTest'
        config.geometry.Nx = 12;
        config.geometry.Ny = 12;
        config.numerical.resolutionX = 320;
        config.numerical.resolutionY = 320;
        config.numerical.searchResolutionX = 320;
        config.numerical.searchResolutionY = 320;
        config.angular.sampleCount = 101;
        validate_diffuser_config(config);
        bank = build_common_random_bank(config);
        options.resolutionX = 320;
        options.resolutionY = 320;
        options.retainLargeData = true;
        options.failFast = true;
        options.angularMode = 'full';
        finalEvaluation = evaluate_diffuser_candidate(config,bank,options);

    case 'forwardOnly'
        bank = build_common_random_bank(config);
        options.resolutionX = config.numerical.resolutionX;
        options.resolutionY = config.numerical.resolutionY;
        options.retainLargeData = true;
        options.failFast = true;
        options.angularMode = 'full';
        finalEvaluation = evaluate_diffuser_candidate(config,bank,options);

    case 'optimize'
        bank = build_common_random_bank(config);
        searchResult = run_coordinate_search(config,bank,outputDirectory);
        bestConfig = searchResult.bestConfig;

        if control.runFinalFullResolution
            finalResolutionX = bestConfig.numerical.resolutionX;
            finalResolutionY = bestConfig.numerical.resolutionY;
        else
            finalResolutionX = bestConfig.numerical.searchResolutionX;
            finalResolutionY = bestConfig.numerical.searchResolutionY;
        end

        finalOptions.resolutionX = finalResolutionX;
        finalOptions.resolutionY = finalResolutionY;
        finalOptions.retainLargeData = true;
        finalOptions.failFast = true;
        finalOptions.angularMode = 'full';
        finalEvaluation = evaluate_diffuser_candidate( ...
            bestConfig,bank,finalOptions);

        if control.runMultiSeedValidation
            if control.validationUseFullResolution
                validationResolutionX = bestConfig.numerical.resolutionX;
                validationResolutionY = bestConfig.numerical.resolutionY;
            else
                validationResolutionX = bestConfig.numerical.searchResolutionX;
                validationResolutionY = bestConfig.numerical.searchResolutionY;
            end
            validation = validate_design_across_seeds( ...
                bestConfig,bestConfig.optimization.validationSeeds, ...
                validationResolutionX,validationResolutionY);
        end

    otherwise
        error('Unknown control.action: %s.',control.action);
end

save_optimization_results(outputDirectory,searchResult,finalEvaluation,validation);
if control.createFigures
    plot_optimization_results(finalEvaluation,searchResult,outputDirectory);
end

fprintf('\nComputation complete.\n');
fprintf('Primary metric: %s\n',finalEvaluation.metrics.primaryMetric);
fprintf('Final primary FWHM: %.6f deg\n',finalEvaluation.metrics.primaryFwhmDegree);
fprintf('Target angular error: %.6f deg\n',finalEvaluation.metrics.absoluteErrorDegree);
fprintf('Results saved to: %s\n',outputDirectory);
