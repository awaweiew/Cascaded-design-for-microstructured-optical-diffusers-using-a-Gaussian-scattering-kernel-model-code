% Measure scattering FWHM.
function metrics = measure_scattering_fwhm(config, angularDistribution)

theta = angularDistribution.thetaDegree(:);
if strcmp(angularDistribution.mode,'full')
    H = angularDistribution.normalized;
    assert(size(H,1) == numel(theta) && size(H,2) == numel(theta), ...
        'Angular-distribution dimensions must match theta-coordinate length.');
    [~,zeroIndex] = min(abs(theta));
    centerCutX = H(:,zeroIndex);
    centerCutY = H(zeroIndex,:).';
else
    H = [];
    centerCutX = angularDistribution.centerCutXNormalized;
    centerCutY = angularDistribution.centerCutYNormalized;
end

centerCutX = centerCutX/(max(centerCutX,[],'omitnan')+eps);
[leftHalfX,rightHalfX,fwhmCenterX] = find_level_width_local( ...
    theta,centerCutX,0.5);

centerCutY = centerCutY/(max(centerCutY,[],'omitnan')+eps);
[leftHalfY,rightHalfY,fwhmCenterY] = find_level_width_local( ...
    theta,centerCutY,0.5);

if strcmp(angularDistribution.mode,'full')
    [thetaXGrid,thetaYGrid] = ndgrid(theta,theta);
    radiusGrid = sqrt(thetaXGrid.^2+thetaYGrid.^2);
    maximumCompleteRadius = min(abs([theta(1),theta(end)]));
    radialEdges = linspace( ...
        0,maximumCompleteRadius,config.measurement.radialBinCount+1);
    radialCenters = 0.5*(radialEdges(1:end-1)+radialEdges(2:end));
    radialProfile = nan(size(radialCenters));

    for binIndex = 1:numel(radialCenters)
        annulusMask = radiusGrid >= radialEdges(binIndex) & ...
            radiusGrid < radialEdges(binIndex+1);
        if any(annulusMask(:))
            radialProfile(binIndex) = mean(H(annulusMask),'omitnan');
        end
    end
    radialProfileNormalized = radialProfile/ ...
        (max(radialProfile,[],'omitnan')+eps);
    radialHalfRadius = find_outward_level_radius_local( ...
        radialCenters,radialProfileNormalized,0.5);
    fwhmRadial = 2*radialHalfRadius;
else
    radialCenters = nan(0,1);
    radialProfileNormalized = nan(0,1);
    radialHalfRadius = NaN;
    fwhmRadial = NaN;
end

switch config.target.metric
    case 'centerCutX'
        primaryFwhm = fwhmCenterX;
    case 'centerCutY'
        primaryFwhm = fwhmCenterY;
    case 'radialAverage'
        assert(strcmp(angularDistribution.mode,'full'), ...
            'Radial averaging requires the full two-dimensional angular distribution.');
        primaryFwhm = fwhmRadial;
    otherwise
        error('Unknown target metric: %s.',config.target.metric);
end

metrics.primaryMetric = config.target.metric;
metrics.primaryFwhmDegree = primaryFwhm;
metrics.targetFwhmDegree = config.target.fwhmDegree;
metrics.absoluteErrorDegree = abs(primaryFwhm-config.target.fwhmDegree);
metrics.signedErrorDegree = primaryFwhm-config.target.fwhmDegree;
metrics.withinTolerance = isfinite(primaryFwhm) && ...
    metrics.absoluteErrorDegree <= config.target.angleToleranceDegree;

metrics.fwhmCenterXDegree = fwhmCenterX;
metrics.fwhmCenterYDegree = fwhmCenterY;
metrics.fwhmRadialDegree = fwhmRadial;
metrics.leftHalfXDegree = leftHalfX;
metrics.rightHalfXDegree = rightHalfX;
metrics.leftHalfYDegree = leftHalfY;
metrics.rightHalfYDegree = rightHalfY;
metrics.radialHalfRadiusDegree = radialHalfRadius;
metrics.anisotropyDegree = abs(fwhmCenterX-fwhmCenterY);

metrics.thetaDegree = theta;
metrics.centerCutXNormalized = centerCutX;
metrics.centerCutYNormalized = centerCutY;
metrics.radialRadiusDegree = radialCenters(:);
metrics.radialProfileNormalized = radialProfileNormalized(:);
end

function [leftCross,rightCross,fullWidth] = ...
        find_level_width_local(theta,intensityNormalized,level)
theta = theta(:);
intensityNormalized = intensityNormalized(:);
valid = isfinite(theta) & isfinite(intensityNormalized);
theta = theta(valid);
intensityNormalized = intensityNormalized(valid);
leftCross = NaN;
rightCross = NaN;
fullWidth = NaN;
if isempty(theta)
    return;
end

[theta,order] = sort(theta);
intensityNormalized = intensityNormalized(order);
peakValue = max(intensityNormalized);
if ~isfinite(peakValue) || peakValue <= 0
    return;
end
intensityNormalized = intensityNormalized/peakValue;
[~,peakIndex] = max(intensityNormalized);

leftIndex = find(intensityNormalized(1:peakIndex) <= level,1,'last');
if ~isempty(leftIndex) && leftIndex < peakIndex
    leftCross = interpolate_level_local( ...
        theta(leftIndex),intensityNormalized(leftIndex), ...
        theta(leftIndex+1),intensityNormalized(leftIndex+1),level);
end

rightRelativeIndex = find( ...
    intensityNormalized(peakIndex:end) <= level,1,'first');
if ~isempty(rightRelativeIndex)
    rightIndex = peakIndex+rightRelativeIndex-1;
    if rightIndex > peakIndex
        rightCross = interpolate_level_local( ...
            theta(rightIndex-1),intensityNormalized(rightIndex-1), ...
            theta(rightIndex),intensityNormalized(rightIndex),level);
    end
end

if isfinite(leftCross) && isfinite(rightCross)
    fullWidth = rightCross-leftCross;
end
end

function radiusAtLevel = find_outward_level_radius_local( ...
        radius,intensityNormalized,level)
radius = radius(:);
intensityNormalized = intensityNormalized(:);
valid = isfinite(radius) & isfinite(intensityNormalized);
radius = radius(valid);
intensityNormalized = intensityNormalized(valid);
radiusAtLevel = NaN;
if isempty(radius)
    return;
end

[radius,order] = sort(radius);
intensityNormalized = intensityNormalized(order);
peakValue = max(intensityNormalized);
if ~isfinite(peakValue) || peakValue <= 0
    return;
end
intensityNormalized = intensityNormalized/peakValue;
[~,peakIndex] = max(intensityNormalized);
relativeIndex = find(intensityNormalized(peakIndex:end) <= level,1,'first');
if isempty(relativeIndex)
    return;
end

index2 = peakIndex+relativeIndex-1;
if index2 <= peakIndex
    radiusAtLevel = radius(index2);
else
    index1 = index2-1;
    radiusAtLevel = interpolate_level_local( ...
        radius(index1),intensityNormalized(index1), ...
        radius(index2),intensityNormalized(index2),level);
end
end

function crossing = interpolate_level_local(x1,y1,x2,y2,level)
if abs(y2-y1) < eps
    crossing = 0.5*(x1+x2);
else
    crossing = x1+(level-y1)*(x2-x1)/(y2-y1);
end
end
