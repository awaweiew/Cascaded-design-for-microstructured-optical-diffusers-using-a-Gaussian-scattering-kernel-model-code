import csv
import hashlib
import os
import re
from dataclasses import dataclass, replace
from pathlib import Path
import argparse

import matplotlib
import matplotlib.pyplot as plt
import numpy as np


matplotlib.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans", "Microsoft YaHei", "SimHei"]
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["axes.unicode_minus"] = False
matplotlib.rcParams.update({
    "font.size": 8,
    "axes.labelsize": 8,
    "axes.titlesize": 8,
    "legend.fontsize": 7,
    "xtick.labelsize": 7,
    "ytick.labelsize": 7,
    "axes.linewidth": 0.8,
    "lines.linewidth": 1.2,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.top": True,
    "ytick.right": True,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.03,
    "svg.fonttype": "none",
})


@dataclass(frozen=True)
class PostprocessConfig:
    stats_dir: str = "propagation_stats_results"
    stats_pattern: str = "stats_*.npz"
    output_dir: str = "postprocess_fig_diffuser"

    center_peak_search_px: int = 3
    cross_section_window_mm: float = 0.2

    dpi: int = 600
    verbose: bool = True

    # Limit figure filename length.
    max_tag_chars: int = 90
    max_path_chars: int = 230
    max_filename_chars: int = 150


def safe_tag(text):
    text = str(text)
    keep = []
    for ch in text:
        if ch.isalnum() or ch in ("-", "_"):
            keep.append(ch)
        elif ch in (".", " "):
            keep.append("p" if ch == "." else "_")
        else:
            keep.append("_")
    return "".join(keep).strip("_")


def compact_tag(text, max_chars=90):
    """Create a deterministic filename tag."""
    tag = safe_tag(text)
    if len(tag) <= max_chars:
        return tag

    digest = hashlib.sha256(tag.encode("utf-8")).hexdigest()[:10]
    marker = f"__{digest}__"
    keep = max_chars - len(marker)
    head_len = int(keep * 0.65)
    tail_len = keep - head_len
    return tag[:head_len] + marker + tag[-tail_len:]


def compact_file_path(path, max_path_chars=230, max_filename_chars=150):
    """Create a Windows-safe output path."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    abs_parent = str(path.parent.resolve())
    filename = path.name
    full_path = str(path.resolve())

    if len(filename) <= max_filename_chars and len(full_path) <= max_path_chars:
        return path

    suffix = path.suffix
    stem = path.stem
    digest = hashlib.sha256(filename.encode("utf-8")).hexdigest()[:12]
    marker = f"__{digest}"

    allowed_filename_chars = min(
        max_filename_chars,
        max_path_chars - len(abs_parent) - 1,
    )
    keep = allowed_filename_chars - len(marker) - len(suffix)

    if keep < 30:
        raise OSError(
            "The output directory is too long for a portable Windows path. "
            "Please use a shorter --output-dir, for example .\\figures."
        )

    head_len = int(keep * 0.65)
    tail_len = keep - head_len
    compact_name = stem[:head_len] + marker + stem[-tail_len:] + suffix
    compact_path = path.with_name(compact_name)

    if len(str(compact_path.resolve())) > max_path_chars:
        raise OSError(
            "Unable to create a Windows-safe output path. "
            "Please use a shorter --output-dir."
        )

    return compact_path


def save_oe_figure(fig, png_path, dpi, config):
    """Save PNG and SVG outputs."""
    png_path = compact_file_path(
        png_path,
        max_path_chars=config.max_path_chars,
        max_filename_chars=config.max_filename_chars,
    )
    svg_path = compact_file_path(
        png_path.with_suffix(".svg"),
        max_path_chars=config.max_path_chars,
        max_filename_chars=config.max_filename_chars,
    )

    fig.savefig(png_path, dpi=dpi, facecolor="white")
    fig.savefig(svg_path, facecolor="white")
    return png_path, svg_path


def load_object_array_item(array):
    item = array[0]
    if hasattr(item, "item"):
        try:
            item = item.item()
        except Exception:
            pass
    return item


def load_meta(data):
    if "meta" not in data:
        return {}
    meta = load_object_array_item(data["meta"])
    return meta if isinstance(meta, dict) else {}


def load_refs(data):
    if "refs" not in data:
        return {}
    refs = load_object_array_item(data["refs"])
    return refs if isinstance(refs, dict) else {}


def parse_float_meta(meta, *keys):
    for key in keys:
        if key in meta:
            try:
                return float(meta[key])
            except (TypeError, ValueError):
                pass
    return np.nan


def parse_sigmac_from_text(text):
    patterns = [
        r"(?:^|_)sigmac([0-9]+(?:p[0-9]+)?)mm",
        r"(?:^|_)c([0-9]+(?:p[0-9]+)?)(?:_|$)",
    ]
    for pattern in patterns:
        match = re.search(pattern, str(text))
        if match is not None:
            return float(match.group(1).replace("p", "."))
    return np.nan


def parse_sigmac_from_meta_or_path(meta, stats_path):
    sigma_c = parse_float_meta(meta, "source_sigma_c_mm", "sigma_c_mm")
    if np.isfinite(sigma_c):
        return sigma_c

    for key in ("source_stem", "source_gsm_file"):
        if key in meta:
            sigma_c = parse_sigmac_from_text(meta[key])
            if np.isfinite(sigma_c):
                return sigma_c

    return parse_sigmac_from_text(Path(stats_path).stem)


def result_label(stats_path, meta):
    """Create a result label."""
    ap_radius = meta.get("ap_diffuser_radius_mm", meta.get("ap_diffuser_radius", np.nan))
    mask_radius = meta.get("ap_mask_radius_mm", meta.get("ap_mask_radius", np.nan))
    ap_suffix = ""
    mask_suffix = ""
    source_suffix = ""
    prop_suffix = ""

    try:
        ap_radius = float(ap_radius)
    except (TypeError, ValueError):
        ap_radius = np.nan
    try:
        mask_radius = float(mask_radius)
    except (TypeError, ValueError):
        mask_radius = np.nan

    if np.isfinite(ap_radius):
        ap_suffix = f"_Ddiff{safe_tag(f'{2.0 * ap_radius:.12g}')}mm"
    else:
        match = re.search(r"_Ddiff([0-9]+(?:p[0-9]+)?)mm", Path(stats_path).stem)
        if match is not None:
            ap_suffix = f"_Ddiff{match.group(1)}mm"

    # Retain mask metadata in labels and CSV output.
    if np.isfinite(mask_radius):
        mask_suffix = f"_Dmask{safe_tag(f'{2.0 * mask_radius:.12g}')}mm"

    sigma_c = parse_sigmac_from_meta_or_path(meta, stats_path)
    if np.isfinite(sigma_c):
        source_suffix = f"_sigmac{safe_tag(f'{sigma_c:.12g}')}mm"

    try:
        z_back = float(meta.get("z_back_mm", meta.get("z_back", np.nan)))
        z_2m = float(meta.get("z_2m_mm", meta.get("z_2m", np.nan)))
    except (TypeError, ValueError):
        z_back = np.nan
        z_2m = np.nan

    if np.isfinite(z_back):
        prop_suffix += f"_zback{safe_tag(f'{z_back:.12g}')}mm"
    if np.isfinite(z_2m):
        prop_suffix += f"_z2m{safe_tag(f'{z_2m:.12g}')}mm"

    if "diffuser_stem" in meta:
        return f"{meta['diffuser_stem']}{ap_suffix}{mask_suffix}{source_suffix}{prop_suffix}"
    if "diffuser_file" in meta:
        return f"{Path(str(meta['diffuser_file'])).stem}{ap_suffix}{mask_suffix}{source_suffix}{prop_suffix}"
    return f"{Path(stats_path).stem.replace('stats_', '', 1)}{mask_suffix}{source_suffix}{prop_suffix}"


def reference_from_refs(refs, key, x, y):
    if key in refs and isinstance(refs[key], dict):
        ref = refs[key]
        if all(k in ref for k in ("iy", "ix", "x", "y")):
            return ref

    iy = len(y) // 2
    ix = len(x) // 2
    return {
        "name": key,
        "iy": int(iy),
        "ix": int(ix),
        "x": float(x[ix]),
        "y": float(y[iy]),
    }


def degree_of_coherence_from_J(I, J_center, ref):
    eps = 1e-30
    I_ref = float(I[ref["iy"], ref["ix"]])
    return J_center / np.sqrt(np.maximum(I_ref * I, eps))


def measure_center_peak_fwhm_direct(x, y, x0, center_search_px=3):
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)

    valid = np.isfinite(x) & np.isfinite(y) & (y > 0)
    if np.sum(valid) < 5:
        return {
            "ok": False,
            "fwhm_mm": np.nan,
            "left_half_mm": np.nan,
            "right_half_mm": np.nan,
            "peak_x_mm": np.nan,
            "peak_y": np.nan,
            "reason": "too few valid points",
        }

    i0 = int(np.argmin(np.abs(x - x0)))
    i_left = max(0, i0 - center_search_px)
    i_right = min(len(x) - 1, i0 + center_search_px)

    local_y = y[i_left:i_right + 1]
    if np.all(~np.isfinite(local_y)):
        return {
            "ok": False,
            "fwhm_mm": np.nan,
            "left_half_mm": np.nan,
            "right_half_mm": np.nan,
            "peak_x_mm": np.nan,
            "peak_y": np.nan,
            "reason": "no valid points near reference",
        }

    i_peak = i_left + int(np.nanargmax(local_y))
    peak = float(y[i_peak])
    if not np.isfinite(peak) or peak <= 0:
        return {
            "ok": False,
            "fwhm_mm": np.nan,
            "left_half_mm": np.nan,
            "right_half_mm": np.nan,
            "peak_x_mm": float(x[i_peak]),
            "peak_y": peak,
            "reason": "invalid peak",
        }

    y_norm = y / peak
    half = 0.5

    left_half = np.nan
    for i in range(i_peak, 0, -1):
        if not np.isfinite(y_norm[i]) or not np.isfinite(y_norm[i - 1]):
            continue
        if y_norm[i] >= half and y_norm[i - 1] < half:
            x1, x2 = x[i - 1], x[i]
            y1, y2 = y_norm[i - 1], y_norm[i]
            left_half = x1 + (half - y1) * (x2 - x1) / (y2 - y1 + 1e-30)
            break

    right_half = np.nan
    for i in range(i_peak, len(x) - 1):
        if not np.isfinite(y_norm[i]) or not np.isfinite(y_norm[i + 1]):
            continue
        if y_norm[i] >= half and y_norm[i + 1] < half:
            x1, x2 = x[i], x[i + 1]
            y1, y2 = y_norm[i], y_norm[i + 1]
            right_half = x1 + (half - y1) * (x2 - x1) / (y2 - y1 + 1e-30)
            break

    ok = bool(np.isfinite(left_half) and np.isfinite(right_half))
    return {
        "ok": ok,
        "fwhm_mm": float(right_half - left_half) if ok else np.nan,
        "left_half_mm": float(left_half) if np.isfinite(left_half) else np.nan,
        "right_half_mm": float(right_half) if np.isfinite(right_half) else np.nan,
        "peak_x_mm": float(x[i_peak]),
        "peak_y": peak,
        "reason": "ok" if ok else "missing half-maximum crossing",
    }


def plot_three_coherence_cross_sections(
    x_source,
    source_line,
    source_fwhm,
    x_pupil,
    pupil_x_line,
    pupil_x_fwhm,
    y_pupil,
    pupil_y_line,
    pupil_y_fwhm,
    tag,
    config,
):
    """Plot coherence cross-sections."""
    fig, ax = plt.subplots(figsize=(7.2, 4.8), constrained_layout=True)

    ax.plot(x_source, source_line, linewidth=1.7, label="Source")
    ax.plot(x_pupil, pupil_x_line, linewidth=1.7, label="Pupil X direction")
    ax.plot(y_pupil, pupil_y_line, linewidth=1.7, label="Pupil Y direction")
    ax.axhline(0.5, linewidth=1.0, linestyle="--", label="Half maximum")

    ax.set_title("Complex degree of coherence cross-sections")
    ax.set_xlabel("transverse coordinate (mm)")
    ax.set_ylabel("|j(center, r)|")

    if config.cross_section_window_mm is not None and config.cross_section_window_mm > 0:
        half_window = 0.5 * config.cross_section_window_mm
        ax.set_xlim(-half_window, half_window)

    ax.set_ylim(-0.03, 1.05)
    ax.grid(True, alpha=0.25, linewidth=0.6)
    ax.legend(frameon=False)

    def fmt_fwhm(name, item):
        if item["ok"]:
            return f"{name} FWHM = {item['fwhm_mm']:.6g} mm"
        return f"{name} FWHM = N/A"

    text = "\n".join([
        fmt_fwhm("Source", source_fwhm),
        fmt_fwhm("Pupil X", pupil_x_fwhm),
        fmt_fwhm("Pupil Y", pupil_y_fwhm),
    ])
    ax.text(
        0.98,
        0.96,
        text,
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=8,
        bbox={"facecolor": "white", "edgecolor": "0.85", "alpha": 0.85},
    )

    output_path = os.path.join(
        config.output_dir,
        f"Coherence_cross_sections_{tag}.png",
    )
    saved_png, saved_svg = save_oe_figure(fig, output_path, config.dpi, config)
    plt.close(fig)
    return str(saved_png), str(saved_svg)


def process_one_stats(stats_path, config):
    with np.load(stats_path, allow_pickle=True) as data:
        meta = load_meta(data)
        refs = load_refs(data)

        label = result_label(stats_path, meta)
        tag = compact_tag(label, max_chars=config.max_tag_chars)

        I_source = np.asarray(data["I_source"], dtype=np.float64)
        J_source_center = np.asarray(data["J_source_center"], dtype=np.complex128)
        I_pupil = np.asarray(data["I_pupil"], dtype=np.float64)
        J_pupil_center = np.asarray(data["J_pupil_center"], dtype=np.complex128)

        x_source = np.asarray(data["x_source"], dtype=np.float64)
        y_source = np.asarray(data["y_source"], dtype=np.float64)
        x_pupil = np.asarray(data["x_pupil"], dtype=np.float64)
        y_pupil = np.asarray(data["y_pupil"], dtype=np.float64)

        source_ref = reference_from_refs(refs, "source_center", x_source, y_source)
        pupil_ref = reference_from_refs(refs, "pupil_center", x_pupil, y_pupil)

        j_source = degree_of_coherence_from_J(I_source, J_source_center, source_ref)
        j_pupil = degree_of_coherence_from_J(I_pupil, J_pupil_center, pupil_ref)

        abs_j_source = np.abs(j_source).astype(np.float64)
        abs_j_pupil = np.abs(j_pupil).astype(np.float64)

        source_line = abs_j_source[source_ref["iy"], :]
        pupil_x_line = abs_j_pupil[pupil_ref["iy"], :]
        pupil_y_line = abs_j_pupil[:, pupil_ref["ix"]]

        source_fwhm = measure_center_peak_fwhm_direct(
            x_source,
            source_line,
            x0=source_ref["x"],
            center_search_px=config.center_peak_search_px,
        )
        pupil_x_fwhm = measure_center_peak_fwhm_direct(
            x_pupil,
            pupil_x_line,
            x0=pupil_ref["x"],
            center_search_px=config.center_peak_search_px,
        )
        pupil_y_fwhm = measure_center_peak_fwhm_direct(
            y_pupil,
            pupil_y_line,
            x0=pupil_ref["y"],
            center_search_px=config.center_peak_search_px,
        )

        figure_png, figure_svg = plot_three_coherence_cross_sections(
            x_source=x_source,
            source_line=source_line,
            source_fwhm=source_fwhm,
            x_pupil=x_pupil,
            pupil_x_line=pupil_x_line,
            pupil_x_fwhm=pupil_x_fwhm,
            y_pupil=y_pupil,
            pupil_y_line=pupil_y_line,
            pupil_y_fwhm=pupil_y_fwhm,
            tag=tag,
            config=config,
        )

        row = {
            "result_label": label,
            "stats_file": str(stats_path),
            "diffuser_file": meta.get("diffuser_file", ""),
            "source_gsm_file": meta.get("source_gsm_file", ""),
            "source_sigma_c_mm": parse_sigmac_from_meta_or_path(meta, stats_path),
            "ap_diffuser_radius_mm": meta.get(
                "ap_diffuser_radius_mm",
                meta.get("ap_diffuser_radius", np.nan),
            ),
            "ap_mask_radius_mm": meta.get(
                "ap_mask_radius_mm",
                meta.get("ap_mask_radius", np.nan),
            ),
            "defocus_z_back_mm": parse_float_meta(meta, "z_back_mm", "z_back"),
            "z_12_mm": parse_float_meta(meta, "z_12_mm", "z_12"),
            "z_2m_mm": parse_float_meta(meta, "z_2m_mm", "z_2m"),
            "source_fwhm_mm": source_fwhm["fwhm_mm"],
            "source_ok": source_fwhm["ok"],
            "source_reason": source_fwhm["reason"],
            "pupil_x_fwhm_mm": pupil_x_fwhm["fwhm_mm"],
            "pupil_x_ok": pupil_x_fwhm["ok"],
            "pupil_x_reason": pupil_x_fwhm["reason"],
            "pupil_y_fwhm_mm": pupil_y_fwhm["fwhm_mm"],
            "pupil_y_ok": pupil_y_fwhm["ok"],
            "pupil_y_reason": pupil_y_fwhm["reason"],
            "pupil_x_over_source": (
                pupil_x_fwhm["fwhm_mm"] / source_fwhm["fwhm_mm"]
                if source_fwhm["ok"] and pupil_x_fwhm["ok"] and source_fwhm["fwhm_mm"] != 0
                else np.nan
            ),
            "pupil_y_over_source": (
                pupil_y_fwhm["fwhm_mm"] / source_fwhm["fwhm_mm"]
                if source_fwhm["ok"] and pupil_y_fwhm["ok"] and source_fwhm["fwhm_mm"] != 0
                else np.nan
            ),
            "figure_png": figure_png,
            "figure_svg": figure_svg,
        }

    return row


def write_summary(rows, config):
    summary_path = os.path.join(config.output_dir, "coherence_fwhm_summary.csv")
    fieldnames = [
        "result_label",
        "stats_file",
        "diffuser_file",
        "source_gsm_file",
        "source_sigma_c_mm",
        "ap_diffuser_radius_mm",
        "ap_mask_radius_mm",
        "defocus_z_back_mm",
        "z_12_mm",
        "z_2m_mm",
        "source_fwhm_mm",
        "source_ok",
        "source_reason",
        "pupil_x_fwhm_mm",
        "pupil_x_ok",
        "pupil_x_reason",
        "pupil_y_fwhm_mm",
        "pupil_y_ok",
        "pupil_y_reason",
        "pupil_x_over_source",
        "pupil_y_over_source",
        "figure_png",
        "figure_svg",
    ]

    Path(config.output_dir).mkdir(parents=True, exist_ok=True)
    with open(summary_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    return summary_path


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Postprocess propagation statistics and keep only source, pupil-X, "
            "and pupil-Y complex-degree-of-coherence cross-sections."
        )
    )
    parser.add_argument("--stats-dir", type=str, default=None)
    parser.add_argument("--stats-pattern", type=str, default=None)
    parser.add_argument("--output-dir", type=str, default=None)
    return parser.parse_args()


def main():
    config = PostprocessConfig()
    args = parse_args()
    updates = {}
    if args.stats_dir is not None:
        updates["stats_dir"] = args.stats_dir
    if args.stats_pattern is not None:
        updates["stats_pattern"] = args.stats_pattern
    if args.output_dir is not None:
        updates["output_dir"] = args.output_dir
    if updates:
        config = replace(config, **updates)

    os.makedirs(config.output_dir, exist_ok=True)

    stats_paths = sorted(Path(config.stats_dir).glob(config.stats_pattern))
    if len(stats_paths) == 0:
        print(f"No stats files found: {os.path.join(config.stats_dir, config.stats_pattern)}")
        return

    rows = []
    for stats_path in stats_paths:
        if config.verbose:
            print(f"processing: {stats_path}")
        row = process_one_stats(stats_path, config)
        rows.append(row)
        if config.verbose:
            print(f"  saved figure: {row['figure_png']}")

    summary_path = write_summary(rows, config)

    print("========== postprocess complete ==========")
    print(f"figure directory = {os.path.abspath(config.output_dir)}")
    print(f"FWHM summary     = {summary_path}")
    print(f"processed files  = {len(rows)}")
    print("kept plots       = source |j|, pupil X |j|, pupil Y |j|")
    print("mask-plane plots = disabled")


if __name__ == "__main__":
    main()
