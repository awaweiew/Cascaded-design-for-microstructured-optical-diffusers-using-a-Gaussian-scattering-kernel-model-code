function config = create_dual_axis_config()
%CREATE_DUAL_AXIS_CONFIG Build the dual-axis optimization configuration.
% Configure kb, kaScale, and rotationUpperDegree.

config = create_diffuser_config();

% Configure the base model parameters.
config.geometry.Lx = 0.5;
config.geometry.Ly = 0.5;
config.geometry.Nx = 100;
config.geometry.Ny = 100;
config.height.minimum = 0.018;
config.height.maximum = 0.030;
config.height.alpha = 1.22;
config.height.beta = 4.48;
config.aspectKa.minimum = 0.5;
config.aspectKa.maximum = 0.8;
config.aspectKa.alpha = 0.40;
config.aspectKa.beta = 0.40;
config.geometry.kb = 0.80;
config.geometry.positionJitterFraction = 0.40;
config.geometry.rotationRange = pi;
config.numerical.softMinK = 2500;
config.numerical.searchResolutionX = 600;
config.numerical.searchResolutionY = 600;
config.numerical.resolutionX = 600;
config.numerical.resolutionY = 600;
config.angular.minimumDegree = -60;
config.angular.maximumDegree = 60;
config.angular.sampleCount = 301;

% Retain the scalar target for compatibility.
config.target.metric = 'centerCutX';
config.target.fwhmDegree = 30;
config.target.angleToleranceDegree = 0.10;

config.dualTarget.xFwhmDegree = 30;
config.dualTarget.yFwhmDegree = 20;
config.dualTarget.xToleranceDegree = 0.10;
config.dualTarget.yToleranceDegree = 0.10;
% Assign targets by directional magnitude.
config.dualTarget.objectiveDefinition = ...
    'directionalExtremaMaximumNormalizedError';

config.dualOptimization.baseAspectKaMinimum = 0.5;
config.dualOptimization.baseAspectKaMaximum = 0.8;
config.dualOptimization.currentKaScale = 1.0;
config.dualOptimization.stage1RotationUpperDegree = 0;
config.dualOptimization.stage2RotationUpperDegree = 0;

config.dualOptimization.parameters = struct( ...
    'name', {'kb','kaScale','rotationUpperDegree'}, ...
    'displayName', {'Minor-to-major axis ratio','Aspect-ratio scale', ...
    'Major-axis rotation upper bound'}, ...
    'enabled', {true,true,true}, ...
    'lowerBound', {0.40,0.50,0.0}, ...
    'upperBound', {1.00,1.50,180.0}, ...
    'initialValue', {0.80,1.00,0.0}, ...
    'coarseStep', {0.02,0.02,10.0}, ...
    'fineStep', {0.005,0.002,1.0}, ...
    'isInteger', {false,false,false});

config.dualOptimization.noImprovementPatience = 3;
config.dualOptimization.maximumEvaluationsPerParameter = 80;
% Enable joint kb and kaScale refinement.
config.dualOptimization.maximumJointRefinementRounds = 5;
config.dualOptimization.minimumJointObjectiveImprovement = 1e-4;
config.dualOptimization.useTargetOnlyAngularDuringSearch = true;
config.dualOptimization.failFast = false;

% Disable legacy parameter settings.
for index = 1:numel(config.optimization.parameters)
    config.optimization.parameters(index).enabled = false;
end
config.optimization.baseAspectKaMinimum = ...
    config.dualOptimization.baseAspectKaMinimum;
config.optimization.baseAspectKaMaximum = ...
    config.dualOptimization.baseAspectKaMaximum;
config.optimization.currentKaScale = config.dualOptimization.currentKaScale;

validate_dual_axis_config(config);
end
