%% Smoke test for three-stage directional optimization.
clear;
clc;

programDirectory = fileparts(mfilename('fullpath'));
modelDirectory = fullfile(fileparts(programDirectory), ...
    'circular angular distribution');
addpath(programDirectory);
addpath(modelDirectory);

config = create_dual_axis_config();
config.geometry.Nx = 5;
config.geometry.Ny = 5;
config.numerical.resolutionX = 150;
config.numerical.resolutionY = 150;
config.numerical.searchResolutionX = 150;
config.numerical.searchResolutionY = 150;
config.angular.sampleCount = 81;
config.measurement.radialBinCount = 80;
config.geometry.rotationRange = deg2rad(90);
config.dualOptimization.maximumEvaluationsPerParameter = 3;
config.dualOptimization.noImprovementPatience = 1;
validate_dual_axis_config(config);

bank = build_common_random_bank(config);
options.resolutionX = 150;
options.resolutionY = 150;
options.retainLargeData = false;
options.failFast = true;
options.angularMode = 'targetOnly';
options.objectiveMode = 'directionalExtrema';
baseline = evaluate_dual_axis_candidate(config,bank,options);
assert(strcmp(baseline.status,'valid'),'Directional-extrema baseline evaluation is invalid.');
assert(baseline.fwhmMaximumDirectionDegree >= ...
    baseline.fwhmMinimumDirectionDegree, ...
    'Maximum-direction FWHM is smaller than minimum-direction FWHM.');
azimuthSeparation = mod(abs(baseline.maximumDirectionAzimuthDegree- ...
    baseline.minimumDirectionAzimuthDegree),180);
azimuthSeparation = min(azimuthSeparation,180-azimuthSeparation);
assert(abs(azimuthSeparation-90) < 1e-8,'Maximum and minimum principal directions are not orthogonal.');

% Verify target ordering by magnitude.
config.dualTarget.xFwhmDegree = baseline.fwhmMinimumDirectionDegree;
config.dualTarget.yFwhmDegree = baseline.fwhmMaximumDirectionDegree;
config.dualTarget.xToleranceDegree = 1e-6;
config.dualTarget.yToleranceDegree = 1e-6;
config.target.fwhmDegree = config.dualTarget.xFwhmDegree;
config.target.angleToleranceDegree = 1e-6;
extremaEvaluation = evaluate_dual_axis_candidate(config,bank,options);
assert(extremaEvaluation.withinBothTolerances, ...
    'Reordered targets did not satisfy both directional criteria.');
assert(abs(extremaEvaluation.targetMaximumDegree- ...
    baseline.fwhmMaximumDirectionDegree) < 1e-12, ...
    'The larger input was not assigned as the maximum-direction target.');

% Verify parameter updates.
parameters = config.dualOptimization.parameters;
kbParameter = parameters(strcmp({parameters.name},'kb'));
kaParameter = parameters(strcmp({parameters.name},'kaScale'));
rotationParameter = parameters(strcmp( ...
    {parameters.name},'rotationUpperDegree'));
kaConfig = apply_dual_axis_parameter(config,kaParameter,0.9);
assert(abs(kaConfig.aspectKa.minimum-0.9* ...
    config.dualOptimization.baseAspectKaMinimum) < 1e-12, ...
    'kaScale was not applied correctly.');
kbConfig = apply_dual_axis_parameter(config,kbParameter,0.7);
assert(abs(kbConfig.geometry.kb-0.7) < 1e-12,'kb was not applied correctly.');
rotationConfig = apply_dual_axis_parameter(config,rotationParameter,45);
assert(abs(rad2deg(rotationConfig.geometry.rotationRange)-45) < 1e-12, ...
    'Rotation upper bound was not applied correctly.');

% Verify the three-stage search order.
stageConfig = config;
stageConfig = apply_dual_axis_parameter(stageConfig,kbParameter, ...
    kbParameter.initialValue);
stageConfig = apply_dual_axis_parameter(stageConfig,kaParameter, ...
    kaParameter.initialValue);
stageConfig = apply_dual_axis_parameter(stageConfig,rotationParameter,0);
stageOptions = options;
stageOptions.objectiveMode = 'directionalExtrema';
stageProbe = evaluate_dual_axis_candidate(stageConfig,bank,stageOptions);
assert(strcmp(stageProbe.status,'valid'),'Three-stage baseline evaluation is invalid.');
stageConfig.dualTarget.xFwhmDegree = ...
    stageProbe.fwhmMaximumDirectionDegree;
stageConfig.dualTarget.yFwhmDegree = ...
    stageProbe.fwhmMinimumDirectionDegree;
stageConfig.dualTarget.xToleranceDegree = 1e-6;
stageConfig.dualTarget.yToleranceDegree = 1e-6;
stageConfig.target.fwhmDegree = stageProbe.fwhmMaximumDirectionDegree;
stageConfig.target.angleToleranceDegree = 1e-6;
stageSearch = run_dual_axis_coordinate_search(stageConfig,bank,'');
assert(stageSearch.completedStages == 3, ...
    'The three stages did not execute in sequence for the baseline target.');
assert(strcmp(stageSearch.parameterResults.parameterName(1),'kb'), ...
    'Stage 1 did not optimize kb.');
assert(strcmp(stageSearch.parameterResults.parameterName(2),'kaScale'), ...
    'Stage 2 did not optimize kaScale.');
assert(strcmp(stageSearch.parameterResults.parameterName(3), ...
    'rotationUpperDegree'),'Stage 3 did not optimize the rotation upper bound.');
assert(stageSearch.parameterResults.stage(1) == 1 && ...
       stageSearch.parameterResults.stage(2) == 2 && ...
       stageSearch.parameterResults.stage(3) == 3, ...
    'Stage numbering or optimization order is incorrect.');
assert(all(stageSearch.parameterResults.executed), ...
    'At least one stage was not executed.');
assert(abs(rad2deg(stageSearch.bestConfig.geometry.rotationRange)) < 1e-12, ...
    'Stage 3 changed the rotation upper bound despite satisfying the target at zero rotation.');
assert(strcmp(stageSearch.stopReason, ...
    'directional_extrema_reached_at_zero_rotation'), ...
    'Incorrect stop reason when the target is met at zero rotation.');

% Verify joint refinement and global coarse scanning.
jointConfig = stageConfig;
jointParameters = jointConfig.dualOptimization.parameters;
jointKbIndex = find(strcmp({jointParameters.name},'kb'),1);
jointKaIndex = find(strcmp({jointParameters.name},'kaScale'),1);
jointRotationIndex = find(strcmp( ...
    {jointParameters.name},'rotationUpperDegree'),1);
jointConfig.dualOptimization.parameters(jointKbIndex).lowerBound = 0.78;
jointConfig.dualOptimization.parameters(jointKbIndex).upperBound = 0.82;
jointConfig.dualOptimization.parameters(jointKbIndex).coarseStep = 0.02;
jointConfig.dualOptimization.parameters(jointKbIndex).fineStep = 0.01;
jointConfig.dualOptimization.parameters(jointKaIndex).lowerBound = 0.98;
jointConfig.dualOptimization.parameters(jointKaIndex).upperBound = 1.02;
jointConfig.dualOptimization.parameters(jointKaIndex).coarseStep = 0.02;
jointConfig.dualOptimization.parameters(jointKaIndex).fineStep = 0.01;
jointConfig.dualOptimization.parameters( ...
    jointRotationIndex).coarseStep = 90;
jointConfig.dualOptimization.parameters( ...
    jointRotationIndex).fineStep = 45;
jointConfig.dualOptimization.maximumEvaluationsPerParameter = 12;
jointConfig.dualOptimization.maximumJointRefinementRounds = 2;
jointConfig.dualOptimization.minimumJointObjectiveImprovement = 0;
jointConfig.dualOptimization.noImprovementPatience = 1;
jointConfig.dualTarget.xFwhmDegree = max( ...
    stageProbe.fwhmMaximumDirectionDegree, ...
    stageProbe.fwhmMinimumDirectionDegree);
jointConfig.dualTarget.yFwhmDegree = 1;
jointConfig.dualTarget.xToleranceDegree = 1e-6;
jointConfig.dualTarget.yToleranceDegree = 1e-6;
jointConfig.target.fwhmDegree = jointConfig.dualTarget.xFwhmDegree;
jointConfig.target.angleToleranceDegree = 1e-6;
validate_dual_axis_config(jointConfig);
jointSearch = run_dual_axis_coordinate_search(jointConfig,bank,'');
assert(jointSearch.jointRefinementRounds >= 1, ...
    'Joint kb/kaScale refinement was not entered when dual targets were unmet.');
assert(any(jointSearch.parameterResults.jointRound > 0 & ...
    strcmp(jointSearch.parameterResults.parameterName,'kb')), ...
    'Joint refinement did not re-optimize kb.');
assert(any(strcmp(jointSearch.history.phase,'global_coarse_scan')), ...
    'Single-parameter optimization did not perform a full-boundary coarse scan.');
assert(strcmp(jointSearch.parameterResults.parameterName(end), ...
    'rotationUpperDegree'),'Rotation optimization was not executed after joint refinement.');

fprintf('Three-stage directional optimization smoke test passed.\n');
fprintf(['Baseline maximum direction=%.6f deg @ %.3f deg, ', ...
    'minimum direction=%.6f deg @ %.3f deg.\n'], ...
    baseline.fwhmMaximumDirectionDegree, ...
    baseline.maximumDirectionAzimuthDegree, ...
    baseline.fwhmMinimumDirectionDegree, ...
    baseline.minimumDirectionAzimuthDegree);
