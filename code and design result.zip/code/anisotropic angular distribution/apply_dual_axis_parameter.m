function updatedConfig = apply_dual_axis_parameter(config,parameter,value)
%APPLY_DUAL_AXIS_PARAMETER Apply one optimization parameter.

assert(isfinite(value) && isscalar(value), 'Candidate value must be a finite scalar.');
assert(value >= parameter.lowerBound-10*eps && ...
       value <= parameter.upperBound+10*eps, ...
    'Candidate value for %s is outside the search range.',parameter.name);
if parameter.isInteger
    value = round(value);
end

updatedConfig = config;
switch parameter.name
    case 'kaScale'
        updatedConfig.aspectKa.minimum = ...
            config.dualOptimization.baseAspectKaMinimum*value;
        updatedConfig.aspectKa.maximum = ...
            config.dualOptimization.baseAspectKaMaximum*value;
        updatedConfig.dualOptimization.currentKaScale = value;
        % Synchronize the compatibility field.
        updatedConfig.optimization.baseAspectKaMinimum = ...
            config.dualOptimization.baseAspectKaMinimum;
        updatedConfig.optimization.baseAspectKaMaximum = ...
            config.dualOptimization.baseAspectKaMaximum;
        updatedConfig.optimization.currentKaScale = value;

    case 'kb'
        updatedConfig.geometry.kb = value;

    case 'rotationUpperDegree'
        % Store the rotation upper bound.
        updatedConfig.geometry.rotationRange = deg2rad(value);

    otherwise
        error('Unknown dual-axis optimization parameter: %s.',parameter.name);
end
validate_dual_axis_config(updatedConfig);
end
