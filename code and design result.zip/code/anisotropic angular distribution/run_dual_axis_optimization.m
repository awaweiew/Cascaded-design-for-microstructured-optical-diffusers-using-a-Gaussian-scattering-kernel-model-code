function result = run_dual_axis_optimization(userControl)
%RUN_DUAL_AXIS_OPTIMIZATION Run the dual-axis optimization workflow.
% Select smokeTest, forwardOnly, or optimize with userControl.action.

if nargin < 1 || isempty(userControl)
    userControl = struct();
end

programDirectory = fileparts(mfilename('fullpath'));
defaults.modelDirectory = fullfile(fileparts(programDirectory), ...
    'circular angular distribution');
defaults.action = 'optimize';

% Assign targets by directional magnitude.
defaults.targetXDegree = 30;
defaults.targetYDegree = 20;
defaults.toleranceXDegree = 0.10;
defaults.toleranceYDegree = 0.10;

defaults.arrayNx = 60;
defaults.arrayNy = 60;
defaults.searchResolutionX = 600;
defaults.searchResolutionY = 600;
defaults.finalResolutionX = 600;
defaults.finalResolutionY = 600;

defaults.kaScaleInitial = 1.00;
defaults.kaScaleLower = 0.5;
defaults.kaScaleUpper = 1.50;
defaults.kaScaleCoarseStep = 0.02;
defaults.kaScaleFineStep = 0.0002;

defaults.kbInitial = 0.80;
defaults.kbLower = 0.40;
defaults.kbUpper = 1.00;
defaults.kbCoarseStep = 0.02;
defaults.kbFineStep = 0.0005;

% Scale common random quantiles by the rotation upper bound.
defaults.rotationUpperInitialDegree = 0;
defaults.rotationUpperLowerDegree = 0;
defaults.rotationUpperUpperDegree = 180;
defaults.rotationUpperCoarseStepDegree = 10;
defaults.rotationUpperFineStepDegree = 1;

defaults.maximumEvaluationsPerParameter = 80;
defaults.noImprovementPatience = 3;
defaults.maximumJointRefinementRounds = 5;
defaults.minimumJointObjectiveImprovement = 1e-4;
defaults.randomSeed = 1;
defaults.createFigures = true;
defaults.outputRootDirectory = fullfile(programDirectory,'results');

% Refine the Gaussian optimum with local Snell tracing.
defaults.enableSnellRefinement = true;
defaults.snellSearchRayCount = 2e6;
defaults.snellFinalRayCount = 2e7;
defaults.snellRayChunkSize = 2.5e5;
defaults.snellRaySamplingMode = 'r2';
defaults.snellRayRandomSeed = 104729;
defaults.snellKbHalfRange = 0.08;
defaults.snellKaScaleHalfRange = 0.12;
defaults.snellRotationHalfRangeDegree = 5;
defaults.snellKbCoarseStep = 0.01;
defaults.snellKaScaleCoarseStep = 0.01;
defaults.snellRotationCoarseStepDegree = 2;
defaults.snellKbFineStep = 0.0001;
defaults.snellKaScaleFineStep = 0.0001;
defaults.snellRotationFineStepDegree = 0.0025;
defaults.snellMaximumEvaluations = 80;
defaults.snellMaximumIterations = 16;
defaults.snellMinimumObjectiveImprovement = 1e-4;
% Refine kb and kaScale jointly before reducing the step size.
defaults.snellEnableJointKbKa = true;
defaults.snellNoImprovementPatience = 2;
defaults.snellStepReductionFactor = 0.1;
defaults.snellPerpendicularBandwidthDegree = 0.60;
defaults.snellProfileSmoothingSigmaBins = 0.75;
defaults.snellAngularSmoothingSigmaBins = 1.0;
defaults.snellSaveAngularCsv = true;

control = merge_control_local(defaults,userControl);
validate_control_local(control);
assert(isfolder(control.modelDirectory), ...
    'Model directory not found: %s',control.modelDirectory);
addpath(control.modelDirectory);
addpath(programDirectory);

requiredFunctions = {'create_diffuser_config','validate_diffuser_config', ...
    'build_common_random_bank','generate_diffuser_surface', ...
    'extract_gaussian_kernel_stats','assemble_gaussian_distribution', ...
    'measure_scattering_fwhm','evaluate_diffuser_candidate'};
for index = 1:numel(requiredFunctions)
    assert(exist(requiredFunctions{index},'file') == 2, ...
        'Model directory is missing required function %s.m.',requiredFunctions{index});
end

config = create_dual_axis_config();
config.geometry.Nx = control.arrayNx;
config.geometry.Ny = control.arrayNy;
config.numerical.searchResolutionX = control.searchResolutionX;
config.numerical.searchResolutionY = control.searchResolutionY;
config.numerical.resolutionX = control.finalResolutionX;
config.numerical.resolutionY = control.finalResolutionY;
config.random.seed = control.randomSeed;
config.dualTarget.xFwhmDegree = control.targetXDegree;
config.dualTarget.yFwhmDegree = control.targetYDegree;
config.dualTarget.xToleranceDegree = control.toleranceXDegree;
config.dualTarget.yToleranceDegree = control.toleranceYDegree;
config.target.fwhmDegree = control.targetXDegree;
config.target.angleToleranceDegree = control.toleranceXDegree;

config = configure_parameter_local(config,'kaScale', ...
    control.kaScaleInitial,control.kaScaleLower,control.kaScaleUpper, ...
    control.kaScaleCoarseStep,control.kaScaleFineStep);
config = configure_parameter_local(config,'kb', ...
    control.kbInitial,control.kbLower,control.kbUpper, ...
    control.kbCoarseStep,control.kbFineStep);
config = configure_parameter_local(config,'rotationUpperDegree', ...
    control.rotationUpperInitialDegree, ...
    control.rotationUpperLowerDegree,control.rotationUpperUpperDegree, ...
    control.rotationUpperCoarseStepDegree, ...
    control.rotationUpperFineStepDegree);

config.dualOptimization.maximumEvaluationsPerParameter = ...
    control.maximumEvaluationsPerParameter;
config.dualOptimization.noImprovementPatience = ...
    control.noImprovementPatience;
config.dualOptimization.maximumJointRefinementRounds = ...
    control.maximumJointRefinementRounds;
config.dualOptimization.minimumJointObjectiveImprovement = ...
    control.minimumJointObjectiveImprovement;

% Apply initial values for non-optimization modes.
parameters = config.dualOptimization.parameters;
for index = 1:numel(parameters)
    config = apply_dual_axis_parameter( ...
        config,parameters(index),parameters(index).initialValue);
end

if strcmp(control.action,'smokeTest')
    config.geometry.Nx = 12;
    config.geometry.Ny = 12;
    config.numerical.searchResolutionX = 280;
    config.numerical.searchResolutionY = 280;
    config.numerical.resolutionX = 280;
    config.numerical.resolutionY = 280;
    config.angular.sampleCount = 101;
    config.measurement.radialBinCount = 100;
end
validate_dual_axis_config(config);

timeStamp = char(datetime('now','Format','yyyyMMdd_HHmmss'));
outputDirectory = fullfile(control.outputRootDirectory,timeStamp);
if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end
fprintf('\nOutput directory: %s\n',outputDirectory);
fprintf('Unordered target pair: {%.6f +/- %.6f, %.6f +/- %.6f} deg.\n', ...
    config.dualTarget.xFwhmDegree,config.dualTarget.xToleranceDegree, ...
    config.dualTarget.yFwhmDegree,config.dualTarget.yToleranceDegree);

randomBank = build_common_random_bank(config);
searchResult = [];
switch control.action
    case {'smokeTest','forwardOnly'}
        options.resolutionX = config.numerical.resolutionX;
        options.resolutionY = config.numerical.resolutionY;
        options.retainLargeData = true;
        options.failFast = true;
        options.angularMode = 'full';
        options.objectiveMode = 'directionalExtrema';
        finalEvaluation = evaluate_dual_axis_candidate( ...
            config,randomBank,options);

    case 'optimize'
        searchResult = run_dual_axis_coordinate_search( ...
            config,randomBank,outputDirectory);
        bestConfig = searchResult.bestConfig;
        options.resolutionX = bestConfig.numerical.resolutionX;
        options.resolutionY = bestConfig.numerical.resolutionY;
        options.retainLargeData = true;
        options.failFast = true;
        options.angularMode = 'full';
        options.objectiveMode = 'directionalExtrema';
        finalEvaluation = evaluate_dual_axis_candidate( ...
            bestConfig,randomBank,options);

    otherwise
        error('Unknown action: %s.',control.action);
end

save_dual_axis_results(outputDirectory,searchResult,finalEvaluation);
if control.createFigures
    plot_dual_axis_results(finalEvaluation,searchResult,outputDirectory);
end

fprintf('\nGaussian-kernel stage complete.\n');
fprintf(['Maximum-direction FWHM: %.6f deg (azimuth %.3f deg, target %.6f deg, ', ...
    'error %+.6f deg)\n'], ...
    finalEvaluation.fwhmMaximumDirectionDegree, ...
    finalEvaluation.maximumDirectionAzimuthDegree, ...
    finalEvaluation.targetMaximumDegree, ...
    finalEvaluation.signedErrorMaximumDegree);
fprintf(['Minimum-direction FWHM: %.6f deg (azimuth %.3f deg, target %.6f deg, ', ...
    'error %+.6f deg)\n'], ...
    finalEvaluation.fwhmMinimumDirectionDegree, ...
    finalEvaluation.minimumDirectionAzimuthDegree, ...
    finalEvaluation.targetMinimumDegree, ...
    finalEvaluation.signedErrorMinimumDegree);
fprintf('Both directional tolerances satisfied: %d\n', ...
    finalEvaluation.withinBothTolerances);
fprintf('Best kaScale=%.9g, kb=%.9g, rotation upper bound=%.9g deg.\n', ...
    finalEvaluation.config.dualOptimization.currentKaScale, ...
    finalEvaluation.config.geometry.kb, ...
    rad2deg(finalEvaluation.config.geometry.rotationRange));

snellResult = [];
if strcmp(control.action,'optimize') && control.enableSnellRefinement
    fprintf('Continuing with local Snell ray-tracing refinement.\n');
    snellResult = run_dual_axis_snell_refinement( ...
        finalEvaluation.config,randomBank,control,outputDirectory);
end

result.control = control;
result.gaussianFinalEvaluation = finalEvaluation;
result.searchResult = searchResult;
result.snellRefinement = snellResult;
result.outputDirectory = outputDirectory;
if isempty(snellResult)
    result.bestConfig = finalEvaluation.config;
    result.finalEvaluation = finalEvaluation;
else
    result.bestConfig = snellResult.bestConfig;
    result.finalEvaluation = snellResult.bestEvaluation;
end
end

function config = configure_parameter_local( ...
        config,name,initialValue,lowerBound,upperBound,coarseStep,fineStep)
index = find(strcmp({config.dualOptimization.parameters.name},name),1);
assert(~isempty(index),'Parameter does not exist: %s.',name);
config.dualOptimization.parameters(index).initialValue = initialValue;
config.dualOptimization.parameters(index).lowerBound = lowerBound;
config.dualOptimization.parameters(index).upperBound = upperBound;
config.dualOptimization.parameters(index).coarseStep = coarseStep;
config.dualOptimization.parameters(index).fineStep = fineStep;
end

function control = merge_control_local(defaults,userControl)
control = defaults;
validFields = fieldnames(defaults);
fields = fieldnames(userControl);
for index = 1:numel(fields)
    name = fields{index};
    assert(any(strcmp(validFields,name)),'Unknown control field: %s.',name);
    control.(name) = userControl.(name);
end
end

function validate_control_local(control)
assert(any(strcmp(control.action,{'smokeTest','forwardOnly','optimize'})), ...
    'action must be smokeTest, forwardOnly, or optimize.');
positiveFields = {'targetXDegree','targetYDegree','toleranceXDegree', ...
    'toleranceYDegree','arrayNx','arrayNy','searchResolutionX', ...
    'searchResolutionY','finalResolutionX','finalResolutionY', ...
    'kaScaleInitial','kaScaleCoarseStep','kaScaleFineStep', ...
    'kbInitial','kbCoarseStep','kbFineStep', ...
    'rotationUpperCoarseStepDegree','rotationUpperFineStepDegree', ...
    'maximumEvaluationsPerParameter','noImprovementPatience', ...
    'maximumJointRefinementRounds','snellNoImprovementPatience'};
for index = 1:numel(positiveFields)
    value = control.(positiveFields{index});
    assert(isnumeric(value) && isscalar(value) && isfinite(value) && value > 0, ...
        'Control field %s must be a positive finite scalar.',positiveFields{index});
end
assert(control.kaScaleLower < control.kaScaleUpper && ...
    control.kaScaleInitial >= control.kaScaleLower && ...
    control.kaScaleInitial <= control.kaScaleUpper, ...
    'Invalid kaScale search range or initial value.');
assert(control.kbLower > 0 && control.kbUpper <= 1 && ...
    control.kbLower < control.kbUpper && ...
    control.kbInitial >= control.kbLower && control.kbInitial <= control.kbUpper, ...
    'Invalid kb search range or initial value.');
assert(control.rotationUpperLowerDegree == 0 && ...
    control.rotationUpperUpperDegree == 180 && ...
    control.rotationUpperInitialDegree >= control.rotationUpperLowerDegree && ...
    control.rotationUpperInitialDegree <= control.rotationUpperUpperDegree, ...
    'Invalid rotation upper-bound search range or initial value.');
assert(islogical(control.createFigures) && isscalar(control.createFigures), ...
    'createFigures must be a logical scalar.');
assert(islogical(control.enableSnellRefinement) && ...
    isscalar(control.enableSnellRefinement), ...
    'enableSnellRefinement must be a logical scalar.');
assert(islogical(control.snellSaveAngularCsv) && ...
    isscalar(control.snellSaveAngularCsv), ...
    'snellSaveAngularCsv must be a logical scalar.');
assert(islogical(control.snellEnableJointKbKa) && ...
    isscalar(control.snellEnableJointKbKa), ...
    'snellEnableJointKbKa must be a logical scalar.');
assert(isnumeric(control.snellStepReductionFactor) && ...
    isscalar(control.snellStepReductionFactor) && ...
    isfinite(control.snellStepReductionFactor) && ...
    control.snellStepReductionFactor > 0 && ...
    control.snellStepReductionFactor < 1, ...
    'snellStepReductionFactor must be between 0 and 1.');
assert(isnumeric(control.minimumJointObjectiveImprovement) && ...
    isscalar(control.minimumJointObjectiveImprovement) && ...
    isfinite(control.minimumJointObjectiveImprovement) && ...
    control.minimumJointObjectiveImprovement >= 0, ...
    'minimumJointObjectiveImprovement must be a nonnegative finite scalar.');
end
