function searchResult = run_dual_axis_coordinate_search( ...
        initialConfig,randomBank,outputDirectory)
%RUN_DUAL_AXIS_COORDINATE_SEARCH Run the three-stage parameter search.
% Optimize kb, kaScale, and rotationUpperDegree in sequence.

if nargin < 3
    outputDirectory = '';
end
validate_dual_axis_config(initialConfig);

parameters = initialConfig.dualOptimization.parameters;
kbParameter = get_parameter_local(parameters,'kb');
kaParameter = get_parameter_local(parameters,'kaScale');
rotationParameter = get_parameter_local(parameters,'rotationUpperDegree');
assert(kbParameter.enabled && kaParameter.enabled && rotationParameter.enabled, ...
    'The staged algorithm requires kb, kaScale, and rotationUpperDegree to be enabled.');

baseOptions.resolutionX = initialConfig.numerical.searchResolutionX;
baseOptions.resolutionY = initialConfig.numerical.searchResolutionY;
baseOptions.retainLargeData = false;
baseOptions.failFast = initialConfig.dualOptimization.failFast;
if initialConfig.dualOptimization.useTargetOnlyAngularDuringSearch
    baseOptions.angularMode = 'targetOnly';
else
    baseOptions.angularMode = 'full';
end

cache = containers.Map('KeyType','char','ValueType','any');
history = repmat(empty_history_local(),0,1);
parameterResults = repmat(empty_parameter_result_local(),0,1);
currentConfig = initialConfig;
currentConfig = apply_dual_axis_parameter( ...
    currentConfig,kbParameter,kbParameter.initialValue);
currentConfig = apply_dual_axis_parameter( ...
    currentConfig,kaParameter,kaParameter.initialValue);

fprintf('\n[Starting three-stage directional FWHM optimization]\n');
fprintf('Maximum target: %.6f deg; minimum target: %.6f deg.\n', ...
    max(initialConfig.dualTarget.xFwhmDegree, ...
        initialConfig.dualTarget.yFwhmDegree), ...
    min(initialConfig.dualTarget.xFwhmDegree, ...
        initialConfig.dualTarget.yFwhmDegree));

%% Stage 1: Optimize kb with zero rotation.
currentConfig = apply_dual_axis_parameter(currentConfig,rotationParameter, ...
    currentConfig.dualOptimization.stage1RotationUpperDegree);
stage1Options = baseOptions;
stage1Options.objectiveMode = 'maximumDirection';
stage1Initial = evaluate_dual_axis_candidate( ...
    currentConfig,randomBank,stage1Options);
history(end+1,1) = evaluation_history_local(stage1Initial,1, ...
    'kb',get_dual_axis_parameter(currentConfig,kbParameter), ...
    'stage_initial',0);
fprintf('\n--- Stage 1: Optimize kb with zero rotation ---\n');
print_evaluation_local('Stage 1 initial',stage1Initial);

[currentConfig,stage1Result] = optimize_one_dual_axis_parameter( ...
    currentConfig,randomBank,kbParameter,stage1Options,cache);
history = append_parameter_history_local( ...
    history,stage1Result,1,'maximumDirection',0);
parameterResults(end+1,1) = parameter_summary_local( ...
    stage1Result,1,'maximumDirection',true,0);
stage1Final = evaluate_dual_axis_candidate( ...
    currentConfig,randomBank,stage1Options);
history(end+1,1) = evaluation_history_local(stage1Final,1, ...
    'kb',get_dual_axis_parameter(currentConfig,kbParameter), ...
    'stage_final',0);
print_evaluation_local('Stage 1 final',stage1Final);
save_checkpoint_local(outputDirectory,currentConfig,history,parameterResults,1);

if ~stage1Final.maximumDirectionSatisfied
    fprintf(['Stage 1 did not meet the final tolerance; retain kb and ', ...
        'continue with kaScale and joint refinement.\n']);
end

%% Stage 2: Optimize kaScale with zero rotation.
currentConfig = apply_dual_axis_parameter(currentConfig,rotationParameter, ...
    currentConfig.dualOptimization.stage2RotationUpperDegree);
stage2Options = baseOptions;
stage2Options.objectiveMode = 'directionalExtrema';
stage2Initial = evaluate_dual_axis_candidate( ...
    currentConfig,randomBank,stage2Options);
history(end+1,1) = evaluation_history_local(stage2Initial,2, ...
    'kaScale',get_dual_axis_parameter(currentConfig,kaParameter), ...
    'stage_initial',0);
fprintf('\n--- Stage 2: Optimize kaScale with zero rotation ---\n');
print_evaluation_local('Stage 2 initial',stage2Initial);

[currentConfig,stage2Result] = optimize_one_dual_axis_parameter( ...
    currentConfig,randomBank,kaParameter,stage2Options,cache);
history = append_parameter_history_local( ...
    history,stage2Result,2,'directionalExtrema',0);
parameterResults(end+1,1) = parameter_summary_local( ...
    stage2Result,2,'directionalExtrema',true,0);
stage2Final = evaluate_dual_axis_candidate( ...
    currentConfig,randomBank,stage2Options);
history(end+1,1) = evaluation_history_local(stage2Final,2, ...
    'kaScale',get_dual_axis_parameter(currentConfig,kaParameter), ...
    'stage_final',0);
print_evaluation_local('Stage 2 final',stage2Final);
save_checkpoint_local(outputDirectory,currentConfig,history,parameterResults,2);

%% Stage 2 refinement: Jointly optimize kb and kaScale.
jointNoImprovementCount = 0;
maximumJointRounds = currentConfig.dualOptimization. ...
    maximumJointRefinementRounds;
minimumJointImprovement = currentConfig.dualOptimization. ...
    minimumJointObjectiveImprovement;
for jointRound = 1:maximumJointRounds
    if stage2Final.withinBothTolerances
        break;
    end
    roundInitialScore = stage2Final.objectiveScore;
    fprintf(['\n--- Stage 2 joint refinement, round %d/%d: ', ...
        'rescan kb and kaScale ---\n'],jointRound,maximumJointRounds);

    [currentConfig,jointKbResult] = optimize_one_dual_axis_parameter( ...
        currentConfig,randomBank,kbParameter,stage2Options,cache);
    history = append_parameter_history_local(history,jointKbResult,2, ...
        'directionalExtrema_joint_refinement',jointRound);
    parameterResults(end+1,1) = parameter_summary_local( ...
        jointKbResult,2,'directionalExtrema_joint_refinement',true,jointRound); %#ok<AGROW>
    jointEvaluation = evaluate_dual_axis_candidate( ...
        currentConfig,randomBank,stage2Options);
    print_evaluation_local(sprintf('Joint round %d after kb',jointRound), ...
        jointEvaluation);

    if ~jointEvaluation.withinBothTolerances
        [currentConfig,jointKaResult] = optimize_one_dual_axis_parameter( ...
            currentConfig,randomBank,kaParameter,stage2Options,cache);
        history = append_parameter_history_local(history,jointKaResult,2, ...
            'directionalExtrema_joint_refinement',jointRound);
        parameterResults(end+1,1) = parameter_summary_local( ...
            jointKaResult,2,'directionalExtrema_joint_refinement',true,jointRound); %#ok<AGROW>
        jointEvaluation = evaluate_dual_axis_candidate( ...
            currentConfig,randomBank,stage2Options);
        print_evaluation_local(sprintf('Joint round %d after kaScale', ...
            jointRound),jointEvaluation);
    end

    stage2Final = jointEvaluation;
    history(end+1,1) = evaluation_history_local(stage2Final,2, ...
        'jointRefinement',NaN,'joint_round_final',jointRound); %#ok<AGROW>
    save_checkpoint_local(outputDirectory,currentConfig,history, ...
        parameterResults,2);
    if stage2Final.withinBothTolerances
        fprintf('Stage 2 joint refinement satisfied both directions.\n');
        break;
    end

    roundImprovement = roundInitialScore-stage2Final.objectiveScore;
    if roundImprovement > minimumJointImprovement
        jointNoImprovementCount = 0;
    else
        jointNoImprovementCount = jointNoImprovementCount+1;
    end
    fprintf('Maximum normalized error improvement: %.9g.\n',roundImprovement);
    if jointNoImprovementCount >= ...
            currentConfig.dualOptimization.noImprovementPatience
        fprintf('Joint refinement had no significant improvement for %d rounds.\n', ...
            jointNoImprovementCount);
        break;
    end
end

%% Stage 3: Optimize the rotation upper bound.
fprintf('\n--- Stage 3: Optimize the rotation upper bound ---\n');
stage3Options = baseOptions;
stage3Options.objectiveMode = 'directionalExtrema';
[currentConfig,stage3Result] = optimize_one_dual_axis_parameter( ...
    currentConfig,randomBank,rotationParameter,stage3Options,cache);
history = append_parameter_history_local( ...
    history,stage3Result,3,'directionalExtrema',0);
parameterResults(end+1,1) = parameter_summary_local( ...
    stage3Result,3,'directionalExtrema',true,0);
stage3Final = evaluate_dual_axis_candidate( ...
    currentConfig,randomBank,stage3Options);
history(end+1,1) = evaluation_history_local(stage3Final,3, ...
    'rotationUpperDegree', ...
    get_dual_axis_parameter(currentConfig,rotationParameter), ...
    'stage_final',0);
print_evaluation_local('Stage 3 final',stage3Final);
save_checkpoint_local(outputDirectory,currentConfig,history,parameterResults,3);

if stage3Final.withinBothTolerances
    if abs(get_dual_axis_parameter(currentConfig,rotationParameter)) < 1e-12
        stopReason = 'directional_extrema_reached_at_zero_rotation';
    else
        stopReason = 'directional_extrema_reached_after_rotation_optimization';
    end
else
    stopReason = 'all_stages_completed_without_full_tolerance';
end
searchResult = finish_search_local(initialConfig,currentConfig, ...
    randomBank,baseOptions,history,parameterResults,3,stopReason,cache);
end

function parameter = get_parameter_local(parameters,name)
index = find(strcmp({parameters.name},name),1);
assert(~isempty(index),'Missing staged parameter: %s.',name);
parameter = parameters(index);
end

function history = append_parameter_history_local( ...
        history,result,stage,criterion,jointRound)
for index = 1:numel(result.evaluations)
    item = result.evaluations(index);
    row = empty_history_local();
    row.stage = stage;
    row.jointRound = jointRound;
    row.criterion = criterion;
    row.parameterName = result.parameterName;
    row.parameterValue = item.parameterValue;
    row.phase = item.phase;
    row.status = item.status;
    row.fwhmMaximumDegree = item.fwhmMaximumDegree;
    row.fwhmMinimumDegree = item.fwhmMinimumDegree;
    row.maximumDirectionAzimuthDegree = item.maximumDirectionAzimuthDegree;
    row.minimumDirectionAzimuthDegree = item.minimumDirectionAzimuthDegree;
    row.errorMaximumDegree = item.errorMaximumDegree;
    row.errorMinimumDegree = item.errorMinimumDegree;
    row.objectiveScore = item.objectiveScore;
    row.objectiveRmsScore = item.objectiveRmsScore;
    row.withinMaximumTolerance = item.withinMaximumTolerance;
    row.withinMinimumTolerance = item.withinMinimumTolerance;
    row.withinBothTolerances = item.withinBothTolerances;
    row.criterionSatisfied = item.criterionSatisfied;
    row.targetAssignment = item.targetAssignment;
    row.validKernelCount = item.validKernelCount;
    row.elapsedSecond = item.elapsedSecond;
    row.fromCache = item.fromCache;
    row.errorMessage = item.errorMessage;
    history(end+1,1) = row; %#ok<AGROW>
end
end

function row = evaluation_history_local( ...
        evaluation,stage,parameterName,parameterValue,phase,jointRound)
row = empty_history_local();
row.stage = stage;
row.jointRound = jointRound;
row.criterion = evaluation.criterionName;
row.parameterName = parameterName;
row.parameterValue = parameterValue;
row.phase = phase;
row.status = evaluation.status;
row.fwhmMaximumDegree = evaluation.fwhmMaximumDirectionDegree;
row.fwhmMinimumDegree = evaluation.fwhmMinimumDirectionDegree;
row.maximumDirectionAzimuthDegree = evaluation.maximumDirectionAzimuthDegree;
row.minimumDirectionAzimuthDegree = evaluation.minimumDirectionAzimuthDegree;
row.errorMaximumDegree = evaluation.signedErrorMaximumDegree;
row.errorMinimumDegree = evaluation.signedErrorMinimumDegree;
row.objectiveScore = evaluation.objectiveScore;
row.objectiveRmsScore = evaluation.objectiveRmsScore;
row.withinMaximumTolerance = evaluation.withinMaximumTolerance;
row.withinMinimumTolerance = evaluation.withinMinimumTolerance;
row.withinBothTolerances = evaluation.withinBothTolerances;
row.criterionSatisfied = evaluation.criterionSatisfied;
row.targetAssignment = evaluation.targetAssignment;
row.validKernelCount = evaluation.validKernelCount;
row.elapsedSecond = evaluation.elapsedSecond;
row.fromCache = evaluation.fromCache;
row.errorMessage = evaluation.errorMessage;
end

function row = parameter_summary_local( ...
        result,stage,criterion,executed,jointRound)
row = empty_parameter_result_local();
row.stage = stage;
row.jointRound = jointRound;
row.criterion = criterion;
row.parameterName = result.parameterName;
row.displayName = result.displayName;
row.initialValue = result.initialValue;
row.bestValue = result.bestValue;
row.bestObjectiveScore = result.bestObjectiveScore;
row.bestFwhmMaximumDegree = result.bestFwhmMaximumDegree;
row.bestFwhmMinimumDegree = result.bestFwhmMinimumDegree;
row.criterionSatisfied = result.criterionSatisfied;
row.withinBothTolerances = result.withinBothTolerances;
row.executed = executed;
row.stopReason = result.stopReason;
row.evaluationCount = result.evaluationCount;
end

function searchResult = finish_search_local(initialConfig,currentConfig, ...
        randomBank,baseOptions,history,parameterResults,completedStages, ...
        stopReason,cache)
finalOptions = baseOptions;
finalOptions.objectiveMode = 'directionalExtrema';
finalEvaluation = evaluate_dual_axis_candidate( ...
    currentConfig,randomBank,finalOptions);
searchResult.initialConfig = initialConfig;
searchResult.bestConfig = currentConfig;
searchResult.finalSearchEvaluation = finalEvaluation;
searchResult.history = struct2table(history);
searchResult.parameterResults = struct2table(parameterResults);
searchResult.completedStages = completedStages;
if isempty(parameterResults)
    searchResult.jointRefinementRounds = 0;
else
    searchResult.jointRefinementRounds = max([parameterResults.jointRound]);
end
searchResult.stopReason = stopReason;
searchResult.cacheEntryCount = cache.Count;
end

function print_evaluation_local(label,evaluation)
if strcmp(evaluation.criterionName,'maximumDirection')
    fprintf(['%s: maximum-direction FWHM=%.6f deg (azimuth %.3f deg), ', ...
        'target=%.6f deg, score=%.6f, criterionSatisfied=%d.\n'],label, ...
        evaluation.fwhmMaximumDirectionDegree, ...
        evaluation.maximumDirectionAzimuthDegree, ...
        evaluation.targetMaximumDegree,evaluation.objectiveScore, ...
        evaluation.criterionSatisfied);
else
    fprintf(['%s: maximum direction %.6f deg@%.3f deg -> %.6f deg; ', ...
        'minimum direction %.6f deg@%.3f deg -> %.6f deg; ', ...
        'score=%.6f, withinBothTolerances=%d.\n'],label, ...
        evaluation.fwhmMaximumDirectionDegree, ...
        evaluation.maximumDirectionAzimuthDegree, ...
        evaluation.targetMaximumDegree, ...
        evaluation.fwhmMinimumDirectionDegree, ...
        evaluation.minimumDirectionAzimuthDegree, ...
        evaluation.targetMinimumDegree,evaluation.objectiveScore, ...
        evaluation.withinBothTolerances);
end
end

function save_checkpoint_local(outputDirectory,currentConfig,history, ...
        parameterResults,stage)
if isempty(outputDirectory)
    return;
end
if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end
historyTable = struct2table(history);
parameterResultTable = struct2table(parameterResults);
save(fullfile(outputDirectory,'dual_axis_checkpoint.mat'), ...
    'currentConfig','historyTable','parameterResultTable','stage','-v7.3');
end

function row = empty_history_local()
row = struct('stage',0,'jointRound',0,'criterion','','parameterName','', ...
    'parameterValue',NaN,'phase','','status','invalid', ...
    'fwhmMaximumDegree',NaN,'fwhmMinimumDegree',NaN, ...
    'maximumDirectionAzimuthDegree',NaN, ...
    'minimumDirectionAzimuthDegree',NaN, ...
    'errorMaximumDegree',NaN,'errorMinimumDegree',NaN, ...
    'objectiveScore',Inf,'objectiveRmsScore',Inf, ...
    'withinMaximumTolerance',false,'withinMinimumTolerance',false, ...
    'withinBothTolerances',false,'criterionSatisfied',false, ...
    'targetAssignment','','validKernelCount',0,'elapsedSecond',NaN, ...
    'fromCache',false,'errorMessage','');
end

function row = empty_parameter_result_local()
row = struct('stage',0,'jointRound',0,'criterion','','parameterName','', ...
    'displayName','','initialValue',NaN,'bestValue',NaN, ...
    'bestObjectiveScore',Inf,'bestFwhmMaximumDegree',NaN, ...
    'bestFwhmMinimumDegree',NaN,'criterionSatisfied',false, ...
    'withinBothTolerances',false,'executed',false, ...
    'stopReason','','evaluationCount',0);
end
