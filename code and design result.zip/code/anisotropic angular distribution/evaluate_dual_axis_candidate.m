function evaluation = evaluate_dual_axis_candidate(config,randomBank,options)
%EVALUATE_DUAL_AXIS_CANDIDATE Evaluate directional FWHM extrema.
if nargin < 3
    options = struct();
end
if ~isfield(options,'objectiveMode')
    options.objectiveMode = 'directionalExtrema';
end
if ~isfield(options,'retainLargeData')
    options.retainLargeData = false;
end
if ~isfield(options,'failFast')
    options.failFast = config.dualOptimization.failFast;
end
assert(any(strcmp(options.objectiveMode, ...
    {'maximumDirection','directionalExtrema'})), ...
    'objectiveMode must be maximumDirection or directionalExtrema.');
validate_dual_axis_config(config);
requestedRetainLargeData = options.retainLargeData;
physicalOptions = options;
physicalOptions.retainLargeData = true;
evaluation = evaluate_diffuser_candidate(config,randomBank,physicalOptions);
evaluation.singleMetricObjectiveDegree = evaluation.objectiveDegree;
if ~strcmp(evaluation.status,'valid')
    evaluation = attach_invalid_extrema_fields_local( ...
        evaluation,config,options.objectiveMode);
    return;
end
try
    directionalMetrics = measure_directional_fwhm_extrema( ...
        config,evaluation.kernelStats);
catch exception
    if options.failFast
        rethrow(exception);
    end
    evaluation.status = 'invalid';
    evaluation.errorMessage = exception.message;
    evaluation = attach_invalid_extrema_fields_local( ...
        evaluation,config,options.objectiveMode);
    evaluation = strip_large_fields_local(evaluation);
    return;
end
target1 = config.dualTarget.xFwhmDegree;
target2 = config.dualTarget.yFwhmDegree;
tolerance1 = config.dualTarget.xToleranceDegree;
tolerance2 = config.dualTarget.yToleranceDegree;
if target1 >= target2
    targetMaximum = target1;
    targetMinimum = target2;
    maximumTolerance = tolerance1;
    minimumTolerance = tolerance2;
else
    targetMaximum = target2;
    targetMinimum = target1;
    maximumTolerance = tolerance2;
    minimumTolerance = tolerance1;
end
fwhmMaximum = directionalMetrics.fwhmMaximumDirectionDegree;
fwhmMinimum = directionalMetrics.fwhmMinimumDirectionDegree;
maximumError = fwhmMaximum-targetMaximum;
minimumError = fwhmMinimum-targetMinimum;
maximumNormalizedError = abs(maximumError)/maximumTolerance;
minimumNormalizedError = abs(minimumError)/minimumTolerance;
extremaScore = max(maximumNormalizedError,minimumNormalizedError);
extremaRms = hypot(maximumNormalizedError,minimumNormalizedError)/sqrt(2);
withinMaximum = abs(maximumError) <= maximumTolerance;
withinMinimum = abs(minimumError) <= minimumTolerance;
evaluation.inputTarget1Degree = target1;
evaluation.inputTarget2Degree = target2;
evaluation.targetMaximumDegree = targetMaximum;
evaluation.targetMinimumDegree = targetMinimum;
evaluation.maximumTargetToleranceDegree = maximumTolerance;
evaluation.minimumTargetToleranceDegree = minimumTolerance;
evaluation.fwhmMaximumDirectionDegree = fwhmMaximum;
evaluation.fwhmMinimumDirectionDegree = fwhmMinimum;
evaluation.maximumDirectionAzimuthDegree = ...
    directionalMetrics.maximumDirectionAzimuthDegree;
evaluation.minimumDirectionAzimuthDegree = ...
    directionalMetrics.minimumDirectionAzimuthDegree;
evaluation.signedErrorMaximumDegree = maximumError;
evaluation.signedErrorMinimumDegree = minimumError;
evaluation.absoluteErrorMaximumDegree = abs(maximumError);
evaluation.absoluteErrorMinimumDegree = abs(minimumError);
evaluation.normalizedErrorMaximum = maximumNormalizedError;
evaluation.normalizedErrorMinimum = minimumNormalizedError;
evaluation.directionalExtremaObjectiveScore = extremaScore;
evaluation.directionalExtremaObjectiveRmsScore = extremaRms;
evaluation.withinMaximumTolerance = withinMaximum;
evaluation.withinMinimumTolerance = withinMinimum;
evaluation.withinBothTolerances = withinMaximum && withinMinimum;
evaluation.maximumDirectionScore = maximumNormalizedError;
evaluation.maximumDirectionSatisfied = withinMaximum;
evaluation.targetAssignment = 'maximumMinimum';
switch options.objectiveMode
    case 'maximumDirection'
        evaluation.objectiveScore = maximumNormalizedError;
        evaluation.objectiveRmsScore = maximumNormalizedError;
        evaluation.objectiveDegree = abs(maximumError);
        evaluation.criterionSatisfied = withinMaximum;
        evaluation.criterionName = 'maximumDirection';
    case 'directionalExtrema'
        evaluation.objectiveScore = extremaScore;
        evaluation.objectiveRmsScore = extremaRms;
        evaluation.objectiveDegree = hypot(abs(maximumError),abs(minimumError));
        evaluation.criterionSatisfied = evaluation.withinBothTolerances;
        evaluation.criterionName = 'directionalExtrema';
end
evaluation.withinTolerance = evaluation.criterionSatisfied;
if requestedRetainLargeData
    evaluation.directionalMetrics = directionalMetrics;
else
    evaluation = strip_large_fields_local(evaluation);
end
end

function evaluation = attach_invalid_extrema_fields_local( ...
        evaluation,config,objectiveMode)
targets = [config.dualTarget.xFwhmDegree,config.dualTarget.yFwhmDegree];
evaluation.inputTarget1Degree = targets(1);
evaluation.inputTarget2Degree = targets(2);
evaluation.targetMaximumDegree = max(targets);
evaluation.targetMinimumDegree = min(targets);
evaluation.maximumTargetToleranceDegree = NaN;
evaluation.minimumTargetToleranceDegree = NaN;
evaluation.fwhmMaximumDirectionDegree = NaN;
evaluation.fwhmMinimumDirectionDegree = NaN;
evaluation.maximumDirectionAzimuthDegree = NaN;
evaluation.minimumDirectionAzimuthDegree = NaN;
evaluation.signedErrorMaximumDegree = NaN;
evaluation.signedErrorMinimumDegree = NaN;
evaluation.absoluteErrorMaximumDegree = Inf;
evaluation.absoluteErrorMinimumDegree = Inf;
evaluation.normalizedErrorMaximum = Inf;
evaluation.normalizedErrorMinimum = Inf;
evaluation.directionalExtremaObjectiveScore = Inf;
evaluation.directionalExtremaObjectiveRmsScore = Inf;
evaluation.withinMaximumTolerance = false;
evaluation.withinMinimumTolerance = false;
evaluation.withinBothTolerances = false;
evaluation.maximumDirectionScore = Inf;
evaluation.maximumDirectionSatisfied = false;
evaluation.targetAssignment = 'invalid';
evaluation.objectiveScore = Inf;
evaluation.objectiveRmsScore = Inf;
evaluation.objectiveDegree = Inf;
evaluation.criterionSatisfied = false;
evaluation.criterionName = objectiveMode;
evaluation.withinTolerance = false;
end

function evaluation = strip_large_fields_local(evaluation)
largeFields = {'config','randomBank','surfaceData','units','kernelStats', ...
    'angularDistribution','metrics','directionalMetrics'};
existing = largeFields(isfield(evaluation,largeFields));
if ~isempty(existing)
    evaluation = rmfield(evaluation,existing);
end
end
