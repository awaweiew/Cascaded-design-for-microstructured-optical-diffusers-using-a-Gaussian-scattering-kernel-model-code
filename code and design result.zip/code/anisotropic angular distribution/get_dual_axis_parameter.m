function value = get_dual_axis_parameter(config,parameter)
%GET_DUAL_AXIS_PARAMETER Read the current optimization parameter.

switch parameter.name
    case 'kaScale'
        value = config.dualOptimization.currentKaScale;
    case 'kb'
        value = config.geometry.kb;
    case 'rotationUpperDegree'
        value = rad2deg(config.geometry.rotationRange);
    otherwise
        error('Unknown dual-axis optimization parameter: %s.',parameter.name);
end
end
