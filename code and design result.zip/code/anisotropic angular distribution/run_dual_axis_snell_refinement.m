function result = run_dual_axis_snell_refinement( ...
        gaussianBestConfig,randomBank,control,outputDirectory)
%RUN_DUAL_AXIS_SNELL_REFINEMENT Refine the Gaussian solution with Snell tracing.
% Rebuild the surface and evaluate directional ray-density FWHM.

validate_dual_axis_config(gaussianBestConfig);
assert(isfolder(outputDirectory),'Snell refinement output directory not found: %s',outputDirectory);
validate_control_local(control);

parameterNames = {'kb','kaScale','rotationUpperDegree'};
parameters = gaussianBestConfig.dualOptimization.parameters;
selectedParameters = repmat(parameters(1),1,numel(parameterNames));
for index = 1:numel(parameterNames)
    parameterIndex = find(strcmp({parameters.name},parameterNames{index}),1);
    assert(~isempty(parameterIndex),'Missing Snell refinement parameter: %s.',parameterNames{index});
    selectedParameters(index) = parameters(parameterIndex);
end

startValues = [gaussianBestConfig.geometry.kb, ...
    gaussianBestConfig.dualOptimization.currentKaScale, ...
    rad2deg(gaussianBestConfig.geometry.rotationRange)];
halfRanges = [control.snellKbHalfRange,control.snellKaScaleHalfRange, ...
    control.snellRotationHalfRangeDegree];
lowerBounds = max([selectedParameters.lowerBound],startValues-halfRanges);
upperBounds = min([selectedParameters.upperBound],startValues+halfRanges);
coarseSteps = [control.snellKbCoarseStep,control.snellKaScaleCoarseStep, ...
    control.snellRotationCoarseStepDegree];
fineSteps = [control.snellKbFineStep,control.snellKaScaleFineStep, ...
    control.snellRotationFineStepDegree];

fprintf('\n[Starting local Snell ray-tracing refinement]\n');
fprintf('Gaussian initial values: kb=%.9g, kaScale=%.9g, rotation upper bound=%.9g deg.\n', ...
    startValues(1),startValues(2),startValues(3));
fprintf(['Local ranges: kb [%.9g, %.9g]; kaScale [%.9g, %.9g]; ', ...
    'rotation [%.9g, %.9g] deg.\n'],lowerBounds(1),upperBounds(1), ...
    lowerBounds(2),upperBounds(2),lowerBounds(3),upperBounds(3));
fprintf('Search rays: %.0f; final evaluation rays: %.0f; sampling: %s.\n', ...
    control.snellSearchRayCount,control.snellFinalRayCount, ...
    control.snellRaySamplingMode);

searchOptions = evaluation_options_local(control, ...
    control.snellSearchRayCount,false);
cache = containers.Map('KeyType','char','ValueType','any');
history = repmat(empty_history_local(),0,1);
currentConfig = gaussianBestConfig;
currentValues = startValues;
evaluationCount = 0;

[currentEvaluation,~] = evaluate_cached_local( ...
    currentConfig,currentValues,'initial',0);
bestEvaluation = currentEvaluation;
bestConfig = currentConfig;
bestValues = currentValues;
stopReason = 'maximum_iterations_reached';

steps = coarseSteps;
iteration = 0;
noImprovementCount = 0;
while evaluationCount < control.snellMaximumEvaluations && ...
        iteration < control.snellMaximumIterations
    iteration = iteration+1;
    improvedThisIteration = false;

    for parameterIndex = 1:numel(selectedParameters)
        if evaluationCount >= control.snellMaximumEvaluations
            break;
        end
        candidates = unique([ ...
            max(lowerBounds(parameterIndex), ...
                currentValues(parameterIndex)-steps(parameterIndex)), ...
            min(upperBounds(parameterIndex), ...
                currentValues(parameterIndex)+steps(parameterIndex))]);
        candidates(abs(candidates-currentValues(parameterIndex)) <= 10*eps) = [];
        coordinateBestEvaluation = currentEvaluation;
        coordinateBestConfig = currentConfig;
        coordinateBestValues = currentValues;

        for candidateIndex = 1:numel(candidates)
            if evaluationCount >= control.snellMaximumEvaluations
                break;
            end
            candidateValues = currentValues;
            candidateValues(parameterIndex) = candidates(candidateIndex);
            candidateConfig = apply_dual_axis_parameter( ...
                currentConfig,selectedParameters(parameterIndex), ...
                candidates(candidateIndex));
            [candidateEvaluation,~] = evaluate_cached_local( ...
                candidateConfig,candidateValues,parameterNames{parameterIndex}, ...
                iteration);
            if candidateEvaluation.objectiveScore+ ...
                    control.snellMinimumObjectiveImprovement < ...
                    coordinateBestEvaluation.objectiveScore
                coordinateBestEvaluation = candidateEvaluation;
                coordinateBestConfig = candidateConfig;
                coordinateBestValues = candidateValues;
            end
        end

        if coordinateBestEvaluation.objectiveScore+ ...
                control.snellMinimumObjectiveImprovement < ...
                currentEvaluation.objectiveScore
            currentEvaluation = coordinateBestEvaluation;
            currentConfig = coordinateBestConfig;
            currentValues = coordinateBestValues;
            improvedThisIteration = true;
        end
        if currentEvaluation.objectiveScore < bestEvaluation.objectiveScore
            bestEvaluation = currentEvaluation;
            bestConfig = currentConfig;
            bestValues = currentValues;
        end
        if currentEvaluation.withinBothTolerances
            stopReason = 'both_directional_targets_reached';
            break;
        end
    end

    if currentEvaluation.withinBothTolerances
        break;
    end

    % Test joint kb and kaScale directions after coordinate stagnation.
    if ~improvedThisIteration && control.snellEnableJointKbKa && ...
            evaluationCount < control.snellMaximumEvaluations
        jointSigns = [-1,-1;-1,1;1,-1;1,1];
        jointBestEvaluation = currentEvaluation;
        jointBestConfig = currentConfig;
        jointBestValues = currentValues;
        for jointIndex = 1:size(jointSigns,1)
            if evaluationCount >= control.snellMaximumEvaluations
                break;
            end
            candidateValues = currentValues;
            candidateValues(1) = min(max( ...
                currentValues(1)+jointSigns(jointIndex,1)*steps(1), ...
                lowerBounds(1)),upperBounds(1));
            candidateValues(2) = min(max( ...
                currentValues(2)+jointSigns(jointIndex,2)*steps(2), ...
                lowerBounds(2)),upperBounds(2));
            if all(abs(candidateValues(1:2)-currentValues(1:2)) <= 10*eps)
                continue;
            end
            candidateConfig = apply_dual_axis_parameter( ...
                currentConfig,selectedParameters(1),candidateValues(1));
            candidateConfig = apply_dual_axis_parameter( ...
                candidateConfig,selectedParameters(2),candidateValues(2));
            [candidateEvaluation,~] = evaluate_cached_local( ...
                candidateConfig,candidateValues,'kb_ka_joint',iteration);
            if candidateEvaluation.objectiveScore+ ...
                    control.snellMinimumObjectiveImprovement < ...
                    jointBestEvaluation.objectiveScore
                jointBestEvaluation = candidateEvaluation;
                jointBestConfig = candidateConfig;
                jointBestValues = candidateValues;
            end
        end
        if jointBestEvaluation.objectiveScore+ ...
                control.snellMinimumObjectiveImprovement < ...
                currentEvaluation.objectiveScore
            currentEvaluation = jointBestEvaluation;
            currentConfig = jointBestConfig;
            currentValues = jointBestValues;
            improvedThisIteration = true;
            if currentEvaluation.objectiveScore < bestEvaluation.objectiveScore
                bestEvaluation = currentEvaluation;
                bestConfig = currentConfig;
                bestValues = currentValues;
            end
        end
    end

    if currentEvaluation.withinBothTolerances
        stopReason = 'both_directional_targets_reached';
        break;
    end
    if ~improvedThisIteration
        noImprovementCount = noImprovementCount+1;
        if noImprovementCount >= control.snellNoImprovementPatience
            if all(steps <= fineSteps+10*eps)
                stopReason = 'adaptive_minimum_steps_reached';
                break;
            end
            oldSteps = steps;
            steps = max(fineSteps,control.snellStepReductionFactor*steps);
            noImprovementCount = 0;
            fprintf(['No improvement for %d rounds; step sizes reduced from [%.9g %.9g %.9g] ', ...
                'to [%.9g %.9g %.9g].\n'], ...
                control.snellNoImprovementPatience,oldSteps,steps);
        end
    else
        noImprovementCount = 0;
    end
end
if evaluationCount >= control.snellMaximumEvaluations
    stopReason = 'maximum_evaluations_reached';
end

% Re-evaluate the final point with more rays.
finalOptions = evaluation_options_local(control, ...
    control.snellFinalRayCount,true);
fprintf('\n[Final Snell evaluation with increased ray count]\n');
finalEvaluation = evaluate_snell_candidate_local( ...
    bestConfig,randomBank,finalOptions);

historyTable = struct2table(history,'AsArray',true);
if ~isempty(historyTable)
    writetable(historyTable,fullfile(outputDirectory, ...
        'snell_refinement_history.csv'));
end
summaryTable = table(bestValues(1),bestValues(2),bestValues(3), ...
    finalEvaluation.fwhmMaximumDirectionDegree, ...
    finalEvaluation.fwhmMinimumDirectionDegree, ...
    finalEvaluation.maximumDirectionAzimuthDegree, ...
    finalEvaluation.minimumDirectionAzimuthDegree, ...
    finalEvaluation.targetMaximumDegree, ...
    finalEvaluation.targetMinimumDegree, ...
    finalEvaluation.signedErrorMaximumDegree, ...
    finalEvaluation.signedErrorMinimumDegree, ...
    finalEvaluation.objectiveScore, ...
    finalEvaluation.withinBothTolerances, ...
    finalEvaluation.validSnellRayCount, ...
    string(stopReason), ...
    'VariableNames',{'kb','kaScale','rotationUpperDegree', ...
    'fwhmMaximumDirectionDegree','fwhmMinimumDirectionDegree', ...
    'maximumDirectionAzimuthDegree','minimumDirectionAzimuthDegree', ...
    'targetMaximumDegree','targetMinimumDegree', ...
    'signedErrorMaximumDegree','signedErrorMinimumDegree', ...
    'objectiveScore','withinBothTolerances','validSnellRayCount','stopReason'});
writetable(summaryTable,fullfile(outputDirectory,'snell_final_summary.csv'));
write_json_local(fullfile(outputDirectory,'best_config_snell_refined.json'), ...
    finalEvaluation.config);
if control.snellSaveAngularCsv
    writematrix(finalEvaluation.angularDistribution.normalized, ...
        fullfile(outputDirectory, ...
        'snell_final_angular_distribution_normalized.csv'));
end

searchResult.bestConfig = bestConfig;
searchResult.bestSearchEvaluation = bestEvaluation;
searchResult.bestValues = bestValues;
searchResult.history = historyTable;
searchResult.stopReason = stopReason;
searchResult.evaluationCount = evaluationCount;
searchResult.localLowerBounds = lowerBounds;
searchResult.localUpperBounds = upperBounds;
searchResult.finalSteps = steps;
searchResult.noImprovementCount = noImprovementCount;

save(fullfile(outputDirectory,'complete_snell_refinement_result.mat'), ...
    'searchResult','finalEvaluation','control','-v7.3');
if control.createFigures
    plot_snell_results_local(finalEvaluation,historyTable,outputDirectory);
end

result.bestConfig = finalEvaluation.config;
result.bestEvaluation = finalEvaluation;
result.searchResult = searchResult;
result.control = control;
result.outputDirectory = outputDirectory;

fprintf('\nSnell refinement complete.\n');
fprintf('Maximum-direction FWHM: %.6f deg (azimuth %.3f deg, error %+.6f deg).\n', ...
    finalEvaluation.fwhmMaximumDirectionDegree, ...
    finalEvaluation.maximumDirectionAzimuthDegree, ...
    finalEvaluation.signedErrorMaximumDegree);
fprintf('Minimum-direction FWHM: %.6f deg (azimuth %.3f deg, error %+.6f deg).\n', ...
    finalEvaluation.fwhmMinimumDirectionDegree, ...
    finalEvaluation.minimumDirectionAzimuthDegree, ...
    finalEvaluation.signedErrorMinimumDegree);
fprintf('Snell final evaluation satisfies both tolerances: %d.\n',finalEvaluation.withinBothTolerances);
fprintf('Final parameters: kaScale=%.9g, kb=%.9g, rotation upper bound=%.9g deg.\n', ...
    bestValues(2),bestValues(1),bestValues(3));

    function [evaluation,fromCache] = evaluate_cached_local( ...
            candidateConfig,candidateValues,phase,currentIteration)
        key = sprintf('%.12g|%.12g|%.12g',candidateValues);
        fromCache = isKey(cache,key);
        if fromCache
            evaluation = cache(key);
        else
            try
                evaluation = evaluate_snell_candidate_local( ...
                    candidateConfig,randomBank,searchOptions);
            catch exception
                evaluation = invalid_evaluation_local( ...
                    candidateConfig,exception.message);
            end
            cache(key) = evaluation;
            evaluationCount = evaluationCount+1;
        end
        record = history_from_evaluation_local(evaluation,candidateValues, ...
            phase,currentIteration,fromCache);
        history(end+1,1) = record;
        fprintf(['[Snell %02d] %-20s kb=%8.5f, ka=%8.5f, rot=%7.3f, ', ...
            'max=%9.5f, min=%9.5f, score=%9.4f%s\n'], ...
            evaluationCount,phase,candidateValues(1),candidateValues(2), ...
            candidateValues(3),record.fwhmMaximumDegree, ...
            record.fwhmMinimumDegree,record.objectiveScore, ...
            ternary_local(fromCache,' [cache]',''));
    end
end

function options = evaluation_options_local(control,rayCount,retainLargeData)
options.rayCount = rayCount;
options.rayChunkSize = control.snellRayChunkSize;
options.raySamplingMode = control.snellRaySamplingMode;
options.rayRandomSeed = control.snellRayRandomSeed;
options.perpendicularBandwidthDegree = ...
    control.snellPerpendicularBandwidthDegree;
options.profileSmoothingSigmaBins = control.snellProfileSmoothingSigmaBins;
options.angularSmoothingSigmaBins = control.snellAngularSmoothingSigmaBins;
options.retainLargeData = retainLargeData;
end

function evaluation = evaluate_snell_candidate_local(config,randomBank,options)
startTime = tic;
surface = generate_diffuser_surface(config,randomBank);
[slopeX,slopeY] = gradient(surface.Z,surface.dx,surface.dy);
normalLength = sqrt(1+slopeX.^2+slopeY.^2);
normalX = slopeX./normalLength;
normalY = slopeY./normalLength;
normalZ = -1./normalLength;
clear slopeX slopeY normalLength;

% Estimate the orthogonal principal directions.
[rayCount,sumAngles,sumOuter,validCount,outsideCount] = ...
    trace_moments_local(normalX,normalY,normalZ,config,options);
assert(validCount >= 10,'Insufficient valid Snell rays for directional FWHM measurement.');
meanAngles = sumAngles/validCount;
covariance = (sumOuter/validCount)-meanAngles.'*meanAngles;
covariance = 0.5*(covariance+covariance.');
[vectors,values] = eig(covariance,'vector');
[~,order] = sort(values,'descend');
directions = vectors(:,order);
directions(:,1) = canonicalize_direction_local(directions(:,1));
directions(:,2) = canonicalize_direction_local(directions(:,2));

% Estimate density profiles along the principal directions.
[theta,profiles,angularCounts,inRangeCount] = trace_profiles_local( ...
    normalX,normalY,normalZ,config,options,meanAngles,directions);
for index = 1:2
    profiles(:,index) = gaussian_smooth_1d_local( ...
        profiles(:,index),options.profileSmoothingSigmaBins);
    profiles(:,index) = profiles(:,index)/(max(profiles(:,index))+eps);
end

widths = nan(1,2);
leftHalf = nan(1,2);
rightHalf = nan(1,2);
azimuths = nan(1,2);
for index = 1:2
    [leftHalf(index),rightHalf(index),widths(index)] = ...
        find_level_width_local(theta,profiles(:,index),0.5);
    azimuths(index) = mod(atan2d(directions(2,index),directions(1,index)),180);
end
assert(all(isfinite(widths)), ...
    'The Snell angular range does not contain a complete directional FWHM; expand angular range.');
[maximumWidth,maximumIndex] = max(widths);
[minimumWidth,minimumIndex] = min(widths);

[targetMaximum,targetMinimum,toleranceMaximum,toleranceMinimum] = ...
    target_values_local(config);
errorMaximum = maximumWidth-targetMaximum;
errorMinimum = minimumWidth-targetMinimum;
normalizedMaximum = abs(errorMaximum)/toleranceMaximum;
normalizedMinimum = abs(errorMinimum)/toleranceMinimum;

directional.thetaDegree = theta;
directional.maximumDirectionProfileNormalized = profiles(:,maximumIndex);
directional.minimumDirectionProfileNormalized = profiles(:,minimumIndex);
directional.fwhmMaximumDirectionDegree = maximumWidth;
directional.fwhmMinimumDirectionDegree = minimumWidth;
directional.maximumDirectionAzimuthDegree = azimuths(maximumIndex);
directional.minimumDirectionAzimuthDegree = azimuths(minimumIndex);
directional.maximumDirectionVector = directions(:,maximumIndex).';
directional.minimumDirectionVector = directions(:,minimumIndex).';
directional.maximumLeftHalfDegree = leftHalf(maximumIndex);
directional.maximumRightHalfDegree = rightHalf(maximumIndex);
directional.minimumLeftHalfDegree = leftHalf(minimumIndex);
directional.minimumRightHalfDegree = rightHalf(minimumIndex);
directional.mixtureMeanThetaXDegree = meanAngles(1);
directional.mixtureMeanThetaYDegree = meanAngles(2);
directional.mixtureCovarianceDegree2 = covariance;
directional.principalDirectionFwhmDegree = widths;
directional.principalDirectionAzimuthsDegree = azimuths;

evaluation.status = 'valid';
evaluation.config = config;
evaluation.inputTarget1Degree = config.dualTarget.xFwhmDegree;
evaluation.inputTarget2Degree = config.dualTarget.yFwhmDegree;
evaluation.targetMaximumDegree = targetMaximum;
evaluation.targetMinimumDegree = targetMinimum;
evaluation.maximumTargetToleranceDegree = toleranceMaximum;
evaluation.minimumTargetToleranceDegree = toleranceMinimum;
evaluation.fwhmMaximumDirectionDegree = maximumWidth;
evaluation.fwhmMinimumDirectionDegree = minimumWidth;
evaluation.maximumDirectionAzimuthDegree = azimuths(maximumIndex);
evaluation.minimumDirectionAzimuthDegree = azimuths(minimumIndex);
evaluation.signedErrorMaximumDegree = errorMaximum;
evaluation.signedErrorMinimumDegree = errorMinimum;
evaluation.absoluteErrorMaximumDegree = abs(errorMaximum);
evaluation.absoluteErrorMinimumDegree = abs(errorMinimum);
evaluation.normalizedErrorMaximum = normalizedMaximum;
evaluation.normalizedErrorMinimum = normalizedMinimum;
evaluation.objectiveScore = max(normalizedMaximum,normalizedMinimum);
evaluation.objectiveRmsScore = hypot(normalizedMaximum,normalizedMinimum)/sqrt(2);
evaluation.objectiveDegree = hypot(errorMaximum,errorMinimum);
evaluation.withinMaximumTolerance = abs(errorMaximum) <= toleranceMaximum;
evaluation.withinMinimumTolerance = abs(errorMinimum) <= toleranceMinimum;
evaluation.withinBothTolerances = evaluation.withinMaximumTolerance && ...
    evaluation.withinMinimumTolerance;
evaluation.withinTolerance = evaluation.withinBothTolerances;
evaluation.criterionSatisfied = evaluation.withinBothTolerances;
evaluation.criterionName = 'snellDirectionalExtrema';
evaluation.directionalMetrics = directional;
evaluation.totalRayCount = rayCount;
evaluation.validSnellRayCount = validCount;
evaluation.invalidSnellRayCount = rayCount-validCount;
evaluation.inAngularRangeRayCount = inRangeCount;
evaluation.outsideAngularRangeRayCount = outsideCount;
evaluation.elapsedSecond = toc(startTime);
evaluation.errorMessage = '';

if options.retainLargeData
    angularCounts = gaussian_smooth_2d_local( ...
        angularCounts,options.angularSmoothingSigmaBins);
    angular.thetaDegree = theta;
    angular.counts = angularCounts;
    angular.normalized = angularCounts/(max(angularCounts(:))+eps);
    angular.mode = 'full';
    angular.angleSpacingDegree = theta(2)-theta(1);
    evaluation.angularDistribution = angular;
    evaluation.surfaceData = surface;
else
    evaluation = rmfield(evaluation,'directionalMetrics');
end
end

function [totalCount,sumAngles,sumOuter,validCount,outsideCount] = ...
        trace_moments_local(normalX,normalY,normalZ,config,options)
totalCount = options.rayCount;
sumAngles = zeros(1,2);
sumOuter = zeros(2,2);
validCount = 0;
outsideCount = 0;
stream = create_stream_local(options);
processed = 0;
while processed < totalCount
    count = min(options.rayChunkSize,totalCount-processed);
    [thetaX,thetaY,valid] = trace_chunk_local(normalX,normalY,normalZ, ...
        config,options,stream,processed+1,count);
    thetaX = thetaX(valid);
    thetaY = thetaY(valid);
    angles = [thetaX,thetaY];
    sumAngles = sumAngles+sum(angles,1);
    sumOuter = sumOuter+angles.'*angles;
    validCount = validCount+size(angles,1);
    outsideCount = outsideCount+nnz(thetaX < config.angular.minimumDegree | ...
        thetaX > config.angular.maximumDegree | ...
        thetaY < config.angular.minimumDegree | ...
        thetaY > config.angular.maximumDegree);
    processed = processed+count;
end
end

function [theta,profiles,angularCounts,inRangeCount] = trace_profiles_local( ...
        normalX,normalY,normalZ,config,options,meanAngles,directions)
theta = linspace(config.angular.minimumDegree, ...
    config.angular.maximumDegree,config.angular.sampleCount).';
dTheta = theta(2)-theta(1);
edges = [theta(1)-0.5*dTheta; ...
    0.5*(theta(1:end-1)+theta(2:end));theta(end)+0.5*dTheta];
profiles = zeros(numel(theta),2);
if options.retainLargeData
    angularCounts = zeros(numel(theta),numel(theta));
else
    angularCounts = [];
end
inRangeCount = 0;
stream = create_stream_local(options);
processed = 0;
while processed < options.rayCount
    count = min(options.rayChunkSize,options.rayCount-processed);
    [thetaX,thetaY,valid] = trace_chunk_local(normalX,normalY,normalZ, ...
        config,options,stream,processed+1,count);
    thetaX = thetaX(valid);
    thetaY = thetaY(valid);
    deltaX = thetaX-meanAngles(1);
    deltaY = thetaY-meanAngles(2);
    coordinate1 = directions(1,1)*deltaX+directions(2,1)*deltaY;
    coordinate2 = directions(1,2)*deltaX+directions(2,2)*deltaY;
    profiles(:,1) = profiles(:,1)+weighted_histogram_local( ...
        coordinate1,coordinate2,edges,options.perpendicularBandwidthDegree);
    profiles(:,2) = profiles(:,2)+weighted_histogram_local( ...
        coordinate2,coordinate1,edges,options.perpendicularBandwidthDegree);
    if options.retainLargeData
        chunkCounts = histcounts2(thetaX,thetaY,edges,edges);
        angularCounts = angularCounts+chunkCounts;
        inRangeCount = inRangeCount+sum(chunkCounts(:));
    else
        inRangeCount = inRangeCount+nnz(thetaX >= theta(1) & thetaX <= theta(end) & ...
            thetaY >= theta(1) & thetaY <= theta(end));
    end
    processed = processed+count;
end
end

function histogram = weighted_histogram_local( ...
        parallelCoordinate,perpendicularCoordinate,edges,bandwidth)
keep = abs(perpendicularCoordinate) <= 4*bandwidth;
bins = discretize(parallelCoordinate(keep),edges);
weights = exp(-0.5*(perpendicularCoordinate(keep)/bandwidth).^2);
valid = ~isnan(bins) & isfinite(weights);
histogram = accumarray(bins(valid),weights(valid), ...
    [numel(edges)-1,1],@sum,0);
end

function [thetaX,thetaY,valid] = trace_chunk_local( ...
        normalX,normalY,normalZ,config,options,stream,firstIndex,count)
[rayX,rayY] = ray_positions_local(options,stream,firstIndex,count, ...
    config.geometry.Lx,config.geometry.Ly);
[sampleX,sampleY,sampleZ] = bilinear_normals_local( ...
    normalX,normalY,normalZ,rayX,rayY, ...
    config.geometry.Lx,config.geometry.Ly);
rayCount = numel(sampleX);
incident = zeros(rayCount,3);
incident(:,3) = -1;
inside = refract_vectors_snell(incident,[sampleX,sampleY,sampleZ], ...
    config.optical.nAir,config.optical.nSubstrate);
validFirst = all(isfinite(inside),2);
output = nan(rayCount,3);
if any(validFirst)
    flatNormal = zeros(nnz(validFirst),3);
    flatNormal(:,3) = -1;
    output(validFirst,:) = refract_vectors_snell(inside(validFirst,:), ...
        flatNormal,config.optical.nSubstrate,config.optical.nAir);
end
valid = all(isfinite(output),2);
thetaX = nan(rayCount,1);
thetaY = nan(rayCount,1);
thetaX(valid) = atan2d(output(valid,1),-output(valid,3));
thetaY(valid) = atan2d(output(valid,2),-output(valid,3));
end

function stream = create_stream_local(options)
if strcmp(options.raySamplingMode,'random')
    stream = RandStream('mt19937ar','Seed',options.rayRandomSeed);
else
    stream = [];
end
end

function [rayX,rayY] = ray_positions_local(options,stream,firstIndex,count,Lx,Ly)
switch options.raySamplingMode
    case 'random'
        uv = rand(stream,2*count,1);
        rayX = Lx*uv(1:2:end);
        rayY = Ly*uv(2:2:end);
    case 'r2'
        index = (firstIndex:(firstIndex+count-1)).';
        plasticConstant = 1.32471795724474602596;
        rayX = Lx*mod(0.5+index/plasticConstant,1);
        rayY = Ly*mod(0.5+index/(plasticConstant^2),1);
    otherwise
        error('Unknown Snell ray sampling mode: %s.',options.raySamplingMode);
end
end

function [sampleX,sampleY,sampleZ] = bilinear_normals_local( ...
        normalX,normalY,normalZ,rayX,rayY,Lx,Ly)
[resolutionY,resolutionX] = size(normalX);
coordinateX = (rayX/Lx)*(resolutionX-1);
coordinateY = (rayY/Ly)*(resolutionY-1);
indexX = min(max(floor(coordinateX)+1,1),resolutionX-1);
indexY = min(max(floor(coordinateY)+1,1),resolutionY-1);
weightX = coordinateX-floor(coordinateX);
weightY = coordinateY-floor(coordinateY);
index00 = indexY+(indexX-1)*resolutionY;
index10 = indexY+indexX*resolutionY;
index01 = indexY+1+(indexX-1)*resolutionY;
index11 = indexY+1+indexX*resolutionY;
sampleX = interpolate_local(normalX);
sampleY = interpolate_local(normalY);
sampleZ = interpolate_local(normalZ);
sampleLength = sqrt(sampleX.^2+sampleY.^2+sampleZ.^2);
sampleX = sampleX./sampleLength;
sampleY = sampleY./sampleLength;
sampleZ = sampleZ./sampleLength;

    function sample = interpolate_local(field)
        sample = (1-weightX).*(1-weightY).*field(index00)+ ...
            weightX.*(1-weightY).*field(index10)+ ...
            (1-weightX).*weightY.*field(index01)+ ...
            weightX.*weightY.*field(index11);
    end
end

function smoothed = gaussian_smooth_1d_local(values,sigmaBins)
if sigmaBins <= 0
    smoothed = values;
    return;
end
radius = max(1,ceil(4*sigmaBins));
coordinate = (-radius:radius).';
kernel = exp(-0.5*(coordinate/sigmaBins).^2);
kernel = kernel/sum(kernel);
smoothed = conv(values,kernel,'same');
end

function smoothed = gaussian_smooth_2d_local(values,sigmaBins)
if sigmaBins <= 0
    smoothed = values;
    return;
end
radius = max(1,ceil(4*sigmaBins));
coordinate = (-radius:radius).';
kernel = exp(-0.5*(coordinate/sigmaBins).^2);
kernel = kernel/sum(kernel);
smoothed = conv2(conv2(values,kernel,'same'),kernel.','same');
end

function [leftCross,rightCross,width] = ...
        find_level_width_local(theta,profile,level)
leftCross = NaN;
rightCross = NaN;
width = NaN;
[peak,peakIndex] = max(profile);
if ~isfinite(peak) || peak <= 0
    return;
end
profile = profile/peak;
leftIndex = find(profile(1:peakIndex) <= level,1,'last');
rightRelative = find(profile(peakIndex:end) <= level,1,'first');
if isempty(leftIndex) || leftIndex >= peakIndex || isempty(rightRelative)
    return;
end
rightIndex = peakIndex+rightRelative-1;
if rightIndex <= peakIndex
    return;
end
leftCross = interpolate_level_local(theta(leftIndex),profile(leftIndex), ...
    theta(leftIndex+1),profile(leftIndex+1),level);
rightCross = interpolate_level_local(theta(rightIndex-1), ...
    profile(rightIndex-1),theta(rightIndex),profile(rightIndex),level);
width = rightCross-leftCross;
end

function crossing = interpolate_level_local(x1,y1,x2,y2,level)
if abs(y2-y1) < eps
    crossing = 0.5*(x1+x2);
else
    crossing = x1+(level-y1)*(x2-x1)/(y2-y1);
end
end

function direction = canonicalize_direction_local(direction)
direction = direction/norm(direction);
if direction(1) < 0 || (abs(direction(1)) <= 10*eps && direction(2) < 0)
    direction = -direction;
end
end

function [targetMaximum,targetMinimum,toleranceMaximum,toleranceMinimum] = ...
        target_values_local(config)
if config.dualTarget.xFwhmDegree >= config.dualTarget.yFwhmDegree
    targetMaximum = config.dualTarget.xFwhmDegree;
    targetMinimum = config.dualTarget.yFwhmDegree;
    toleranceMaximum = config.dualTarget.xToleranceDegree;
    toleranceMinimum = config.dualTarget.yToleranceDegree;
else
    targetMaximum = config.dualTarget.yFwhmDegree;
    targetMinimum = config.dualTarget.xFwhmDegree;
    toleranceMaximum = config.dualTarget.yToleranceDegree;
    toleranceMinimum = config.dualTarget.xToleranceDegree;
end
end

function record = history_from_evaluation_local( ...
        evaluation,values,phase,iteration,fromCache)
record = empty_history_local();
record.iteration = iteration;
record.phase = phase;
record.kb = values(1);
record.kaScale = values(2);
record.rotationUpperDegree = values(3);
record.status = evaluation.status;
record.fromCache = fromCache;
record.errorMessage = evaluation.errorMessage;
record.elapsedSecond = evaluation.elapsedSecond;
if strcmp(evaluation.status,'valid')
    record.fwhmMaximumDegree = evaluation.fwhmMaximumDirectionDegree;
    record.fwhmMinimumDegree = evaluation.fwhmMinimumDirectionDegree;
    record.maximumDirectionAzimuthDegree = ...
        evaluation.maximumDirectionAzimuthDegree;
    record.minimumDirectionAzimuthDegree = ...
        evaluation.minimumDirectionAzimuthDegree;
    record.errorMaximumDegree = evaluation.signedErrorMaximumDegree;
    record.errorMinimumDegree = evaluation.signedErrorMinimumDegree;
    record.objectiveScore = evaluation.objectiveScore;
    record.withinBothTolerances = evaluation.withinBothTolerances;
    record.validRayCount = evaluation.validSnellRayCount;
end
end

function record = empty_history_local()
record = struct('iteration',0,'phase','','kb',NaN,'kaScale',NaN, ...
    'rotationUpperDegree',NaN,'status','invalid','fwhmMaximumDegree',NaN, ...
    'fwhmMinimumDegree',NaN,'maximumDirectionAzimuthDegree',NaN, ...
    'minimumDirectionAzimuthDegree',NaN,'errorMaximumDegree',NaN, ...
    'errorMinimumDegree',NaN,'objectiveScore',Inf, ...
    'withinBothTolerances',false,'validRayCount',0,'elapsedSecond',NaN, ...
    'fromCache',false,'errorMessage','');
end

function evaluation = invalid_evaluation_local(config,message)
evaluation.status = 'invalid';
evaluation.config = config;
evaluation.fwhmMaximumDirectionDegree = NaN;
evaluation.fwhmMinimumDirectionDegree = NaN;
evaluation.maximumDirectionAzimuthDegree = NaN;
evaluation.minimumDirectionAzimuthDegree = NaN;
evaluation.signedErrorMaximumDegree = NaN;
evaluation.signedErrorMinimumDegree = NaN;
evaluation.objectiveScore = Inf;
evaluation.withinBothTolerances = false;
evaluation.validSnellRayCount = 0;
evaluation.elapsedSecond = 0;
evaluation.errorMessage = message;
end

function validate_control_local(control)
positiveIntegerFields = {'snellSearchRayCount','snellFinalRayCount', ...
    'snellRayChunkSize','snellMaximumEvaluations','snellMaximumIterations', ...
    'snellNoImprovementPatience'};
for index = 1:numel(positiveIntegerFields)
    value = control.(positiveIntegerFields{index});
    assert(isnumeric(value) && isscalar(value) && isfinite(value) && ...
        value >= 1 && value == floor(value), ...
        '%s must be a positive integer.',positiveIntegerFields{index});
end
assert(any(strcmp(control.snellRaySamplingMode,{'random','r2'})), ...
    'snellRaySamplingMode must be random or r2.');
assert(islogical(control.snellEnableJointKbKa) && ...
    isscalar(control.snellEnableJointKbKa), ...
    'snellEnableJointKbKa must be a logical scalar.');
assert(isnumeric(control.snellStepReductionFactor) && ...
    isscalar(control.snellStepReductionFactor) && ...
    isfinite(control.snellStepReductionFactor) && ...
    control.snellStepReductionFactor > 0 && ...
    control.snellStepReductionFactor < 1, ...
    'snellStepReductionFactor must be between 0 and 1.');
assert(isnumeric(control.snellRayRandomSeed) && ...
    isscalar(control.snellRayRandomSeed) && ...
    isfinite(control.snellRayRandomSeed) && ...
    control.snellRayRandomSeed >= 0 && ...
    control.snellRayRandomSeed == floor(control.snellRayRandomSeed), ...
    'snellRayRandomSeed must be a nonnegative integer.');
nonnegativeFields = {'snellKbHalfRange','snellKaScaleHalfRange', ...
    'snellRotationHalfRangeDegree','snellMinimumObjectiveImprovement', ...
    'snellProfileSmoothingSigmaBins','snellAngularSmoothingSigmaBins'};
for index = 1:numel(nonnegativeFields)
    value = control.(nonnegativeFields{index});
    assert(isnumeric(value) && isscalar(value) && isfinite(value) && value >= 0, ...
        '%s must be a nonnegative finite scalar.',nonnegativeFields{index});
end
positiveFields = {'snellKbCoarseStep','snellKaScaleCoarseStep', ...
    'snellRotationCoarseStepDegree','snellKbFineStep', ...
    'snellKaScaleFineStep','snellRotationFineStepDegree', ...
    'snellPerpendicularBandwidthDegree'};
for index = 1:numel(positiveFields)
    value = control.(positiveFields{index});
    assert(isnumeric(value) && isscalar(value) && isfinite(value) && value > 0, ...
        '%s must be a positive finite scalar.',positiveFields{index});
end
assert(control.snellKbFineStep <= control.snellKbCoarseStep && ...
    control.snellKaScaleFineStep <= control.snellKaScaleCoarseStep && ...
    control.snellRotationFineStepDegree <= ...
    control.snellRotationCoarseStepDegree,'Snell fine step cannot exceed coarse step.');
end

function plot_snell_results_local(evaluation,history,outputDirectory)
theta = evaluation.angularDistribution.thetaDegree;
angular = evaluation.angularDistribution.normalized;
directional = evaluation.directionalMetrics;
figureHandle = figure('Color','w','Name','Snell final angular distribution');
imagesc(theta,theta,angular.'); axis image; set(gca,'YDir','normal');
xlabel('\theta_x (deg)'); ylabel('\theta_y (deg)'); colorbar; colormap turbo;
title(sprintf('Snell: max %.3f° @ %.1f°, min %.3f° @ %.1f°', ...
    evaluation.fwhmMaximumDirectionDegree, ...
    evaluation.maximumDirectionAzimuthDegree, ...
    evaluation.fwhmMinimumDirectionDegree, ...
    evaluation.minimumDirectionAzimuthDegree));
exportgraphics(figureHandle,fullfile(outputDirectory, ...
    'snell_final_angular_distribution.png'),'Resolution',200);

figureHandle = figure('Color','w','Name','Snell directional FWHM');
plot(theta,directional.maximumDirectionProfileNormalized,'LineWidth',1.8); hold on;
plot(theta,directional.minimumDirectionProfileNormalized,'--','LineWidth',1.8);
yline(0.5,':','Half maximum'); grid on; ylim([0,1.05]);
xlabel('Angle offset (deg)'); ylabel('Estimated ray density (normalized)');
legend(sprintf('Max %.4f°, target %.4f°', ...
    evaluation.fwhmMaximumDirectionDegree,evaluation.targetMaximumDegree), ...
    sprintf('Min %.4f°, target %.4f°', ...
    evaluation.fwhmMinimumDirectionDegree,evaluation.targetMinimumDegree), ...
    'Half maximum','Location','best');
title('Snell ray-tracing principal-direction density profiles');
exportgraphics(figureHandle,fullfile(outputDirectory, ...
    'snell_final_fwhm_profiles.png'),'Resolution',200);

if ~isempty(history)
    valid = strcmp(history.status,'valid');
    if any(valid)
        index = find(valid);
        figureHandle = figure('Color','w','Name','Snell local refinement history');
        tiledlayout(2,1,'TileSpacing','compact');
        nexttile;
        plot(index,history.fwhmMaximumDegree(valid),'o-','LineWidth',1.2); hold on;
        plot(index,history.fwhmMinimumDegree(valid),'s-','LineWidth',1.2);
        yline(evaluation.targetMaximumDegree,'--','Maximum target');
        yline(evaluation.targetMinimumDegree,':','Minimum target');
        grid on; ylabel('FWHM (deg)'); legend('Maximum','Minimum');
        nexttile;
        semilogy(index,max(history.objectiveScore(valid),eps),'o-','LineWidth',1.2);
        yline(1,'--','Tolerance boundary'); grid on;
        xlabel('Valid evaluation index'); ylabel('Maximum normalized error');
        exportgraphics(figureHandle,fullfile(outputDirectory, ...
            'snell_refinement_history.png'),'Resolution',200);
    end
end
end

function write_json_local(pathName,structure)
try
    text = jsonencode(structure,'PrettyPrint',true);
catch
    text = jsonencode(structure);
end
fileId = fopen(pathName,'w','n','UTF-8');
assert(fileId >= 0,'Unable to create JSON file: %s',pathName);
cleanup = onCleanup(@() fclose(fileId));
fwrite(fileId,text,'char');
end

function output = ternary_local(condition,trueText,falseText)
if condition
    output = trueText;
else
    output = falseText;
end
end
