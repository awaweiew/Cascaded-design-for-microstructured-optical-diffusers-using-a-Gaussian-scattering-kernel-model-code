% Simulate integrated diffuser polarization.

close all; clc; clear;

Lx = 0.5;
Ly = 0.5;
resx = 2000; resy = 2000;
N = 60;

h_min = 0.018;
h_max = 0.03;
alpha_h = 1.22;
beta_h  = 4.48;

ka_min  = 0.6;
ka_max  = 0.85 ;
alpha_ka = 1.62;
beta_ka = 2.05;

kb = 0.6;

pos_jitter_frac = 0.4;
rot_jitter = pi;
is_convex = false;
show_mesh = false;
smooth_k = 2500;
smooth_sigma = 0.8; %#ok<NASGU>
rng(1);

n_air = 1.0;
n_sub = 1.5;
lambda = 0.55e-3;

T_sub = 1.0;
z_back = -T_sub;

input_pol = '45';
Ein_custom = [1; 1i; 0] / sqrt(2);

ray_stride = 4;

enforce_lateral_aperture = false;

theta_limit_deg = 80;
Ntheta = 321;

enable_observation_plane = true;
z_air_obs = 10.0;
Nobs = 301;
obs_half_width = 8.0;

basis_tol = 1e-12;
intensity_tol = 1e-14;

x = linspace(0, Lx, resx);
y = linspace(0, Ly, resy);
[X, Y] = meshgrid(x, y);
Z_final = zeros(size(X));
px = Lx / N; py = Ly / N;
cx_base = linspace(px/2, Lx - px/2, N);
cy_base = linspace(py/2, Ly - py/2, N);
jx_max = (px/2) * pos_jitter_frac;
jy_max = (py/2) * pos_jitter_frac;

M = N*N;
h_all = zeros(1,M);
ka_all = zeros(1,M);
a_all = zeros(1,M);
b_all = zeros(1,M);
theta_all = zeros(1,M);
cx_all = zeros(1,M);
cy_all = zeros(1,M);
count = 1;

fprintf('Generating diffuser: %d x %d grid, %d ellipsoidal units...\n', resx, resy, M);
for i = 1:N
    for j = 1:N
        cx0 = cx_base(i);
        cy0 = cy_base(j);
        dx_jit = (2*rand()-1) * jx_max;
        dy_jit = (2*rand()-1) * jy_max;
        cx = min(max(cx0 + dx_jit, px/2), Lx - px/2);
        cy = min(max(cy0 + dy_jit, py/2), Ly - py/2);

        u = betarnd(alpha_h, beta_h);
        h = h_min + (h_max - h_min) * u;
        h_all(count) = h;

        u_ka = betarnd(alpha_ka, beta_ka);
        ka_current = ka_min + (ka_max - ka_min) * u_ka;
        ka_all(count) = ka_current;

        a = ka_current * h;
        b = kb * a;

        theta = rand() * rot_jitter;

        a_all(count) = a;
        b_all(count) = b;
        theta_all(count) = theta;
        cx_all(count) = cx;
        cy_all(count) = cy;

        Z_sub = ellipsoid_cap(X, Y, cx, cy, a, b, h, theta);

        if is_convex
            Z_final = (1/smooth_k) * log(exp(smooth_k * Z_final) + exp(smooth_k * Z_sub));
        else
            Z_final = -(1/smooth_k) * log(exp(-smooth_k * Z_final) + exp(-smooth_k * (-Z_sub)));
        end
        count = count + 1;
    end
end


if z_back >= min(Z_final(:))
    error(['Back plane z_back=%.6f mm must lie below all rough-surface points.', ...
           'Current min(Z_final)=%.6f mm. Increase T_sub.'], z_back, min(Z_final(:)));
end

fprintf('Diffuser generation complete: Z range [%.4f, %.4f] mm\n', min(Z_final(:)), max(Z_final(:)));
fprintf('ka sample mean %.4f (target %.4f), h sample mean %.4f mm\n', ...
    mean(ka_all), mean(h_all));
save('surface_23deg.mat','Z_final','-v7.3');
fprintf('Surface matrix saved: surface_23deg.mat\n');

dx = x(2) - x(1);
dy = y(2) - y(1);
[dZdx, dZdy] = gradient(Z_final, dx, dy);

Nmag = sqrt(1 + dZdx.^2 + dZdy.^2);
nrx = dZdx ./ Nmag;
nry = dZdy ./ Nmag;
nrz = -1 ./ Nmag;

ixr = 1:ray_stride:resx;
iyr = 1:ray_stride:resy;
Xr = X(iyr, ixr);
Yr = Y(iyr, ixr);
Zr = Z_final(iyr, ixr);
Nrx = nrx(iyr, ixr);
Nry = nry(iyr, ixr);
Nrz = nrz(iyr, ixr);
Sxr = dZdx(iyr, ixr);
Syr = dZdy(iyr, ixr);

Nr_y = numel(iyr);
Nr_x = numel(ixr);
Nrays = numel(Xr);
fprintf('Polarization tracing samples: %d x %d = %d rays (ray_stride=%d)\n', ...
    Nr_x, Nr_y, Nrays, ray_stride);

R0 = [Xr(:), Yr(:), Zr(:)];
N1 = [Nrx(:), Nry(:), Nrz(:)];
N1 = normalize_rows(N1);
K0 = repmat([0, 0, -1], Nrays, 1);

switch lower(input_pol)
    case 'x'
        E0_single = [1; 0; 0];
    case 'y'
        E0_single = [0; 1; 0];
    case '45'
        E0_single = [1; 1; 0] / sqrt(2);
    case 'circularr'
        E0_single = [1; -1i; 0] / sqrt(2);
    case 'custom'
        E0_single = Ein_custom(:);
        E0_single = E0_single - [0;0;-1] * ([0;0;-1]' * E0_single);
        E0_single = E0_single / norm(E0_single);
    otherwise
        error('Unknown input_pol: %s', input_pol);
end
E0 = repmat(E0_single.', Nrays, 1);

cos_i1 = sum(K0 .* N1, 2);
cos_i1 = min(max(cos_i1, 0), 1);
theta_i1 = acos(cos_i1);

theta_slope = atan(sqrt(Sxr(:).^2 + Syr(:).^2));
max_theta_err = max(abs(theta_i1 - theta_slope));

eta1 = n_air / n_sub;
sin_t1_sq = eta1^2 .* max(0, 1 - cos_i1.^2);
cos_t1 = sqrt(max(0, 1 - sin_t1_sq));
K1 = eta1 .* K0 + (cos_t1 - eta1 .* cos_i1) .* N1;
K1 = normalize_rows(K1);

[S1basis, P1i] = local_sp_basis(N1, K0, basis_tol);
P1t = normalize_rows(cross(S1basis, K1, 2));

[ts1, tp1, tau_s1, tau_p1, Ts1, Tp1] = fresnel_transmission(...
    n_air, n_sub, cos_i1, cos_t1);
D1 = (Ts1 - Tp1) ./ (Ts1 + Tp1 + eps);

Es1 = sum(E0 .* S1basis, 2);
Ep1 = sum(E0 .* P1i, 2);
E1 = (tau_s1 .* Es1) .* S1basis + (tau_p1 .* Ep1) .* P1t;

Delta1 = angle(ts1) - angle(tp1);

transverse_err1 = max(abs(sum(E1 .* K1, 2)) ./ (sqrt(sum(abs(E1).^2,2)) + eps));

valid_down = K1(:,3) < -basis_tol;
t_to_back = nan(Nrays,1);
t_to_back(valid_down) = (z_back - R0(valid_down,3)) ./ K1(valid_down,3);
valid_back_intersection = valid_down & (t_to_back > 0);

Rback = nan(Nrays,3);
Rback(valid_back_intersection,:) = R0(valid_back_intersection,:) + ...
    t_to_back(valid_back_intersection) .* K1(valid_back_intersection,:);

if enforce_lateral_aperture
    valid_lateral = valid_back_intersection & ...
        Rback(:,1) >= 0 & Rback(:,1) <= Lx & ...
        Rback(:,2) >= 0 & Rback(:,2) <= Ly;
else
    valid_lateral = valid_back_intersection;
end

Nback = repmat([0, 0, -1], Nrays, 1);
cos_i2 = sum(K1 .* Nback, 2);
cos_i2 = min(max(cos_i2, 0), 1);
theta_i2 = acos(cos_i2);

eta2 = n_sub / n_air;
sin_t2_sq = eta2^2 .* max(0, 1 - cos_i2.^2);
mask_tir2 = valid_lateral & (sin_t2_sq >= 1);
mask_direct = valid_lateral & ~mask_tir2;

cos_t2 = nan(Nrays,1);
cos_t2(mask_direct) = sqrt(max(0, 1 - sin_t2_sq(mask_direct)));

K2 = nan(Nrays,3);
K2(mask_direct,:) = eta2 .* K1(mask_direct,:) + ...
    (cos_t2(mask_direct) - eta2 .* cos_i2(mask_direct)) .* Nback(mask_direct,:);
K2(mask_direct,:) = normalize_rows(K2(mask_direct,:));

[S2basis, P2i] = local_sp_basis(Nback, K1, basis_tol);
P2t = nan(Nrays,3);
P2t(mask_direct,:) = normalize_rows(cross(S2basis(mask_direct,:), K2(mask_direct,:), 2));

Ts2 = zeros(Nrays,1); Tp2 = zeros(Nrays,1);
ts2 = zeros(Nrays,1); tp2 = zeros(Nrays,1);
tau_s2 = zeros(Nrays,1); tau_p2 = zeros(Nrays,1);
if any(mask_direct)
    [ts2(mask_direct), tp2(mask_direct), tau_s2(mask_direct), tau_p2(mask_direct), ...
        Ts2(mask_direct), Tp2(mask_direct)] = fresnel_transmission(...
        n_sub, n_air, cos_i2(mask_direct), cos_t2(mask_direct));
end
D2 = nan(Nrays,1);
D2(mask_direct) = (Ts2(mask_direct) - Tp2(mask_direct)) ./ ...
                  (Ts2(mask_direct) + Tp2(mask_direct) + eps);

Es2 = sum(E1 .* S2basis, 2);
Ep2 = sum(E1 .* P2i, 2);
E2 = nan(Nrays,3);
E2(mask_direct,:) = ...
    (tau_s2(mask_direct) .* Es2(mask_direct)) .* S2basis(mask_direct,:) + ...
    (tau_p2(mask_direct) .* Ep2(mask_direct)) .* P2t(mask_direct,:);

Delta2 = nan(Nrays,1);
Delta2(mask_direct) = angle(ts2(mask_direct)) - angle(tp2(mask_direct));

rs_tir = nan(Nrays,1);
rp_tir = nan(Nrays,1);
Delta_tir = nan(Nrays,1);
if any(mask_tir2)
    sin_t2 = sqrt(sin_t2_sq(mask_tir2));
    cos_t2_complex = 1i * sqrt(max(0, sin_t2.^2 - 1));
    ci = cos_i2(mask_tir2);
    rs = (n_sub.*ci - n_air.*cos_t2_complex) ./ ...
         (n_sub.*ci + n_air.*cos_t2_complex);
    rp = (n_air.*ci - n_sub.*cos_t2_complex) ./ ...
         (n_air.*ci + n_sub.*cos_t2_complex);
    rs_tir(mask_tir2) = rs;
    rp_tir(mask_tir2) = rp;
    Delta_tir(mask_tir2) = angle(rs) - angle(rp);
end

transverse_err2 = max(abs(sum(E2(mask_direct,:) .* K2(mask_direct,:), 2)) ./ ...
    (sqrt(sum(abs(E2(mask_direct,:)).^2,2)) + eps));

K2d = K2(mask_direct,:);
E2d = E2(mask_direct,:);
Nd = size(K2d,1);

ex_lab = repmat([1,0,0], Nd, 1);
projx = sum(ex_lab .* K2d, 2);
eH = ex_lab - projx .* K2d;
eHn = sqrt(sum(eH.^2,2));

badH = eHn < basis_tol;
if any(badH)
    ey_lab = repmat([0,1,0], sum(badH), 1);
    Kbad = K2d(badH,:);
    projy = sum(ey_lab .* Kbad, 2);
    eH(badH,:) = ey_lab - projy .* Kbad;
end
eH = normalize_rows(eH);
eV = normalize_rows(cross(eH, K2d, 2));

EH = sum(E2d .* eH, 2);
EV = sum(E2d .* eV, 2);

S0_ray = abs(EH).^2 + abs(EV).^2;
S1_ray = abs(EH).^2 - abs(EV).^2;
S2_ray = 2*real(conj(EH).*EV);
S3_ray = 2*imag(conj(EH).*EV);

psi_ray = 0.5 * atan2(S2_ray, S1_ray);
arg_chi = S3_ray ./ (S0_ray + eps);
arg_chi = min(max(arg_chi,-1),1);
chi_ray = 0.5 * asin(arg_chi);

DoP_ray = sqrt(S1_ray.^2 + S2_ray.^2 + S3_ray.^2) ./ (S0_ray + eps);

thx_ray = atan2d(K2d(:,1), -K2d(:,3));
thy_ray = atan2d(K2d(:,2), -K2d(:,3));

small_slope_mask_all = theta_i1 < deg2rad(5) & mask_direct;
if any(small_slope_mask_all)
    kxy_exact = K2(small_slope_mask_all,1:2) ./ (-K2(small_slope_mask_all,3));
    sxy_small = [Sxr(:),Syr(:)];
    sxy_small = sxy_small(small_slope_mask_all,:);
    kxy_linear = (n_sub-n_air)/n_air .* sxy_small;
    slope_angle_linear_rms = sqrt(mean(sum((kxy_exact-kxy_linear).^2,2)));
else
    slope_angle_linear_rms = NaN;
end

theta_edges = linspace(-theta_limit_deg, theta_limit_deg, Ntheta+1);
theta_centers = 0.5*(theta_edges(1:end-1) + theta_edges(2:end));

[S0_ang,S1_ang,S2_ang,S3_ang,raycount_ang] = bin_stokes_2d(...
    thx_ray, thy_ray, S0_ray, S1_ray, S2_ray, S3_ray, theta_edges, theta_edges);

DoP_ang = sqrt(S1_ang.^2 + S2_ang.^2 + S3_ang.^2) ./ (S0_ang + eps);
DoLP_ang = sqrt(S1_ang.^2 + S2_ang.^2) ./ (S0_ang + eps);
psi_ang = 0.5 * atan2(S2_ang, S1_ang);
arg_chi_ang = S3_ang ./ (S0_ang + eps);
arg_chi_ang = min(max(arg_chi_ang,-1),1);
chi_ang = 0.5 * asin(arg_chi_ang);

empty_ang = S0_ang <= intensity_tol * max(S0_ang(:));
DoP_ang(empty_ang) = NaN;
DoLP_ang(empty_ang) = NaN;
psi_ang(empty_ang) = NaN;
chi_ang(empty_ang) = NaN;

S0_total = sum(S0_ray);
S1_total = sum(S1_ray);
S2_total = sum(S2_ray);
S3_total = sum(S3_ray);
DoP_total = sqrt(S1_total^2 + S2_total^2 + S3_total^2) / (S0_total + eps);
DoLP_total = sqrt(S1_total^2 + S2_total^2) / (S0_total + eps);
psi_total = 0.5 * atan2(S2_total,S1_total);
chi_total = 0.5 * asin(max(-1,min(1,S3_total/(S0_total+eps))));

if enable_observation_plane
    Rback_d = Rback(mask_direct,:);
    z_obs = z_back - z_air_obs;
    t_obs = (z_obs - z_back) ./ K2d(:,3);
    Robs = Rback_d + t_obs .* K2d;

    obs_edges = linspace(-obs_half_width, obs_half_width, Nobs+1);
    obs_centers = 0.5*(obs_edges(1:end-1)+obs_edges(2:end));
    [S0_obs,S1_obs,S2_obs,S3_obs,raycount_obs] = bin_stokes_2d(...
        Robs(:,1)-Lx/2, Robs(:,2)-Ly/2, S0_ray,S1_ray,S2_ray,S3_ray, ...
        obs_edges, obs_edges);

    DoP_obs = sqrt(S1_obs.^2 + S2_obs.^2 + S3_obs.^2) ./ (S0_obs + eps);
    DoLP_obs = sqrt(S1_obs.^2 + S2_obs.^2) ./ (S0_obs + eps);
    psi_obs = 0.5 * atan2(S2_obs,S1_obs);
    arg_chi_obs = S3_obs ./ (S0_obs + eps);
    arg_chi_obs = min(max(arg_chi_obs,-1),1);
    chi_obs = 0.5 * asin(arg_chi_obs);

    empty_obs = S0_obs <= intensity_tol * max(S0_obs(:));
    DoP_obs(empty_obs)=NaN; DoLP_obs(empty_obs)=NaN;
    psi_obs(empty_obs)=NaN; chi_obs(empty_obs)=NaN;
else
    obs_centers=[]; S0_obs=[]; DoP_obs=[]; DoLP_obs=[]; psi_obs=[]; chi_obs=[]; %#ok<NASGU>
    raycount_obs=[]; %#ok<NASGU>
end

analyzer_deg = linspace(0,180,361);
I_analyzer = 0.5 * (S0_total + S1_total*cosd(2*analyzer_deg) + ...
                   S2_total*sind(2*analyzer_deg));
Imax_an = max(I_analyzer);
Imin_an = min(I_analyzer);
DoLP_from_analyzer = (Imax_an-Imin_an)/(Imax_an+Imin_an+eps);

th_c = asind(n_air/n_sub);
fprintf('\n================ Polarization tracing results ================\n');
fprintf('First interface: air -> rough glass; second interface: glass -> planar air\n');
fprintf('Slope-angle consistency max|theta_i1-atan(|gradZ|)| = %.3e deg\n', rad2deg(max_theta_err));
fprintf('First-interface maximum relative E dot k transverse error = %.3e\n', transverse_err1);
fprintf('Final-output maximum relative E dot k transverse error = %.3e\n', transverse_err2);
if isfinite(slope_angle_linear_rms)
    fprintf('Small-slope directional RMS error between exact Snell and Ktheta linear mapping = %.3e\n', slope_angle_linear_rms);
end
fprintf('Rough-surface local incidence angle: mean %.3f deg, max %.3f deg\n', ...
    rad2deg(mean(theta_i1)), rad2deg(max(theta_i1)));
fprintf('Back-surface glass-side incidence angle: mean %.3f deg, max %.3f deg, critical angle %.3f deg\n', ...
    rad2deg(mean(theta_i2(valid_lateral))), rad2deg(max(theta_i2(valid_lateral))), th_c);
fprintf('Back-surface TIR ray fraction of valid incident rays = %.3f %%\n', ...
    100*sum(mask_tir2)/max(1,sum(valid_lateral)));
fprintf('Direct-transmission ray fraction = %.3f %% (relative to valid back-surface incidence)\n', ...
    100*sum(mask_direct)/max(1,sum(valid_lateral)));
valid_dop_ray = S0_ray>intensity_tol;
if any(valid_dop_ray)
    fprintf('Direct-transmission single-ray DoP: mean %.8f, min %.8f\n', ...
        mean(DoP_ray(valid_dop_ray)), min(DoP_ray(valid_dop_ray)));
else
    fprintf('Warning: no nonzero direct-transmission rays are available for DoP statistics.\n');
end
fprintf('Full angular-domain unresolved reception: DoLP = %.6f, DoP = %.6f\n', DoLP_total, DoP_total);
fprintf('Full angular-domain equivalent psi = %.3f deg, chi = %.3f deg\n', ...
    rad2deg(psi_total), rad2deg(chi_total));
fprintf('Rotating linear-polarizer modulation = %.6f (equal to DoLP)\n', DoLP_from_analyzer);
fprintf('First-interface max|Delta_trans| = %.3e deg\n', ...
    rad2deg(max(abs(Delta1))));
if any(mask_direct)
    fprintf('Second-interface direct-transmission max|Delta_trans| = %.3e deg\n', ...
        rad2deg(max(abs(Delta2(mask_direct)))));
end
if any(mask_tir2)
    fprintf('TIR reflection phase difference Delta_rs-rp: mean %.3f deg, range [%.3f, %.3f] deg\n', ...
        rad2deg(mean(Delta_tir(mask_tir2))), ...
        rad2deg(min(Delta_tir(mask_tir2))), rad2deg(max(Delta_tir(mask_tir2))));
end
fprintf('==============================================\n');

figure('Name','Diffuser surface','Color','w');
if show_mesh
    surf(1e3*X,1e3*Y,1e3*Z_final,1e3*Z_final,'EdgeColor','k');
else
    surf(1e3*X,1e3*Y,1e3*Z_final,1e3*Z_final,'EdgeColor','none');
end
axis equal; shading interp; colormap turbo; colorbar;
xlabel('x (\mum)'); ylabel('y (\mum)'); zlabel('z (\mum)');
title('Similar ellipsoidal-cap diffuser surface'); view(45,45); light; lighting gouraud;

figure('Name','Local ray/Fresnel diagnostics','Color','w');
tiledlayout(2,3,'Padding','compact','TileSpacing','compact');
nexttile;
imagesc(x(ixr)*1e3,y(iyr)*1e3,rad2deg(reshape(theta_i1,Nr_y,Nr_x))); axis image; colorbar;
title('\theta_{i,rough} (deg)'); xlabel('x (\mum)'); ylabel('y (\mum)');
nexttile;
imagesc(x(ixr)*1e3,y(iyr)*1e3,reshape(D1,Nr_y,Nr_x)); axis image; colorbar;
title('D_1: rough air\rightarrowglass');
nexttile;
imagesc(x(ixr)*1e3,y(iyr)*1e3,rad2deg(reshape(theta_i2,Nr_y,Nr_x))); axis image; colorbar;
title('\theta_{i,back} (deg)');
nexttile;
D2map=reshape(D2,Nr_y,Nr_x);
imagesc(x(ixr)*1e3,y(iyr)*1e3,D2map); axis image; colorbar;
title('D_2: back glass\rightarrowair');
nexttile;
imagesc(x(ixr)*1e3,y(iyr)*1e3,reshape(mask_tir2,Nr_y,Nr_x)); axis image; colorbar;
title('Back-surface TIR mask');
nexttile;
psi_map=nan(Nrays,1); psi_map(mask_direct)=rad2deg(psi_ray);
imagesc(x(ixr)*1e3,y(iyr)*1e3,reshape(psi_map,Nr_y,Nr_x)); axis image; colorbar;
title('Direct-transmission ray \psi (deg)');

figure('Name','Angle-resolved polarization','Color','w');
tiledlayout(2,3,'Padding','compact','TileSpacing','compact');
nexttile;
imagesc(theta_centers,theta_centers,log10(S0_ang+eps)); axis image; colorbar;
xlabel('\theta_x (deg)'); ylabel('\theta_y (deg)'); title('log_{10} S_0');
nexttile;
imagesc(theta_centers,theta_centers,rad2deg(psi_ang)); axis image; colorbar;
title('\psi(\theta_x,\theta_y) (deg)');
nexttile;
imagesc(theta_centers,theta_centers,rad2deg(chi_ang)); axis image; colorbar;
title('\chi(\theta_x,\theta_y) (deg)');
nexttile;
imagesc(theta_centers,theta_centers,DoLP_ang); axis image; colorbar; caxis([0 1]);
title('DoLP');
nexttile;
imagesc(theta_centers,theta_centers,DoP_ang); axis image; colorbar; caxis([0 1]);
title('DoP');
nexttile;
imagesc(theta_centers,theta_centers,raycount_ang); axis image; colorbar;
title('ray count / angular bin');

if enable_observation_plane
    figure('Name','Observation-plane polarization','Color','w');
    tiledlayout(2,3,'Padding','compact','TileSpacing','compact');
    nexttile;
    imagesc(obs_centers,obs_centers,log10(S0_obs+eps)); axis image; colorbar;
    xlabel('x_{obs} (mm)'); ylabel('y_{obs} (mm)'); title('log_{10} S_0');
    nexttile;
    imagesc(obs_centers,obs_centers,rad2deg(psi_obs)); axis image; colorbar;
    title('\psi_{obs} (deg)');
    nexttile;
    imagesc(obs_centers,obs_centers,rad2deg(chi_obs)); axis image; colorbar;
    title('\chi_{obs} (deg)');
    nexttile;
    imagesc(obs_centers,obs_centers,DoLP_obs); axis image; colorbar; caxis([0 1]);
    title('DoLP_{obs}');
    nexttile;
    imagesc(obs_centers,obs_centers,DoP_obs); axis image; colorbar; caxis([0 1]);
    title('DoP_{obs}');
    nexttile;
    imagesc(obs_centers,obs_centers,raycount_obs); axis image; colorbar;
    title('ray count / spatial bin');
end

figure('Name','Analyzer and TIR phase diagnostics','Color','w');
tiledlayout(1,2,'Padding','compact','TileSpacing','compact');
nexttile;
plot(analyzer_deg,I_analyzer/max(I_analyzer),'LineWidth',1.5); grid on;
xlabel('Analyzer angle (deg)'); ylabel('Normalized intensity');
title(sprintf('Analyzer modulation / DoLP = %.4f',DoLP_from_analyzer));
nexttile;
if any(mask_tir2)
    histogram(rad2deg(Delta_tir(mask_tir2)),100,'Normalization','pdf','EdgeColor','none');
    xlabel('\Delta_{TIR}=arg(r_s)-arg(r_p) (deg)'); ylabel('PDF');
    title('s-p reflection phase difference for back-surface TIR'); grid on;
else
    axis off;
    text(0.1,0.5,'No back-surface TIR rays for the current parameters','FontSize',12);
end

results = struct();
results.params = struct('n_air',n_air,'n_sub',n_sub,'lambda',lambda, ...
    'T_sub',T_sub,'ray_stride',ray_stride,'input_pol',input_pol, ...
    'theta_limit_deg',theta_limit_deg,'Ntheta',Ntheta);
results.diffuser = struct('h_all',h_all,'ka_all',ka_all,'a_all',a_all,'b_all',b_all, ...
    'theta_all',theta_all,'cx_all',cx_all,'cy_all',cy_all);
results.theta_centers = theta_centers;
results.S0_ang = S0_ang; results.S1_ang=S1_ang; results.S2_ang=S2_ang; results.S3_ang=S3_ang;
results.DoLP_ang=DoLP_ang; results.DoP_ang=DoP_ang; results.psi_ang=psi_ang; results.chi_ang=chi_ang;
results.DoLP_total=DoLP_total; results.DoP_total=DoP_total;
results.psi_total=psi_total; results.chi_total=chi_total;
results.TIR_fraction = sum(mask_tir2)/max(1,sum(valid_lateral));
results.max_theta_consistency_error_deg = rad2deg(max_theta_err);
results.transverse_err1 = transverse_err1;
results.transverse_err2 = transverse_err2;
results.small_slope_linear_mapping_rms = slope_angle_linear_rms;

save('diffuser_polarization_results.mat','results','-v7.3');
fprintf('Results saved: diffuser_polarization_results.mat\n');

function Z = ellipsoid_cap(X, Y, cx, cy, a, b, h, theta)
    dx = X - cx;
    dy = Y - cy;
    ct = cos(theta); st = sin(theta);
    xp =  ct.*dx + st.*dy;
    yp = -st.*dx + ct.*dy;
    r2 = (xp./a).^2 + (yp./b).^2;
    inside = r2 <= 1;
    Z = zeros(size(X));
    Z(inside) = h * sqrt(max(0, 1 - r2(inside)));
end

function A = normalize_rows(A)
    n = sqrt(sum(abs(A).^2,2));
    n(n==0) = 1;
    A = A ./ n;
end

function [Sbasis, Pibasis] = local_sp_basis(N12, Ki, tol)
    Sbasis = cross(N12, Ki, 2);
    ns = sqrt(sum(Sbasis.^2,2));
    bad = ns < tol;

    if any(bad)
        Kb = Ki(bad,:);
        ref = repmat([0,1,0],sum(bad),1);
        bad_ref = abs(sum(ref.*Kb,2)) > 0.99;
        ref(bad_ref,:) = repmat([1,0,0],sum(bad_ref),1);
        Sbasis(bad,:) = ref - sum(ref.*Kb,2).*Kb;
    end
    Sbasis = normalize_rows(Sbasis);
    Pibasis = normalize_rows(cross(Sbasis, Ki, 2));
end

function [ts,tp,tau_s,tau_p,Ts,Tp] = fresnel_transmission(n1,n2,cos_i,cos_t)
    ts = 2*n1.*cos_i ./ (n1.*cos_i + n2.*cos_t);
    tp = 2*n1.*cos_i ./ (n1.*cos_t + n2.*cos_i);

    flux = (n2.*cos_t) ./ (n1.*cos_i + eps);
    Ts = abs(ts).^2 .* flux;
    Tp = abs(tp).^2 .* flux;

    g = sqrt(max(0,flux));
    tau_s = g .* ts;
    tau_p = g .* tp;
end

function [S0m,S1m,S2m,S3m,countm] = bin_stokes_2d(xv,yv,S0,S1,S2,S3,xedges,yedges)
    Nx = numel(xedges)-1;
    Ny = numel(yedges)-1;
    ix = discretize(xv,xedges);
    iy = discretize(yv,yedges);
    valid = ~isnan(ix) & ~isnan(iy) & isfinite(S0) & S0>=0;
    lin = sub2ind([Ny,Nx],iy(valid),ix(valid));

    S0v = accumarray(lin,S0(valid),[Ny*Nx,1],@sum,0);
    S1v = accumarray(lin,S1(valid),[Ny*Nx,1],@sum,0);
    S2v = accumarray(lin,S2(valid),[Ny*Nx,1],@sum,0);
    S3v = accumarray(lin,S3(valid),[Ny*Nx,1],@sum,0);
    Cv  = accumarray(lin,1,[Ny*Nx,1],@sum,0);

    S0m = reshape(S0v,[Ny,Nx]);
    S1m = reshape(S1v,[Ny,Nx]);
    S2m = reshape(S2v,[Ny,Nx]);
    S3m = reshape(S3v,[Ny,Nx]);
    countm = reshape(Cv,[Ny,Nx]);
end
