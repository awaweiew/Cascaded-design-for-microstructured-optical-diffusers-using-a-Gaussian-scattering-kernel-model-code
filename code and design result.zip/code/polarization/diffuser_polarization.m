% Simulate polarization through the diffuser.
close all; clc; clear;

if ~exist('Z_final','var')
    try
        S = load('Zfinal.mat');
        Z = S.Z_final;
        fprintf('Loaded height field Z_final\n');
    catch
        error('Height field not found: run diffuser.m to generate and save Z_final first.');
    end
else
    Z = Z_final;
end

n_air  = 1.0;
n_sub  = 1.5;
lambda = 0.55e-3;

Lx = 0.5;
[ny, nx] = size(Z);
dx = Lx / (nx - 1);
x  = linspace(0, Lx, nx);
y  = linspace(0, Lx, ny);

T_sub = 1.0;

Ein = [1; 1]/sqrt(2);

[sx, sy] = gradient(Z, dx, dx);
Nnorm = sqrt(sx.^2 + sy.^2 + 1);

nx = -sx ./ Nnorm;
ny = -sy ./ Nnorm;
nz =  1 ./ Nnorm;

ki = [0, 0, -1];

cosTi   = -(ki(1).*nx + ki(2).*ny + ki(3).*nz);
cosTi   = min(max(cosTi, 0), 1);
theta_i = acos(cosTi);
slope_mag = sqrt(sx.^2 + sy.^2);

t_front = 2*n_air/(n_air + n_sub);

th_c   = asin(n_air/n_sub);
mask_tir = theta_i >= th_c;

sinTt = (n_sub/n_air) .* sin(theta_i);
sinTt(mask_tir) = 1;
cosTt = sqrt(max(0, 1 - sinTt.^2));

ts = 2*n_sub*cosTi ./ (n_sub*cosTi + n_air*cosTt);
tp = 2*n_sub*cosTi ./ (n_sub*cosTt + n_air*cosTi);
ts(mask_tir) = 0;  tp(mask_tir) = 0;

Ts = abs(ts).^2 .* (n_air.*cosTt)./(n_sub.*cosTi);
Tp = abs(tp).^2 .* (n_air.*cosTt)./(n_sub.*cosTi);
D  = (Ts - Tp) ./ (Ts + Tp + eps);
D(mask_tir) = NaN;

Delta = angle(ts) - angle(tp);

phi = atan2(-nx, ny);
cph = cos(phi); sph = sin(phi);

Es =  cph.*Ein(1) + sph.*Ein(2);
Ep = -sph.*Ein(1) + cph.*Ein(2);

Es2 = ts .* Es;
Ep2 = tp .* Ep;

Ex = cph.*Es2 - sph.*Ep2;
Ey = sph.*Es2 + cph.*Ep2;

phase_screen = exp(-1i * (2*pi/lambda) * (n_sub - n_air) * Z);

E_near_x = t_front * Ex .* phase_screen;
E_near_y = t_front * Ey .* phase_screen;

I_near = abs(E_near_x).^2 + abs(E_near_y).^2;
psi_near = 0.5 * atan2( 2*real(conj(E_near_x).*E_near_y), ...
                        abs(E_near_x).^2 - abs(E_near_y).^2 );
tmp = 2*imag(conj(E_near_x).*E_near_y) ./ (abs(E_near_x).^2 + abs(E_near_y).^2 + eps);
tmp = min(max(tmp, -1), 1);
chi_near = 0.5 * asin(tmp);

E_pup_x = fftshift(fft2(E_near_x));
E_pup_y = fftshift(fft2(E_near_y));

fx = (-nx/2 : nx/2-1) / (nx*dx);
fy = (-ny/2 : ny/2-1) / (ny*dx);

fmax = 1/lambda;
idx_x = abs(fx) <= fmax;
idx_y = abs(fy) <= fmax;
theta_x = asind(lambda*fx(idx_x));
theta_y = asind(lambda*fy(idx_y));
E_pup_x = E_pup_x(idx_y, idx_x);
E_pup_y = E_pup_y(idx_y, idx_x);

I_pup = (abs(E_pup_x).^2 + abs(E_pup_y).^2);
psi_pup = 0.5 * atan2( 2*real(conj(E_pup_x).*E_pup_y), ...
                       abs(E_pup_x).^2 - abs(E_pup_y).^2 );
tmp = 2*imag(conj(E_pup_x).*E_pup_y) ./ (abs(E_pup_x).^2 + abs(E_pup_y).^2 + eps);
tmp = min(max(tmp, -1), 1);
chi_pup = 0.5 * asin(tmp);

S0n = abs(E_near_x).^2 + abs(E_near_y).^2;
S1n = abs(E_near_x).^2 - abs(E_near_y).^2;
S2n = 2*real(conj(E_near_x).*E_near_y);
S3n = 2*imag(conj(E_near_x).*E_near_y);

DoP_near = sqrt( sum(S1n(:))^2 + sum(S2n(:))^2 + sum(S3n(:))^2 ) / sum(S0n(:));

S0p = abs(E_pup_x).^2 + abs(E_pup_y).^2;
S1p = abs(E_pup_x).^2 - abs(E_pup_y).^2;
S2p = 2*real(conj(E_pup_x).*E_pup_y);
S3p = 2*imag(conj(E_pup_x).*E_pup_y);
DoP_pup = sqrt( sum(S1p(:))^2 + sum(S2p(:))^2 + sum(S3p(:))^2 ) / sum(S0p(:));

fprintf('\n===== Polarization tracing statistics (planar substrate -> rough output surface)=====\n');
fprintf('TIR-blocked area fraction: %.2f%% (steep-slope rays are totally internally reflected)\n', ...
    100*mean(mask_tir(:)));
fprintf('Incidence angle theta_i: mean %.2f deg, max %.2f deg, critical angle %.2f deg\n', ...
    rad2deg(mean(theta_i(:))), rad2deg(max(theta_i(:))), rad2deg(th_c));
fprintf('Near-field polarization azimuth psi: mean %.2f deg, standard deviation %.2f deg (input 45 deg)\n', ...
    rad2deg(mean(psi_near(:))), rad2deg(std(psi_near(:))));
fprintf('Near-field aperture-averaged DoP: %.4f (<1 indicates spatial depolarization)\n', DoP_near);
fprintf('Pupil aperture-averaged DoP: %.4f\n', DoP_pup);

figure('Name','Output surface: incidence angle / diattenuation / TIR','Color','w');
subplot(1,3,1);
imagesc(x*1e3, y*1e3, rad2deg(theta_i)); axis image; colorbar;
title('Incidence angle \theta_i (deg)');
subplot(1,3,2);
imagesc(x*1e3, y*1e3, D); axis image; colorbar;
title('Diattenuation D');
subplot(1,3,3);
imagesc(x*1e3, y*1e3, mask_tir); axis image; colorbar;
title('Total-internal-reflection region (no transmission)');

figure('Name','Near field: intensity / polarization azimuth / ellipticity','Color','w');
subplot(1,3,1);
imagesc(x*1e3, y*1e3, I_near); axis image; colorbar;
title('Near-field intensity |E|^2 (TIR regions are dark)');
subplot(1,3,2);
imagesc(x*1e3, y*1e3, rad2deg(psi_near)); axis image; colorbar;
title('Near-field polarization azimuth \psi (deg)');
subplot(1,3,3);
imagesc(x*1e3, y*1e3, rad2deg(chi_near)); axis image; colorbar;
title('Near-field ellipticity angle \chi (deg)');

figure('Name','Pupil plane: angular-spectrum intensity / polarization azimuth / ellipticity','Color','w');
subplot(1,3,1);
imagesc(theta_x, theta_y, log10(I_pup+eps)); axis image; colorbar;
xlim([-70 70]); ylim([-70 70]);
title('Pupil angular-spectrum intensity (log)'); xlabel('\theta_x (deg)'); ylabel('\theta_y (deg)');
subplot(1,3,2);
imagesc(theta_x, theta_y, rad2deg(psi_pup)); axis image; colorbar;
xlim([-70 70]); ylim([-70 70]);
title('Pupil polarization azimuth \psi (deg)');
subplot(1,3,3);
imagesc(theta_x, theta_y, rad2deg(chi_pup)); axis image; colorbar;
xlim([-70 70]); ylim([-70 70]);
title('Pupil ellipticity angle \chi (deg)');

figure('Name','Near-field polarization-azimuth distribution','Color','w');
histogram(rad2deg(psi_near(:)), 100, 'Normalization','pdf', 'EdgeColor','none');
xline(45,'--r','Input azimuth 45 deg','LineWidth',1.5);
xlabel('Near-field polarization azimuth \psi (deg)'); ylabel('Probability density');
title('Polarization-azimuth spatial dispersion from the diffuser'); grid on;

fprintf('\nSimulation complete.\n');
