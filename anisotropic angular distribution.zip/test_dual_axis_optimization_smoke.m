%% 最大/最小主方向目标与三阶段优化轻量自检
clear;
clc;

programDirectory = fileparts(mfilename('fullpath'));
modelDirectory = [ ...
    'D:\课题\小论文\参考文献与初稿\8-18日初稿\', ...
    '高斯快速逼近代码\高斯核散射模型完整坐标优化程序'];
addpath(programDirectory);
addpath(modelDirectory);

config = create_dual_axis_config();
config.geometry.Nx = 5;
config.geometry.Ny = 5;
config.numerical.resolutionX = 150;
config.numerical.resolutionY = 150;
config.numerical.searchResolutionX = 150;
config.numerical.searchResolutionY = 150;
config.angular.sampleCount = 81;
config.measurement.radialBinCount = 80;
config.geometry.rotationRange = deg2rad(90);
config.dualOptimization.maximumEvaluationsPerParameter = 3;
config.dualOptimization.noImprovementPatience = 1;
validate_dual_axis_config(config);

bank = build_common_random_bank(config);
options.resolutionX = 150;
options.resolutionY = 150;
options.retainLargeData = false;
options.failFast = true;
options.angularMode = 'targetOnly';
options.objectiveMode = 'directionalExtrema';
baseline = evaluate_dual_axis_candidate(config,bank,options);
assert(strcmp(baseline.status,'valid'),'方向极值基准评价无效。');
assert(baseline.fwhmMaximumDirectionDegree >= ...
    baseline.fwhmMinimumDirectionDegree, ...
    '最大方向 FWHM 小于最小方向 FWHM。');
azimuthSeparation = mod(abs(baseline.maximumDirectionAzimuthDegree- ...
    baseline.minimumDirectionAzimuthDegree),180);
azimuthSeparation = min(azimuthSeparation,180-azimuthSeparation);
assert(abs(azimuthSeparation-90) < 1e-8,'最大/最小主方向不正交。');

% 把两个目标故意按 Y、X 的顺序输入，验证程序会自动交换配对。
config.dualTarget.xFwhmDegree = baseline.fwhmMinimumDirectionDegree;
config.dualTarget.yFwhmDegree = baseline.fwhmMaximumDirectionDegree;
config.dualTarget.xToleranceDegree = 1e-6;
config.dualTarget.yToleranceDegree = 1e-6;
config.target.fwhmDegree = config.dualTarget.xFwhmDegree;
config.target.angleToleranceDegree = 1e-6;
extremaEvaluation = evaluate_dual_axis_candidate(config,bank,options);
assert(extremaEvaluation.withinBothTolerances, ...
    '颠倒两个输入值后，最大/最小主方向目标未同时达标。');
assert(abs(extremaEvaluation.targetMaximumDegree- ...
    baseline.fwhmMaximumDirectionDegree) < 1e-12, ...
    '较大输入值没有自动成为最大方向目标。');

% 验证三个抽象参数正确写入物理配置。
parameters = config.dualOptimization.parameters;
kbParameter = parameters(strcmp({parameters.name},'kb'));
kaParameter = parameters(strcmp({parameters.name},'kaScale'));
rotationParameter = parameters(strcmp( ...
    {parameters.name},'rotationUpperDegree'));
kaConfig = apply_dual_axis_parameter(config,kaParameter,0.9);
assert(abs(kaConfig.aspectKa.minimum-0.9* ...
    config.dualOptimization.baseAspectKaMinimum) < 1e-12, ...
    'kaScale 未正确写入。');
kbConfig = apply_dual_axis_parameter(config,kbParameter,0.7);
assert(abs(kbConfig.geometry.kb-0.7) < 1e-12,'kb 未正确写入。');
rotationConfig = apply_dual_axis_parameter(config,rotationParameter,45);
assert(abs(rad2deg(rotationConfig.geometry.rotationRange)-45) < 1e-12, ...
    '朝向展宽上限未正确写入。');

% 用 0 degree、初始 kb 和初始 kaScale 下的散射角作为目标，验证：
% 阶段一先优化 kb，阶段二再优化 kaScale，阶段三仍会被调用且保持 0 degree。
stageConfig = config;
stageConfig = apply_dual_axis_parameter(stageConfig,kbParameter, ...
    kbParameter.initialValue);
stageConfig = apply_dual_axis_parameter(stageConfig,kaParameter, ...
    kaParameter.initialValue);
stageConfig = apply_dual_axis_parameter(stageConfig,rotationParameter,0);
stageOptions = options;
stageOptions.objectiveMode = 'directionalExtrema';
stageProbe = evaluate_dual_axis_candidate(stageConfig,bank,stageOptions);
assert(strcmp(stageProbe.status,'valid'),'三阶段基准评价无效。');
stageConfig.dualTarget.xFwhmDegree = ...
    stageProbe.fwhmMaximumDirectionDegree;
stageConfig.dualTarget.yFwhmDegree = ...
    stageProbe.fwhmMinimumDirectionDegree;
stageConfig.dualTarget.xToleranceDegree = 1e-6;
stageConfig.dualTarget.yToleranceDegree = 1e-6;
stageConfig.target.fwhmDegree = stageProbe.fwhmMaximumDirectionDegree;
stageConfig.target.angleToleranceDegree = 1e-6;
stageSearch = run_dual_axis_coordinate_search(stageConfig,bank,'');
assert(stageSearch.completedStages == 3, ...
    '满足基准目标时，三个阶段没有全部按顺序执行。');
assert(strcmp(stageSearch.parameterResults.parameterName(1),'kb'), ...
    '第一阶段优化参数不是 kb。');
assert(strcmp(stageSearch.parameterResults.parameterName(2),'kaScale'), ...
    '第二阶段优化参数不是 kaScale。');
assert(strcmp(stageSearch.parameterResults.parameterName(3), ...
    'rotationUpperDegree'),'第三阶段优化参数不是朝向展宽上限。');
assert(stageSearch.parameterResults.stage(1) == 1 && ...
       stageSearch.parameterResults.stage(2) == 2 && ...
       stageSearch.parameterResults.stage(3) == 3, ...
    '阶段编号或优化顺序错误。');
assert(all(stageSearch.parameterResults.executed), ...
    '三个阶段中存在未执行的阶段。');
assert(abs(rad2deg(stageSearch.bestConfig.geometry.rotationRange)) < 1e-12, ...
    '0 degree 已满足目标时，第三阶段不应改变朝向展宽上限。');
assert(strcmp(stageSearch.stopReason, ...
    'directional_extrema_reached_at_zero_rotation'), ...
    '0 degree 已达标时的停止原因错误。');

% 构造无法同时达到的目标，验证阶段二会进入 kb/kaScale 联合修正，
% 并验证单参数搜索实际覆盖全边界粗扫描，而不是只检查初值邻点。
jointConfig = stageConfig;
jointParameters = jointConfig.dualOptimization.parameters;
jointKbIndex = find(strcmp({jointParameters.name},'kb'),1);
jointKaIndex = find(strcmp({jointParameters.name},'kaScale'),1);
jointRotationIndex = find(strcmp( ...
    {jointParameters.name},'rotationUpperDegree'),1);
jointConfig.dualOptimization.parameters(jointKbIndex).lowerBound = 0.78;
jointConfig.dualOptimization.parameters(jointKbIndex).upperBound = 0.82;
jointConfig.dualOptimization.parameters(jointKbIndex).coarseStep = 0.02;
jointConfig.dualOptimization.parameters(jointKbIndex).fineStep = 0.01;
jointConfig.dualOptimization.parameters(jointKaIndex).lowerBound = 0.98;
jointConfig.dualOptimization.parameters(jointKaIndex).upperBound = 1.02;
jointConfig.dualOptimization.parameters(jointKaIndex).coarseStep = 0.02;
jointConfig.dualOptimization.parameters(jointKaIndex).fineStep = 0.01;
jointConfig.dualOptimization.parameters( ...
    jointRotationIndex).coarseStep = 90;
jointConfig.dualOptimization.parameters( ...
    jointRotationIndex).fineStep = 45;
jointConfig.dualOptimization.maximumEvaluationsPerParameter = 12;
jointConfig.dualOptimization.maximumJointRefinementRounds = 2;
jointConfig.dualOptimization.minimumJointObjectiveImprovement = 0;
jointConfig.dualOptimization.noImprovementPatience = 1;
jointConfig.dualTarget.xFwhmDegree = max( ...
    stageProbe.fwhmMaximumDirectionDegree, ...
    stageProbe.fwhmMinimumDirectionDegree);
jointConfig.dualTarget.yFwhmDegree = 1;
jointConfig.dualTarget.xToleranceDegree = 1e-6;
jointConfig.dualTarget.yToleranceDegree = 1e-6;
jointConfig.target.fwhmDegree = jointConfig.dualTarget.xFwhmDegree;
jointConfig.target.angleToleranceDegree = 1e-6;
validate_dual_axis_config(jointConfig);
jointSearch = run_dual_axis_coordinate_search(jointConfig,bank,'');
assert(jointSearch.jointRefinementRounds >= 1, ...
    '双目标未达标时没有进入 kb/kaScale 联合修正。');
assert(any(jointSearch.parameterResults.jointRound > 0 & ...
    strcmp(jointSearch.parameterResults.parameterName,'kb')), ...
    '联合修正没有重新优化 kb。');
assert(any(strcmp(jointSearch.history.phase,'global_coarse_scan')), ...
    '单参数优化没有执行全边界粗扫描。');
assert(strcmp(jointSearch.parameterResults.parameterName(end), ...
    'rotationUpperDegree'),'联合修正后没有执行朝向优化。');

fprintf('最大/最小主方向目标与三阶段优化轻量自检通过。\n');
fprintf(['基准最大方向=%.6f deg @ %.3f deg，', ...
    '最小方向=%.6f deg @ %.3f deg。\n'], ...
    baseline.fwhmMaximumDirectionDegree, ...
    baseline.maximumDirectionAzimuthDegree, ...
    baseline.fwhmMinimumDirectionDegree, ...
    baseline.minimumDirectionAzimuthDegree);
