function manifest = redraw_dual_axis_optics_express_figures(resultDirectory, outputDirectory)
%REDRAW_DUAL_AXIS_OPTICS_EXPRESS_FIGURES Replot manuscript Figs. 5.8--5.14.
%
% This function reads the saved Gaussian-kernel and Snell ray-tracing
% results. It does not rerun the optimization or change any numerical
% result. The figures are formatted at their final manuscript size with
% English labels, line styles/markers that remain distinguishable without
% color, and separate high-resolution publication files.
%
% Outputs for every figure:
%   PNG  - 600 dpi, used by the Markdown manuscript.
%   TIFF - 600 dpi, publication submission source.
%   PDF  - vector for line plots; 600-dpi image for maps/surfaces.
%
% Usage:
%   redraw_dual_axis_optics_express_figures
%   redraw_dual_axis_optics_express_figures(resultDirectory)
%   redraw_dual_axis_optics_express_figures(resultDirectory, outputDirectory)

if nargin < 1 || isempty(resultDirectory)
    programDirectory = fileparts(mfilename('fullpath'));
    resultDirectory = fullfile(programDirectory, '优化结果', '20260907_143700');
end
if nargin < 2 || isempty(outputDirectory)
    outputDirectory = fullfile(resultDirectory, 'OpticsExpress重绘图片-9-8');
end

gaussianFile = fullfile(resultDirectory, 'complete_dual_axis_result.mat');
snellFile = fullfile(resultDirectory, 'complete_snell_refinement_result.mat');
assert(isfile(gaussianFile), 'Gaussian result file not found: %s', gaussianFile);
assert(isfile(snellFile), 'Snell result file not found: %s', snellFile);
if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end

gaussian = load(gaussianFile, 'finalEvaluation', 'searchResult');
snell = load(snellFile, 'finalEvaluation', 'searchResult');
style = publication_style();

targetMaximum = get_numeric_field(gaussian.finalEvaluation, ...
    'targetMaximumDegree', 30);
targetMinimum = get_numeric_field(gaussian.finalEvaluation, ...
    'targetMinimumDegree', 20);

entries = strings(0, 8);

% Fig. 5.8: Gaussian three-parameter coordinate-search history.
fig = plot_dual_history(gaussian.searchResult.history, ...
    targetMaximum, targetMinimum, style);
entries(end+1, :) = export_figure(fig, outputDirectory, ...
    'fig_5_8_gaussian_dual_axis_history', 'Fig. 5.8', ...
    style.fullWidthCm, style.historyHeightCm, true, style);
close(fig);

% Fig. 5.9: Optimized continuous surface used by the Gaussian evaluation.
fig = plot_surface(gaussian.finalEvaluation.surfaceData, style);
entries(end+1, :) = export_figure(fig, outputDirectory, ...
    'fig_5_9_gaussian_optimized_surface', 'Fig. 5.9', ...
    style.fullWidthCm, style.surfaceHeightCm, false, style);
close(fig);

% Fig. 5.10: Gaussian far-field angular distribution.
fig = plot_angular_distribution( ...
    gaussian.finalEvaluation.angularDistribution.thetaDegree, ...
    gaussian.finalEvaluation.angularDistribution.normalized, ...
    'Normalized intensity', style);
entries(end+1, :) = export_figure(fig, outputDirectory, ...
    'fig_5_10_gaussian_angular_distribution', 'Fig. 5.10', ...
    style.mapWidthCm, style.mapHeightCm, false, style);
close(fig);

% Fig. 5.11: Gaussian principal-axis profiles.
fig = plot_principal_profiles(gaussian.finalEvaluation.directionalMetrics, ...
    gaussian.finalEvaluation, 'Normalized intensity', style);
entries(end+1, :) = export_figure(fig, outputDirectory, ...
    'fig_5_11_gaussian_principal_profiles', 'Fig. 5.11', ...
    style.fullWidthCm, style.profileHeightCm, true, style);
close(fig);

% Fig. 5.12: Local Snell-refinement history.
fig = plot_dual_history(snell.searchResult.history, ...
    targetMaximum, targetMinimum, style);
entries(end+1, :) = export_figure(fig, outputDirectory, ...
    'fig_5_12_snell_refinement_history', 'Fig. 5.12', ...
    style.fullWidthCm, style.historyHeightCm, true, style);
close(fig);

% Fig. 5.13: Snell ray-tracing far-field angular distribution.
fig = plot_angular_distribution( ...
    snell.finalEvaluation.angularDistribution.thetaDegree, ...
    snell.finalEvaluation.angularDistribution.normalized, ...
    'Normalized ray count', style);
entries(end+1, :) = export_figure(fig, outputDirectory, ...
    'fig_5_13_snell_angular_distribution', 'Fig. 5.13', ...
    style.mapWidthCm, style.mapHeightCm, false, style);
close(fig);

% Fig. 5.14: Snell principal-axis profiles.
fig = plot_principal_profiles(snell.finalEvaluation.directionalMetrics, ...
    snell.finalEvaluation, 'Normalized ray count', style);
entries(end+1, :) = export_figure(fig, outputDirectory, ...
    'fig_5_14_snell_principal_profiles', 'Fig. 5.14', ...
    style.fullWidthCm, style.profileHeightCm, true, style);
close(fig);

manifest = array2table(entries, 'VariableNames', ...
    {'Figure', 'PNG', 'TIFF', 'PDF', 'Width_cm', 'Height_cm', ...
    'Raster_dpi', 'PDF_type'});
writetable(manifest, fullfile(outputDirectory, 'figure_manifest.csv'));

fprintf('Created %d publication figures in:\n%s\n', ...
    height(manifest), outputDirectory);
disp(manifest(:, {'Figure', 'PNG', 'TIFF', 'PDF'}));
end

function style = publication_style()
style.fontName = 'Arial';
style.fontSize = 8;
style.legendFontSize = 7.2;
style.axesLineWidth = 0.75;
style.curveLineWidth = 1.15;
style.referenceLineWidth = 0.9;
style.markerSize = 4.0;
style.fullWidthCm = 13.3;
style.mapWidthCm = 10.5;
style.mapHeightCm = 9.0;
style.historyHeightCm = 9.8;
style.surfaceHeightCm = 9.2;
style.profileHeightCm = 8.6;
style.rasterDpi = 600;
style.blue = [0, 114, 178] / 255;
style.orange = [213, 94, 0] / 255;
style.gray = [0.32, 0.32, 0.32];
end

function fig = new_figure(widthCm, heightCm)
fig = figure('Color', 'w', 'Units', 'centimeters', ...
    'Position', [2, 2, widthCm, heightCm], ...
    'PaperPositionMode', 'auto', 'Visible', 'off');
end

function style_axes(ax, style)
set(ax, 'FontName', style.fontName, 'FontSize', style.fontSize, ...
    'LineWidth', style.axesLineWidth, 'TickDir', 'out', ...
    'Box', 'on', 'Layer', 'top');
ax.LabelFontSizeMultiplier = 1;
ax.TitleFontSizeMultiplier = 1;
end

function label_panel(ax, labelText, style)
text(ax, 0.012, 0.965, labelText, 'Units', 'normalized', ...
    'VerticalAlignment', 'top', 'FontName', style.fontName, ...
    'FontSize', style.fontSize, 'FontWeight', 'bold', ...
    'Color', 'k', 'Interpreter', 'none', 'BackgroundColor', 'w', ...
    'Margin', 1);
end

function value = get_numeric_field(data, fieldName, fallback)
if isstruct(data) && isfield(data, fieldName) && ...
        isscalar(data.(fieldName)) && isfinite(data.(fieldName))
    value = data.(fieldName);
else
    value = fallback;
end
end

function [fwhmMaximum, fwhmMinimum, objective] = history_values(history)
if istable(history)
    fwhmMaximum = history.fwhmMaximumDegree;
    fwhmMinimum = history.fwhmMinimumDegree;
    objective = history.objectiveScore;
    valid = isfinite(fwhmMaximum) & isfinite(fwhmMinimum) & ...
        isfinite(objective);
    if ismember('status', history.Properties.VariableNames)
        status = string(history.status);
        valid = valid & (strcmpi(status, 'valid') | strcmpi(status, 'accepted'));
    end
    fwhmMaximum = fwhmMaximum(valid);
    fwhmMinimum = fwhmMinimum(valid);
    objective = objective(valid);
else
    valid = isfinite([history.fwhmMaximumDegree]) & ...
        isfinite([history.fwhmMinimumDegree]) & ...
        isfinite([history.objectiveScore]);
    if isfield(history, 'status')
        status = string({history.status});
        valid = valid & (strcmpi(status, 'valid') | strcmpi(status, 'accepted'));
    end
    fwhmMaximum = [history(valid).fwhmMaximumDegree].';
    fwhmMinimum = [history(valid).fwhmMinimumDegree].';
    objective = [history(valid).objectiveScore].';
end
fwhmMaximum = fwhmMaximum(:);
fwhmMinimum = fwhmMinimum(:);
objective = objective(:);
end

function indices = sparse_marker_indices(numberOfPoints)
if numberOfPoints <= 14
    indices = 1:numberOfPoints;
else
    indices = unique(round(linspace(1, numberOfPoints, 14)));
end
end

function fig = plot_dual_history(history, targetMaximum, targetMinimum, style)
[fwhmMaximum, fwhmMinimum, objective] = history_values(history);
assert(~isempty(objective), 'No valid history entries are available for plotting.');
index = (1:numel(objective)).';
markerIndices = sparse_marker_indices(numel(index));

fig = new_figure(style.fullWidthCm, style.historyHeightCm);
layout = tiledlayout(fig, 2, 1, 'TileSpacing', 'compact', ...
    'Padding', 'compact');

ax1 = nexttile(layout);
plot(ax1, index, fwhmMaximum, '-o', 'Color', style.blue, ...
    'LineWidth', style.curveLineWidth, 'MarkerSize', style.markerSize, ...
    'MarkerFaceColor', 'w', 'MarkerIndices', markerIndices);
hold(ax1, 'on');
plot(ax1, index, fwhmMinimum, '--s', 'Color', style.orange, ...
    'LineWidth', style.curveLineWidth, 'MarkerSize', style.markerSize, ...
    'MarkerFaceColor', 'w', 'MarkerIndices', markerIndices);
yline(ax1, targetMaximum, '-.', 'Color', style.gray, ...
    'LineWidth', style.referenceLineWidth);
yline(ax1, targetMinimum, ':', 'Color', style.gray, ...
    'LineWidth', style.referenceLineWidth);
grid(ax1, 'on');
ax1.GridAlpha = 0.14;
ylabel(ax1, 'FWHM (deg)');
legend(ax1, {'Maximum-axis FWHM', 'Minimum-axis FWHM', ...
    sprintf('Maximum target = %.1f deg', targetMaximum), ...
    sprintf('Minimum target = %.1f deg', targetMinimum)}, ...
    'Location', 'best', 'FontSize', style.legendFontSize, 'Box', 'off');
style_axes(ax1, style);
label_panel(ax1, '(a)', style);

ax2 = nexttile(layout);
semilogy(ax2, index, max(objective, realmin), '-d', ...
    'Color', style.blue, 'LineWidth', style.curveLineWidth, ...
    'MarkerSize', style.markerSize, 'MarkerFaceColor', 'w', ...
    'MarkerIndices', markerIndices);
hold(ax2, 'on');
yline(ax2, 1, '--', 'Color', style.gray, ...
    'LineWidth', style.referenceLineWidth);
grid(ax2, 'on');
ax2.GridAlpha = 0.14;
xlabel(ax2, 'Valid evaluation index');
ylabel(ax2, 'Objective score, J');
legend(ax2, {'Objective score', 'Acceptance boundary, J = 1'}, ...
    'Location', 'best', 'FontSize', style.legendFontSize, 'Box', 'off');
style_axes(ax2, style);
label_panel(ax2, '(b)', style);
end

function fig = plot_surface(surfaceData, style)
resolutionX = size(surfaceData.Z, 2);
resolutionY = size(surfaceData.Z, 1);
stride = max(1, ceil(max(resolutionX, resolutionY) / 700));
rows = 1:stride:resolutionY;
columns = 1:stride:resolutionX;
xMicrometer = 1e3 * surfaceData.x(columns);
yMicrometer = 1e3 * surfaceData.y(rows);
zMicrometer = 1e3 * surfaceData.Z(rows, columns);

fig = new_figure(style.fullWidthCm, style.surfaceHeightCm);
ax = axes(fig);
surf(ax, xMicrometer, yMicrometer, zMicrometer, zMicrometer, ...
    'EdgeColor', 'none', 'FaceColor', 'interp');
view(ax, -42, 30);
axis(ax, 'tight');
pbaspect(ax, [1, 1, 0.42]);
grid(ax, 'on');
ax.GridAlpha = 0.12;
xlabel(ax, 'x (\mum)');
ylabel(ax, 'y (\mum)');
zlabel(ax, 'z (\mum)');
colormap(ax, parula(256));
cb = colorbar(ax);
cb.Label.String = 'Surface height (\mum)';
cb.Label.Interpreter = 'tex';
cb.FontName = style.fontName;
cb.FontSize = style.fontSize;
lighting(ax, 'gouraud');
light(ax, 'Position', [-1, -1, 2], 'Style', 'infinite');
material(ax, 'dull');
style_axes(ax, style);
end

function fig = plot_angular_distribution(theta, distribution, colorbarLabel, style)
theta = theta(:).';
distribution = distribution ./ max(distribution(:));

fig = new_figure(style.mapWidthCm, style.mapHeightCm);
ax = axes(fig);
imagesc(ax, theta, theta, distribution.');
set(ax, 'YDir', 'normal');
axis(ax, 'image');
clim(ax, [0, 1]);
hold(ax, 'on');
contour(ax, theta, theta, distribution.', [0.1, 0.1], '--', ...
    'Color', 'w', 'LineWidth', style.referenceLineWidth);
contour(ax, theta, theta, distribution.', [0.5, 0.5], '-', ...
    'Color', 'w', 'LineWidth', style.curveLineWidth);
xlabel(ax, '\theta_x (deg)');
ylabel(ax, '\theta_y (deg)');
colormap(ax, parula(256));
cb = colorbar(ax);
cb.Ticks = 0:0.2:1;
cb.Label.String = colorbarLabel;
cb.FontName = style.fontName;
cb.FontSize = style.fontSize;
style_axes(ax, style);
end

function fig = plot_principal_profiles(metrics, evaluation, yLabelText, style)
theta = metrics.thetaDegree(:);
maximumProfile = metrics.maximumDirectionProfileNormalized(:);
minimumProfile = metrics.minimumDirectionProfileNormalized(:);
maximumFwhm = get_numeric_field(evaluation, ...
    'fwhmMaximumDirectionDegree', NaN);
minimumFwhm = get_numeric_field(evaluation, ...
    'fwhmMinimumDirectionDegree', NaN);
markerIndices = sparse_marker_indices(numel(theta));

fig = new_figure(style.fullWidthCm, style.profileHeightCm);
ax = axes(fig);
plot(ax, theta, maximumProfile, '-o', 'Color', style.blue, ...
    'LineWidth', style.curveLineWidth, 'MarkerSize', style.markerSize, ...
    'MarkerFaceColor', 'w', 'MarkerIndices', markerIndices);
hold(ax, 'on');
plot(ax, theta, minimumProfile, '--s', 'Color', style.orange, ...
    'LineWidth', style.curveLineWidth, 'MarkerSize', style.markerSize, ...
    'MarkerFaceColor', 'w', 'MarkerIndices', markerIndices);
yline(ax, 0.5, ':', 'Color', style.gray, ...
    'LineWidth', style.referenceLineWidth);
grid(ax, 'on');
ax.GridAlpha = 0.14;
xlim(ax, [min(theta), max(theta)]);
ylim(ax, [0, 1.03]);
xlabel(ax, 'Angle along principal axis (deg)');
ylabel(ax, yLabelText);
legend(ax, {sprintf('Maximum axis (%.2f deg)', maximumFwhm), ...
    sprintf('Minimum axis (%.2f deg)', minimumFwhm), ...
    'Half maximum'}, 'Location', 'northoutside', ...
    'Orientation', 'horizontal', 'NumColumns', 2, ...
    'FontSize', style.legendFontSize, 'Box', 'off');
style_axes(ax, style);
end

function entry = export_figure(fig, outputDirectory, baseName, figureNumber, ...
        widthCm, heightCm, vectorPdf, style)
pngName = baseName + ".png";
tiffName = baseName + ".tif";
pdfName = baseName + ".pdf";
pngPath = fullfile(outputDirectory, pngName);
tiffPath = fullfile(outputDirectory, tiffName);
pdfPath = fullfile(outputDirectory, pdfName);

exportgraphics(fig, pngPath, 'Resolution', style.rasterDpi, ...
    'BackgroundColor', 'white');
exportgraphics(fig, tiffPath, 'Resolution', style.rasterDpi, ...
    'BackgroundColor', 'white');
if vectorPdf
    exportgraphics(fig, pdfPath, 'ContentType', 'vector', ...
        'BackgroundColor', 'white');
    pdfType = "vector";
else
    exportgraphics(fig, pdfPath, 'ContentType', 'image', ...
        'Resolution', style.rasterDpi, 'BackgroundColor', 'white');
    pdfType = "image";
end

entry = [string(figureNumber), string(pngName), string(tiffName), ...
    string(pdfName), string(widthCm), string(heightCm), ...
    string(style.rasterDpi), pdfType];
end
