function metrics = measure_directional_fwhm_extrema(config,kernelStats)
%MEASURE_DIRECTIONAL_FWHM_EXTREMA 测量二维散射分布主方向的最大/最小 FWHM。
theta = linspace(config.angular.minimumDegree, ...
    config.angular.maximumDegree,config.angular.sampleCount).';
stats = kernelStats.table;
valid = stats.validKernel & isfinite(stats.weight) & stats.weight > 0 & ...
    isfinite(stats.meanThetaX_deg) & isfinite(stats.meanThetaY_deg) & ...
    isfinite(stats.cov11_deg2) & isfinite(stats.cov12_deg2) & ...
    isfinite(stats.cov22_deg2);
assert(any(valid),'没有可用于方向性 FWHM 的有效高斯核。');
weight = stats.weight(valid);
meanX = stats.meanThetaX_deg(valid);
meanY = stats.meanThetaY_deg(valid);
cov11 = stats.cov11_deg2(valid);
cov12 = stats.cov12_deg2(valid);
cov22 = stats.cov22_deg2(valid);
normalizedWeight = weight/sum(weight);
mixtureMeanX = sum(normalizedWeight.*meanX);
mixtureMeanY = sum(normalizedWeight.*meanY);
deltaMeanX = meanX-mixtureMeanX;
deltaMeanY = meanY-mixtureMeanY;
mixtureCovariance = [ ...
    sum(normalizedWeight.*(cov11+deltaMeanX.^2)), ...
    sum(normalizedWeight.*(cov12+deltaMeanX.*deltaMeanY)); ...
    sum(normalizedWeight.*(cov12+deltaMeanX.*deltaMeanY)), ...
    sum(normalizedWeight.*(cov22+deltaMeanY.^2))];
mixtureCovariance = 0.5*(mixtureCovariance+mixtureCovariance.');
[eigenvectors,eigenvalueVector] = eig(mixtureCovariance,'vector');
[~,order] = sort(eigenvalueVector,'descend');
directions = eigenvectors(:,order);
for directionIndex = 1:2
    directions(:,directionIndex) = ...
        canonicalize_direction_local(directions(:,directionIndex));
end
profiles = zeros(numel(theta),2);
widths = nan(1,2);
leftCrossings = nan(1,2);
rightCrossings = nan(1,2);
azimuths = nan(1,2);
for directionIndex = 1:2
    direction = directions(:,directionIndex);
    profiles(:,directionIndex) = directional_cut_local(theta,direction, ...
        mixtureMeanX,mixtureMeanY,meanX,meanY,cov11,cov12,cov22,weight);
    profiles(:,directionIndex) = profiles(:,directionIndex)/ ...
        (max(profiles(:,directionIndex),[],'omitnan')+eps);
    [leftCrossings(directionIndex),rightCrossings(directionIndex), ...
        widths(directionIndex)] = find_level_width_local( ...
        theta,profiles(:,directionIndex),0.5);
    azimuths(directionIndex) = mod(atan2d(direction(2),direction(1)),180);
end
assert(all(isfinite(widths)), ...
    '当前角度网格内无法获得完整的主方向半高全宽。');
[maximumWidth,maximumIndex] = max(widths);
[minimumWidth,minimumIndex] = min(widths);
metrics.fwhmMaximumDirectionDegree = maximumWidth;
metrics.fwhmMinimumDirectionDegree = minimumWidth;
metrics.maximumDirectionAzimuthDegree = azimuths(maximumIndex);
metrics.minimumDirectionAzimuthDegree = azimuths(minimumIndex);
metrics.maximumDirectionVector = directions(:,maximumIndex).';
metrics.minimumDirectionVector = directions(:,minimumIndex).';
metrics.maximumLeftHalfDegree = leftCrossings(maximumIndex);
metrics.maximumRightHalfDegree = rightCrossings(maximumIndex);
metrics.minimumLeftHalfDegree = leftCrossings(minimumIndex);
metrics.minimumRightHalfDegree = rightCrossings(minimumIndex);
metrics.directionalAnisotropyDegree = maximumWidth-minimumWidth;
metrics.mixtureMeanThetaXDegree = mixtureMeanX;
metrics.mixtureMeanThetaYDegree = mixtureMeanY;
metrics.mixtureCovarianceDegree2 = mixtureCovariance;
metrics.thetaDegree = theta;
metrics.maximumDirectionProfileNormalized = profiles(:,maximumIndex);
metrics.minimumDirectionProfileNormalized = profiles(:,minimumIndex);
metrics.principalDirectionAzimuthsDegree = azimuths;
metrics.principalDirectionFwhmDegree = widths;
end

function profile = directional_cut_local(theta,direction,centerX,centerY, ...
        meanX,meanY,cov11,cov12,cov22,weight)
profile = zeros(size(theta));
for kernelIndex = 1:numel(weight)
    determinant = cov11(kernelIndex)*cov22(kernelIndex)- ...
        cov12(kernelIndex)^2;
    if ~isfinite(determinant) || determinant <= 0
        continue;
    end
    inverse11 = cov22(kernelIndex)/determinant;
    inverse12 = -cov12(kernelIndex)/determinant;
    inverse22 = cov11(kernelIndex)/determinant;
    deltaX = centerX+theta*direction(1)-meanX(kernelIndex);
    deltaY = centerY+theta*direction(2)-meanY(kernelIndex);
    quadratic = inverse11.*deltaX.^2 + ...
        2*inverse12.*deltaX.*deltaY + inverse22.*deltaY.^2;
    profile = profile + weight(kernelIndex).*exp(-0.5*quadratic)/ ...
        (2*pi*sqrt(determinant));
end
end

function direction = canonicalize_direction_local(direction)
direction = direction/norm(direction);
if direction(1) < 0 || ...
        (abs(direction(1)) <= 10*eps && direction(2) < 0)
    direction = -direction;
end
end

function [leftCross,rightCross,fullWidth] = ...
        find_level_width_local(theta,intensityNormalized,level)
theta = theta(:);
intensityNormalized = intensityNormalized(:);
valid = isfinite(theta) & isfinite(intensityNormalized);
theta = theta(valid);
intensityNormalized = intensityNormalized(valid);
leftCross = NaN;
rightCross = NaN;
fullWidth = NaN;
if isempty(theta)
    return;
end
[theta,order] = sort(theta);
intensityNormalized = intensityNormalized(order);
peakValue = max(intensityNormalized);
if ~isfinite(peakValue) || peakValue <= 0
    return;
end
intensityNormalized = intensityNormalized/peakValue;
[~,peakIndex] = max(intensityNormalized);
leftIndex = find(intensityNormalized(1:peakIndex) <= level,1,'last');
rightRelativeIndex = find( ...
    intensityNormalized(peakIndex:end) <= level,1,'first');
if ~isempty(leftIndex) && leftIndex < peakIndex
    leftCross = interpolate_level_local(theta(leftIndex), ...
        intensityNormalized(leftIndex),theta(leftIndex+1), ...
        intensityNormalized(leftIndex+1),level);
end
if ~isempty(rightRelativeIndex)
    rightIndex = peakIndex+rightRelativeIndex-1;
    if rightIndex > peakIndex
        rightCross = interpolate_level_local(theta(rightIndex-1), ...
            intensityNormalized(rightIndex-1),theta(rightIndex), ...
            intensityNormalized(rightIndex),level);
    end
end
if isfinite(leftCross) && isfinite(rightCross)
    fullWidth = rightCross-leftCross;
end
end

function crossing = interpolate_level_local(x1,y1,x2,y2,level)
if abs(y2-y1) < eps
    crossing = 0.5*(x1+x2);
else
    crossing = x1+(level-y1)*(x2-x1)/(y2-y1);
end
end
