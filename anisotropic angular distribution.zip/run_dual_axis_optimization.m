function result = run_dual_axis_optimization(userControl)
%RUN_DUAL_AXIS_OPTIMIZATION 最大/最小主方向 FWHM、三参数优化总控入口。
%
% 推荐调用方式：
%   control.action = 'optimize';
%   control.targetXDegree = 30;
%   control.targetYDegree = 20;
%   result = run_dual_axis_optimization(control);
%
% action 可选：smokeTest、forwardOnly、optimize。

if nargin < 1 || isempty(userControl)
    userControl = struct();
end

programDirectory = fileparts(mfilename('fullpath'));
defaults.modelDirectory = [ ...
    'D:\课题\小论文\参考文献与初稿\8-18日初稿\', ...
    '高斯快速逼近代码\高斯核散射模型完整坐标优化程序'];
defaults.action = 'optimize';

% 两个输入不绑定 X/Y；较大值作为最大主方向目标，较小值作为最小目标。
defaults.targetXDegree = 30;
defaults.targetYDegree = 20;
defaults.toleranceXDegree = 0.10;
defaults.toleranceYDegree = 0.10;

defaults.arrayNx = 60;
defaults.arrayNy = 60;
defaults.searchResolutionX = 600;
defaults.searchResolutionY = 600;
defaults.finalResolutionX = 600;
defaults.finalResolutionY = 600;

defaults.kaScaleInitial = 1.00;
defaults.kaScaleLower = 0.5;
defaults.kaScaleUpper = 1.50;
defaults.kaScaleCoarseStep = 0.02;
defaults.kaScaleFineStep = 0.0002;

defaults.kbInitial = 0.80;
defaults.kbLower = 0.40;
defaults.kbUpper = 1.00;
defaults.kbCoarseStep = 0.02;
defaults.kbFineStep = 0.0005;

% theta_p = rotationUpperDegree * U_p，U_p 为固定公共随机分位数。
defaults.rotationUpperInitialDegree = 0;
defaults.rotationUpperLowerDegree = 0;
defaults.rotationUpperUpperDegree = 180;
defaults.rotationUpperCoarseStepDegree = 10;
defaults.rotationUpperFineStepDegree = 1;

defaults.maximumEvaluationsPerParameter = 80;
defaults.noImprovementPatience = 3;
defaults.maximumJointRefinementRounds = 5;
defaults.minimumJointObjectiveImprovement = 1e-4;
defaults.randomSeed = 1;
defaults.createFigures = true;
defaults.outputRootDirectory = fullfile(programDirectory,'优化结果');

% 高斯核完成全范围快速优化后，以其最优点为中心执行小范围 Snell 精修。
defaults.enableSnellRefinement = true;
defaults.snellSearchRayCount = 2e6;
defaults.snellFinalRayCount = 2e7;
defaults.snellRayChunkSize = 2.5e5;
defaults.snellRaySamplingMode = 'r2';
defaults.snellRayRandomSeed = 104729;
defaults.snellKbHalfRange = 0.08;
defaults.snellKaScaleHalfRange = 0.12;
defaults.snellRotationHalfRangeDegree = 5;
defaults.snellKbCoarseStep = 0.01;
defaults.snellKaScaleCoarseStep = 0.01;
defaults.snellRotationCoarseStepDegree = 2;
defaults.snellKbFineStep = 0.0001;
defaults.snellKaScaleFineStep = 0.0001;
defaults.snellRotationFineStepDegree = 0.0025;
defaults.snellMaximumEvaluations = 80;
defaults.snellMaximumIterations = 16;
defaults.snellMinimumObjectiveImprovement = 1e-4;
% 单坐标停滞后先搜索 kb/kaScale 联合方向；连续两轮无改善再将步长
% 缩小一个数量级，直至达到上面定义的 FineStep。
defaults.snellEnableJointKbKa = true;
defaults.snellNoImprovementPatience = 2;
defaults.snellStepReductionFactor = 0.1;
defaults.snellPerpendicularBandwidthDegree = 0.60;
defaults.snellProfileSmoothingSigmaBins = 0.75;
defaults.snellAngularSmoothingSigmaBins = 1.0;
defaults.snellSaveAngularCsv = true;

control = merge_control_local(defaults,userControl);
validate_control_local(control);
assert(isfolder(control.modelDirectory), ...
    '找不到原高斯核模型目录：%s',control.modelDirectory);
addpath(control.modelDirectory);
addpath(programDirectory);

requiredFunctions = {'create_diffuser_config','validate_diffuser_config', ...
    'build_common_random_bank','generate_diffuser_surface', ...
    'extract_gaussian_kernel_stats','assemble_gaussian_distribution', ...
    'measure_scattering_fwhm','evaluate_diffuser_candidate'};
for index = 1:numel(requiredFunctions)
    assert(exist(requiredFunctions{index},'file') == 2, ...
        '原模型目录缺少依赖函数 %s.m。',requiredFunctions{index});
end

config = create_dual_axis_config();
config.geometry.Nx = control.arrayNx;
config.geometry.Ny = control.arrayNy;
config.numerical.searchResolutionX = control.searchResolutionX;
config.numerical.searchResolutionY = control.searchResolutionY;
config.numerical.resolutionX = control.finalResolutionX;
config.numerical.resolutionY = control.finalResolutionY;
config.random.seed = control.randomSeed;
config.dualTarget.xFwhmDegree = control.targetXDegree;
config.dualTarget.yFwhmDegree = control.targetYDegree;
config.dualTarget.xToleranceDegree = control.toleranceXDegree;
config.dualTarget.yToleranceDegree = control.toleranceYDegree;
config.target.fwhmDegree = control.targetXDegree;
config.target.angleToleranceDegree = control.toleranceXDegree;

config = configure_parameter_local(config,'kaScale', ...
    control.kaScaleInitial,control.kaScaleLower,control.kaScaleUpper, ...
    control.kaScaleCoarseStep,control.kaScaleFineStep);
config = configure_parameter_local(config,'kb', ...
    control.kbInitial,control.kbLower,control.kbUpper, ...
    control.kbCoarseStep,control.kbFineStep);
config = configure_parameter_local(config,'rotationUpperDegree', ...
    control.rotationUpperInitialDegree, ...
    control.rotationUpperLowerDegree,control.rotationUpperUpperDegree, ...
    control.rotationUpperCoarseStepDegree, ...
    control.rotationUpperFineStepDegree);

config.dualOptimization.maximumEvaluationsPerParameter = ...
    control.maximumEvaluationsPerParameter;
config.dualOptimization.noImprovementPatience = ...
    control.noImprovementPatience;
config.dualOptimization.maximumJointRefinementRounds = ...
    control.maximumJointRefinementRounds;
config.dualOptimization.minimumJointObjectiveImprovement = ...
    control.minimumJointObjectiveImprovement;

% forwardOnly 和 smokeTest 也应使用入口中填写的三参数初值。
parameters = config.dualOptimization.parameters;
for index = 1:numel(parameters)
    config = apply_dual_axis_parameter( ...
        config,parameters(index),parameters(index).initialValue);
end

if strcmp(control.action,'smokeTest')
    config.geometry.Nx = 12;
    config.geometry.Ny = 12;
    config.numerical.searchResolutionX = 280;
    config.numerical.searchResolutionY = 280;
    config.numerical.resolutionX = 280;
    config.numerical.resolutionY = 280;
    config.angular.sampleCount = 101;
    config.measurement.radialBinCount = 100;
end
validate_dual_axis_config(config);

timeStamp = char(datetime('now','Format','yyyyMMdd_HHmmss'));
outputDirectory = fullfile(control.outputRootDirectory,timeStamp);
if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end
fprintf('\n结果目录：%s\n',outputDirectory);
fprintf('无序目标对：{%.6f +/- %.6f, %.6f +/- %.6f} deg。\n', ...
    config.dualTarget.xFwhmDegree,config.dualTarget.xToleranceDegree, ...
    config.dualTarget.yFwhmDegree,config.dualTarget.yToleranceDegree);

randomBank = build_common_random_bank(config);
searchResult = [];
switch control.action
    case {'smokeTest','forwardOnly'}
        options.resolutionX = config.numerical.resolutionX;
        options.resolutionY = config.numerical.resolutionY;
        options.retainLargeData = true;
        options.failFast = true;
        options.angularMode = 'full';
        options.objectiveMode = 'directionalExtrema';
        finalEvaluation = evaluate_dual_axis_candidate( ...
            config,randomBank,options);

    case 'optimize'
        searchResult = run_dual_axis_coordinate_search( ...
            config,randomBank,outputDirectory);
        bestConfig = searchResult.bestConfig;
        options.resolutionX = bestConfig.numerical.resolutionX;
        options.resolutionY = bestConfig.numerical.resolutionY;
        options.retainLargeData = true;
        options.failFast = true;
        options.angularMode = 'full';
        options.objectiveMode = 'directionalExtrema';
        finalEvaluation = evaluate_dual_axis_candidate( ...
            bestConfig,randomBank,options);

    otherwise
        error('未知 action：%s。',control.action);
end

save_dual_axis_results(outputDirectory,searchResult,finalEvaluation);
if control.createFigures
    plot_dual_axis_results(finalEvaluation,searchResult,outputDirectory);
end

fprintf('\n高斯核阶段完成。\n');
fprintf(['最大方向 FWHM：%.6f deg（方位 %.3f deg，目标 %.6f deg，', ...
    '误差 %+.6f deg）\n'], ...
    finalEvaluation.fwhmMaximumDirectionDegree, ...
    finalEvaluation.maximumDirectionAzimuthDegree, ...
    finalEvaluation.targetMaximumDegree, ...
    finalEvaluation.signedErrorMaximumDegree);
fprintf(['最小方向 FWHM：%.6f deg（方位 %.3f deg，目标 %.6f deg，', ...
    '误差 %+.6f deg）\n'], ...
    finalEvaluation.fwhmMinimumDirectionDegree, ...
    finalEvaluation.minimumDirectionAzimuthDegree, ...
    finalEvaluation.targetMinimumDegree, ...
    finalEvaluation.signedErrorMinimumDegree);
fprintf('最大、最小主方向同时达标：%d\n', ...
    finalEvaluation.withinBothTolerances);
fprintf('最佳 kaScale=%.9g，kb=%.9g，朝向上限=%.9g deg。\n', ...
    finalEvaluation.config.dualOptimization.currentKaScale, ...
    finalEvaluation.config.geometry.kb, ...
    rad2deg(finalEvaluation.config.geometry.rotationRange));

snellResult = [];
if strcmp(control.action,'optimize') && control.enableSnellRefinement
    fprintf('以下继续使用 Snell 光线追迹进行小范围精修。\n');
    snellResult = run_dual_axis_snell_refinement( ...
        finalEvaluation.config,randomBank,control,outputDirectory);
end

result.control = control;
result.gaussianFinalEvaluation = finalEvaluation;
result.searchResult = searchResult;
result.snellRefinement = snellResult;
result.outputDirectory = outputDirectory;
if isempty(snellResult)
    result.bestConfig = finalEvaluation.config;
    result.finalEvaluation = finalEvaluation;
else
    result.bestConfig = snellResult.bestConfig;
    result.finalEvaluation = snellResult.bestEvaluation;
end
end

function config = configure_parameter_local( ...
        config,name,initialValue,lowerBound,upperBound,coarseStep,fineStep)
index = find(strcmp({config.dualOptimization.parameters.name},name),1);
assert(~isempty(index),'不存在参数 %s。',name);
config.dualOptimization.parameters(index).initialValue = initialValue;
config.dualOptimization.parameters(index).lowerBound = lowerBound;
config.dualOptimization.parameters(index).upperBound = upperBound;
config.dualOptimization.parameters(index).coarseStep = coarseStep;
config.dualOptimization.parameters(index).fineStep = fineStep;
end

function control = merge_control_local(defaults,userControl)
control = defaults;
validFields = fieldnames(defaults);
fields = fieldnames(userControl);
for index = 1:numel(fields)
    name = fields{index};
    assert(any(strcmp(validFields,name)),'未知控制字段：%s。',name);
    control.(name) = userControl.(name);
end
end

function validate_control_local(control)
assert(any(strcmp(control.action,{'smokeTest','forwardOnly','optimize'})), ...
    'action 必须为 smokeTest、forwardOnly 或 optimize。');
positiveFields = {'targetXDegree','targetYDegree','toleranceXDegree', ...
    'toleranceYDegree','arrayNx','arrayNy','searchResolutionX', ...
    'searchResolutionY','finalResolutionX','finalResolutionY', ...
    'kaScaleInitial','kaScaleCoarseStep','kaScaleFineStep', ...
    'kbInitial','kbCoarseStep','kbFineStep', ...
    'rotationUpperCoarseStepDegree','rotationUpperFineStepDegree', ...
    'maximumEvaluationsPerParameter','noImprovementPatience', ...
    'maximumJointRefinementRounds','snellNoImprovementPatience'};
for index = 1:numel(positiveFields)
    value = control.(positiveFields{index});
    assert(isnumeric(value) && isscalar(value) && isfinite(value) && value > 0, ...
        '控制字段 %s 必须为正的有限标量。',positiveFields{index});
end
assert(control.kaScaleLower < control.kaScaleUpper && ...
    control.kaScaleInitial >= control.kaScaleLower && ...
    control.kaScaleInitial <= control.kaScaleUpper, ...
    'kaScale 搜索范围或初值不合法。');
assert(control.kbLower > 0 && control.kbUpper <= 1 && ...
    control.kbLower < control.kbUpper && ...
    control.kbInitial >= control.kbLower && control.kbInitial <= control.kbUpper, ...
    'kb 搜索范围或初值不合法。');
assert(control.rotationUpperLowerDegree == 0 && ...
    control.rotationUpperUpperDegree == 180 && ...
    control.rotationUpperInitialDegree >= control.rotationUpperLowerDegree && ...
    control.rotationUpperInitialDegree <= control.rotationUpperUpperDegree, ...
    '朝向展宽上限的搜索范围或初值不合法。');
assert(islogical(control.createFigures) && isscalar(control.createFigures), ...
    'createFigures 必须为逻辑标量。');
assert(islogical(control.enableSnellRefinement) && ...
    isscalar(control.enableSnellRefinement), ...
    'enableSnellRefinement 必须为逻辑标量。');
assert(islogical(control.snellSaveAngularCsv) && ...
    isscalar(control.snellSaveAngularCsv), ...
    'snellSaveAngularCsv 必须为逻辑标量。');
assert(islogical(control.snellEnableJointKbKa) && ...
    isscalar(control.snellEnableJointKbKa), ...
    'snellEnableJointKbKa 必须为逻辑标量。');
assert(isnumeric(control.snellStepReductionFactor) && ...
    isscalar(control.snellStepReductionFactor) && ...
    isfinite(control.snellStepReductionFactor) && ...
    control.snellStepReductionFactor > 0 && ...
    control.snellStepReductionFactor < 1, ...
    'snellStepReductionFactor 必须位于 0 和 1 之间。');
assert(isnumeric(control.minimumJointObjectiveImprovement) && ...
    isscalar(control.minimumJointObjectiveImprovement) && ...
    isfinite(control.minimumJointObjectiveImprovement) && ...
    control.minimumJointObjectiveImprovement >= 0, ...
    'minimumJointObjectiveImprovement 必须为非负有限标量。');
end
