function config = create_dual_axis_config()
%CREATE_DUAL_AXIS_CONFIG 建立 X/Y 双 FWHM、三参数坐标优化配置。
%
% 本函数依赖原“高斯核散射模型完整坐标优化程序”中的
% create_diffuser_config.m。新增的三个优化变量为：
%   1. kb                  椭球短轴/长轴比例；
%   2. kaScale             宽深比 k_a 上下限的整体尺度；
%   3. rotationUpperDegree 长轴随机朝向的上限，theta~U(0,thetaMax)。

config = create_diffuser_config();

% 与原论文第五章及原总控程序保持一致的基础结构。
config.geometry.Lx = 0.5;
config.geometry.Ly = 0.5;
config.geometry.Nx = 100;
config.geometry.Ny = 100;
config.height.minimum = 0.018;
config.height.maximum = 0.030;
config.height.alpha = 1.22;
config.height.beta = 4.48;
config.aspectKa.minimum = 0.5;
config.aspectKa.maximum = 0.8;
config.aspectKa.alpha = 0.40;
config.aspectKa.beta = 0.40;
config.geometry.kb = 0.80;
config.geometry.positionJitterFraction = 0.40;
config.geometry.rotationRange = pi;
config.numerical.softMinK = 2500;
config.numerical.searchResolutionX = 600;
config.numerical.searchResolutionY = 600;
config.numerical.resolutionX = 600;
config.numerical.resolutionY = 600;
config.angular.minimumDegree = -60;
config.angular.maximumDegree = 60;
config.angular.sampleCount = 301;

% 原评价函数仍需一个 primary target；实际优化不使用这个单一目标，
% 而使用下面 dualTarget 中的 X/Y 两个目标。
config.target.metric = 'centerCutX';
config.target.fwhmDegree = 30;
config.target.angleToleranceDegree = 0.10;

config.dualTarget.xFwhmDegree = 30;
config.dualTarget.yFwhmDegree = 20;
config.dualTarget.xToleranceDegree = 0.10;
config.dualTarget.yToleranceDegree = 0.10;
% 两个输入值只提供目标大小；不绑定 X/Y。较大值匹配整个 diffuser
% 的最大主方向 FWHM，较小值匹配最小主方向 FWHM。
config.dualTarget.objectiveDefinition = ...
    'directionalExtremaMaximumNormalizedError';

config.dualOptimization.baseAspectKaMinimum = 0.5;
config.dualOptimization.baseAspectKaMaximum = 0.8;
config.dualOptimization.currentKaScale = 1.0;
config.dualOptimization.stage1RotationUpperDegree = 0;
config.dualOptimization.stage2RotationUpperDegree = 0;

config.dualOptimization.parameters = struct( ...
    'name', {'kb','kaScale','rotationUpperDegree'}, ...
    'displayName', {'长短轴比例','宽深比整体尺度','长轴朝向展宽上限'}, ...
    'enabled', {true,true,true}, ...
    'lowerBound', {0.40,0.50,0.0}, ...
    'upperBound', {1.00,1.50,180.0}, ...
    'initialValue', {0.80,1.00,0.0}, ...
    'coarseStep', {0.02,0.02,10.0}, ...
    'fineStep', {0.005,0.002,1.0}, ...
    'isInteger', {false,false,false});

config.dualOptimization.noImprovementPatience = 3;
config.dualOptimization.maximumEvaluationsPerParameter = 80;
% kaScale 首次优化后，使用无序双目标在 0 degree 下交替重扫 kb/kaScale。
config.dualOptimization.maximumJointRefinementRounds = 5;
config.dualOptimization.minimumJointObjectiveImprovement = 1e-4;
config.dualOptimization.useTargetOnlyAngularDuringSearch = true;
config.dualOptimization.failFast = false;

% 防止旧优化入口误启用原来的参数列表。
for index = 1:numel(config.optimization.parameters)
    config.optimization.parameters(index).enabled = false;
end
config.optimization.baseAspectKaMinimum = ...
    config.dualOptimization.baseAspectKaMinimum;
config.optimization.baseAspectKaMaximum = ...
    config.dualOptimization.baseAspectKaMaximum;
config.optimization.currentKaScale = config.dualOptimization.currentKaScale;

validate_dual_axis_config(config);
end
