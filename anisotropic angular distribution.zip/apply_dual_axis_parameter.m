function updatedConfig = apply_dual_axis_parameter(config,parameter,value)
%APPLY_DUAL_AXIS_PARAMETER 将一个三参数候选值写入物理配置。

assert(isfinite(value) && isscalar(value), '候选值必须为有限标量。');
assert(value >= parameter.lowerBound-10*eps && ...
       value <= parameter.upperBound+10*eps, ...
    '参数 %s 的候选值超出搜索范围。',parameter.name);
if parameter.isInteger
    value = round(value);
end

updatedConfig = config;
switch parameter.name
    case 'kaScale'
        updatedConfig.aspectKa.minimum = ...
            config.dualOptimization.baseAspectKaMinimum*value;
        updatedConfig.aspectKa.maximum = ...
            config.dualOptimization.baseAspectKaMaximum*value;
        updatedConfig.dualOptimization.currentKaScale = value;
        % 同步旧字段，使原模型的保存和缓存接口保持一致。
        updatedConfig.optimization.baseAspectKaMinimum = ...
            config.dualOptimization.baseAspectKaMinimum;
        updatedConfig.optimization.baseAspectKaMaximum = ...
            config.dualOptimization.baseAspectKaMaximum;
        updatedConfig.optimization.currentKaScale = value;

    case 'kb'
        updatedConfig.geometry.kb = value;

    case 'rotationUpperDegree'
        % 原表面生成模块随后执行 theta=rotationRange*U，故这里写入上限。
        updatedConfig.geometry.rotationRange = deg2rad(value);

    otherwise
        error('未知双方向优化参数：%s。',parameter.name);
end
validate_dual_axis_config(updatedConfig);
end
