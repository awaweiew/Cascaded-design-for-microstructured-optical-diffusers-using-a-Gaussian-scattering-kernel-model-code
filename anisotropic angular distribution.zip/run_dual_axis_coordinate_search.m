function searchResult = run_dual_axis_coordinate_search( ...
        initialConfig,randomBank,outputDirectory)
%RUN_DUAL_AXIS_COORDINATE_SEARCH 按指定物理顺序执行三阶段优化。
%
% 阶段一：rotationUpperDegree=0，只优化 kb，使整个散射分布的最大
%         主方向 FWHM 达到两个输入目标中的较大值。
% 阶段二：保持 rotationUpperDegree=0，先固定 kb 优化 kaScale；如未
%         同时达标，则交替全范围重扫 kb/kaScale，消除两者耦合误差。
% 阶段三：固定 kb 和 kaScale，从 0 degree 开始优化朝向随机范围上限。
%         即使阶段二已达标，也会进入阶段三；此时会在初始 0 degree
%         立即满足判据并退出，不改变已有结果。

if nargin < 3
    outputDirectory = '';
end
validate_dual_axis_config(initialConfig);

parameters = initialConfig.dualOptimization.parameters;
kbParameter = get_parameter_local(parameters,'kb');
kaParameter = get_parameter_local(parameters,'kaScale');
rotationParameter = get_parameter_local(parameters,'rotationUpperDegree');
assert(kbParameter.enabled && kaParameter.enabled && rotationParameter.enabled, ...
    '分阶段算法要求 kb、kaScale 和 rotationUpperDegree 全部启用。');

baseOptions.resolutionX = initialConfig.numerical.searchResolutionX;
baseOptions.resolutionY = initialConfig.numerical.searchResolutionY;
baseOptions.retainLargeData = false;
baseOptions.failFast = initialConfig.dualOptimization.failFast;
if initialConfig.dualOptimization.useTargetOnlyAngularDuringSearch
    baseOptions.angularMode = 'targetOnly';
else
    baseOptions.angularMode = 'full';
end

cache = containers.Map('KeyType','char','ValueType','any');
history = repmat(empty_history_local(),0,1);
parameterResults = repmat(empty_parameter_result_local(),0,1);
currentConfig = initialConfig;
currentConfig = apply_dual_axis_parameter( ...
    currentConfig,kbParameter,kbParameter.initialValue);
currentConfig = apply_dual_axis_parameter( ...
    currentConfig,kaParameter,kaParameter.initialValue);

fprintf('\n[开始最大/最小主方向 FWHM 的三阶段优化]\n');
fprintf('最大方向目标：%.6f deg；最小方向目标：%.6f deg。\n', ...
    max(initialConfig.dualTarget.xFwhmDegree, ...
        initialConfig.dualTarget.yFwhmDegree), ...
    min(initialConfig.dualTarget.xFwhmDegree, ...
        initialConfig.dualTarget.yFwhmDegree));

%% ================= 阶段一：0 degree 下优化 kb =================
currentConfig = apply_dual_axis_parameter(currentConfig,rotationParameter, ...
    currentConfig.dualOptimization.stage1RotationUpperDegree);
stage1Options = baseOptions;
stage1Options.objectiveMode = 'maximumDirection';
stage1Initial = evaluate_dual_axis_candidate( ...
    currentConfig,randomBank,stage1Options);
history(end+1,1) = evaluation_history_local(stage1Initial,1, ...
    'kb',get_dual_axis_parameter(currentConfig,kbParameter), ...
    'stage_initial',0);
fprintf('\n--- 阶段一：朝向上限 0 deg，优化 kb ---\n');
print_evaluation_local('阶段一初始',stage1Initial);

[currentConfig,stage1Result] = optimize_one_dual_axis_parameter( ...
    currentConfig,randomBank,kbParameter,stage1Options,cache);
history = append_parameter_history_local( ...
    history,stage1Result,1,'maximumDirection',0);
parameterResults(end+1,1) = parameter_summary_local( ...
    stage1Result,1,'maximumDirection',true,0);
stage1Final = evaluate_dual_axis_candidate( ...
    currentConfig,randomBank,stage1Options);
history(end+1,1) = evaluation_history_local(stage1Final,1, ...
    'kb',get_dual_axis_parameter(currentConfig,kbParameter), ...
    'stage_final',0);
print_evaluation_local('阶段一结束',stage1Final);
save_checkpoint_local(outputDirectory,currentConfig,history,parameterResults,1);

if ~stage1Final.maximumDirectionSatisfied
    fprintf(['阶段一尚未达到最终容差；保留当前最佳 kb，继续 kaScale ', ...
        '及 kb/kaScale 联合修正。\n']);
end

%% ================= 阶段二：保持 0 degree，优化 kaScale =================
currentConfig = apply_dual_axis_parameter(currentConfig,rotationParameter, ...
    currentConfig.dualOptimization.stage2RotationUpperDegree);
stage2Options = baseOptions;
stage2Options.objectiveMode = 'directionalExtrema';
stage2Initial = evaluate_dual_axis_candidate( ...
    currentConfig,randomBank,stage2Options);
history(end+1,1) = evaluation_history_local(stage2Initial,2, ...
    'kaScale',get_dual_axis_parameter(currentConfig,kaParameter), ...
    'stage_initial',0);
fprintf('\n--- 阶段二：保持朝向上限 0 deg，优化 kaScale ---\n');
print_evaluation_local('阶段二初始',stage2Initial);

[currentConfig,stage2Result] = optimize_one_dual_axis_parameter( ...
    currentConfig,randomBank,kaParameter,stage2Options,cache);
history = append_parameter_history_local( ...
    history,stage2Result,2,'directionalExtrema',0);
parameterResults(end+1,1) = parameter_summary_local( ...
    stage2Result,2,'directionalExtrema',true,0);
stage2Final = evaluate_dual_axis_candidate( ...
    currentConfig,randomBank,stage2Options);
history(end+1,1) = evaluation_history_local(stage2Final,2, ...
    'kaScale',get_dual_axis_parameter(currentConfig,kaParameter), ...
    'stage_final',0);
print_evaluation_local('阶段二结束',stage2Final);
save_checkpoint_local(outputDirectory,currentConfig,history,parameterResults,2);

%% ========== 阶段二联合修正：0 degree 下交替优化 kb/kaScale ==========
jointNoImprovementCount = 0;
maximumJointRounds = currentConfig.dualOptimization. ...
    maximumJointRefinementRounds;
minimumJointImprovement = currentConfig.dualOptimization. ...
    minimumJointObjectiveImprovement;
for jointRound = 1:maximumJointRounds
    if stage2Final.withinBothTolerances
        break;
    end
    roundInitialScore = stage2Final.objectiveScore;
    fprintf(['\n--- 阶段二联合修正，第 %d/%d 轮：', ...
        '重新扫描 kb 和 kaScale ---\n'],jointRound,maximumJointRounds);

    [currentConfig,jointKbResult] = optimize_one_dual_axis_parameter( ...
        currentConfig,randomBank,kbParameter,stage2Options,cache);
    history = append_parameter_history_local(history,jointKbResult,2, ...
        'directionalExtrema_joint_refinement',jointRound);
    parameterResults(end+1,1) = parameter_summary_local( ...
        jointKbResult,2,'directionalExtrema_joint_refinement',true,jointRound); %#ok<AGROW>
    jointEvaluation = evaluate_dual_axis_candidate( ...
        currentConfig,randomBank,stage2Options);
    print_evaluation_local(sprintf('联合第 %d 轮 kb 后',jointRound), ...
        jointEvaluation);

    if ~jointEvaluation.withinBothTolerances
        [currentConfig,jointKaResult] = optimize_one_dual_axis_parameter( ...
            currentConfig,randomBank,kaParameter,stage2Options,cache);
        history = append_parameter_history_local(history,jointKaResult,2, ...
            'directionalExtrema_joint_refinement',jointRound);
        parameterResults(end+1,1) = parameter_summary_local( ...
            jointKaResult,2,'directionalExtrema_joint_refinement',true,jointRound); %#ok<AGROW>
        jointEvaluation = evaluate_dual_axis_candidate( ...
            currentConfig,randomBank,stage2Options);
        print_evaluation_local(sprintf('联合第 %d 轮 kaScale 后', ...
            jointRound),jointEvaluation);
    end

    stage2Final = jointEvaluation;
    history(end+1,1) = evaluation_history_local(stage2Final,2, ...
        'jointRefinement',NaN,'joint_round_final',jointRound); %#ok<AGROW>
    save_checkpoint_local(outputDirectory,currentConfig,history, ...
        parameterResults,2);
    if stage2Final.withinBothTolerances
        fprintf('阶段二联合修正已使两个方向同时达标。\n');
        break;
    end

    roundImprovement = roundInitialScore-stage2Final.objectiveScore;
    if roundImprovement > minimumJointImprovement
        jointNoImprovementCount = 0;
    else
        jointNoImprovementCount = jointNoImprovementCount+1;
    end
    fprintf('本轮最大归一化误差改善量：%.9g。\n',roundImprovement);
    if jointNoImprovementCount >= ...
            currentConfig.dualOptimization.noImprovementPatience
        fprintf('联合修正连续 %d 轮无显著改善，结束联合修正。\n', ...
            jointNoImprovementCount);
        break;
    end
end

%% ================= 阶段三：从 0 degree 优化朝向上限 =================
fprintf('\n--- 阶段三：优化长轴朝向随机范围上限 ---\n');
stage3Options = baseOptions;
stage3Options.objectiveMode = 'directionalExtrema';
[currentConfig,stage3Result] = optimize_one_dual_axis_parameter( ...
    currentConfig,randomBank,rotationParameter,stage3Options,cache);
history = append_parameter_history_local( ...
    history,stage3Result,3,'directionalExtrema',0);
parameterResults(end+1,1) = parameter_summary_local( ...
    stage3Result,3,'directionalExtrema',true,0);
stage3Final = evaluate_dual_axis_candidate( ...
    currentConfig,randomBank,stage3Options);
history(end+1,1) = evaluation_history_local(stage3Final,3, ...
    'rotationUpperDegree', ...
    get_dual_axis_parameter(currentConfig,rotationParameter), ...
    'stage_final',0);
print_evaluation_local('阶段三结束',stage3Final);
save_checkpoint_local(outputDirectory,currentConfig,history,parameterResults,3);

if stage3Final.withinBothTolerances
    if abs(get_dual_axis_parameter(currentConfig,rotationParameter)) < 1e-12
        stopReason = 'directional_extrema_reached_at_zero_rotation';
    else
        stopReason = 'directional_extrema_reached_after_rotation_optimization';
    end
else
    stopReason = 'all_stages_completed_without_full_tolerance';
end
searchResult = finish_search_local(initialConfig,currentConfig, ...
    randomBank,baseOptions,history,parameterResults,3,stopReason,cache);
end

function parameter = get_parameter_local(parameters,name)
index = find(strcmp({parameters.name},name),1);
assert(~isempty(index),'缺少分阶段参数 %s。',name);
parameter = parameters(index);
end

function history = append_parameter_history_local( ...
        history,result,stage,criterion,jointRound)
for index = 1:numel(result.evaluations)
    item = result.evaluations(index);
    row = empty_history_local();
    row.stage = stage;
    row.jointRound = jointRound;
    row.criterion = criterion;
    row.parameterName = result.parameterName;
    row.parameterValue = item.parameterValue;
    row.phase = item.phase;
    row.status = item.status;
    row.fwhmMaximumDegree = item.fwhmMaximumDegree;
    row.fwhmMinimumDegree = item.fwhmMinimumDegree;
    row.maximumDirectionAzimuthDegree = item.maximumDirectionAzimuthDegree;
    row.minimumDirectionAzimuthDegree = item.minimumDirectionAzimuthDegree;
    row.errorMaximumDegree = item.errorMaximumDegree;
    row.errorMinimumDegree = item.errorMinimumDegree;
    row.objectiveScore = item.objectiveScore;
    row.objectiveRmsScore = item.objectiveRmsScore;
    row.withinMaximumTolerance = item.withinMaximumTolerance;
    row.withinMinimumTolerance = item.withinMinimumTolerance;
    row.withinBothTolerances = item.withinBothTolerances;
    row.criterionSatisfied = item.criterionSatisfied;
    row.targetAssignment = item.targetAssignment;
    row.validKernelCount = item.validKernelCount;
    row.elapsedSecond = item.elapsedSecond;
    row.fromCache = item.fromCache;
    row.errorMessage = item.errorMessage;
    history(end+1,1) = row; %#ok<AGROW>
end
end

function row = evaluation_history_local( ...
        evaluation,stage,parameterName,parameterValue,phase,jointRound)
row = empty_history_local();
row.stage = stage;
row.jointRound = jointRound;
row.criterion = evaluation.criterionName;
row.parameterName = parameterName;
row.parameterValue = parameterValue;
row.phase = phase;
row.status = evaluation.status;
row.fwhmMaximumDegree = evaluation.fwhmMaximumDirectionDegree;
row.fwhmMinimumDegree = evaluation.fwhmMinimumDirectionDegree;
row.maximumDirectionAzimuthDegree = evaluation.maximumDirectionAzimuthDegree;
row.minimumDirectionAzimuthDegree = evaluation.minimumDirectionAzimuthDegree;
row.errorMaximumDegree = evaluation.signedErrorMaximumDegree;
row.errorMinimumDegree = evaluation.signedErrorMinimumDegree;
row.objectiveScore = evaluation.objectiveScore;
row.objectiveRmsScore = evaluation.objectiveRmsScore;
row.withinMaximumTolerance = evaluation.withinMaximumTolerance;
row.withinMinimumTolerance = evaluation.withinMinimumTolerance;
row.withinBothTolerances = evaluation.withinBothTolerances;
row.criterionSatisfied = evaluation.criterionSatisfied;
row.targetAssignment = evaluation.targetAssignment;
row.validKernelCount = evaluation.validKernelCount;
row.elapsedSecond = evaluation.elapsedSecond;
row.fromCache = evaluation.fromCache;
row.errorMessage = evaluation.errorMessage;
end

function row = parameter_summary_local( ...
        result,stage,criterion,executed,jointRound)
row = empty_parameter_result_local();
row.stage = stage;
row.jointRound = jointRound;
row.criterion = criterion;
row.parameterName = result.parameterName;
row.displayName = result.displayName;
row.initialValue = result.initialValue;
row.bestValue = result.bestValue;
row.bestObjectiveScore = result.bestObjectiveScore;
row.bestFwhmMaximumDegree = result.bestFwhmMaximumDegree;
row.bestFwhmMinimumDegree = result.bestFwhmMinimumDegree;
row.criterionSatisfied = result.criterionSatisfied;
row.withinBothTolerances = result.withinBothTolerances;
row.executed = executed;
row.stopReason = result.stopReason;
row.evaluationCount = result.evaluationCount;
end

function searchResult = finish_search_local(initialConfig,currentConfig, ...
        randomBank,baseOptions,history,parameterResults,completedStages, ...
        stopReason,cache)
finalOptions = baseOptions;
finalOptions.objectiveMode = 'directionalExtrema';
finalEvaluation = evaluate_dual_axis_candidate( ...
    currentConfig,randomBank,finalOptions);
searchResult.initialConfig = initialConfig;
searchResult.bestConfig = currentConfig;
searchResult.finalSearchEvaluation = finalEvaluation;
searchResult.history = struct2table(history);
searchResult.parameterResults = struct2table(parameterResults);
searchResult.completedStages = completedStages;
if isempty(parameterResults)
    searchResult.jointRefinementRounds = 0;
else
    searchResult.jointRefinementRounds = max([parameterResults.jointRound]);
end
searchResult.stopReason = stopReason;
searchResult.cacheEntryCount = cache.Count;
end

function print_evaluation_local(label,evaluation)
if strcmp(evaluation.criterionName,'maximumDirection')
    fprintf(['%s：最大方向 FWHM=%.6f deg（方位 %.3f deg），', ...
        '目标=%.6f deg，score=%.6f，阶段达标=%d。\n'],label, ...
        evaluation.fwhmMaximumDirectionDegree, ...
        evaluation.maximumDirectionAzimuthDegree, ...
        evaluation.targetMaximumDegree,evaluation.objectiveScore, ...
        evaluation.criterionSatisfied);
else
    fprintf(['%s：最大方向 %.6f deg@%.3f deg -> %.6f deg；', ...
        '最小方向 %.6f deg@%.3f deg -> %.6f deg；', ...
        'score=%.6f，同时达标=%d。\n'],label, ...
        evaluation.fwhmMaximumDirectionDegree, ...
        evaluation.maximumDirectionAzimuthDegree, ...
        evaluation.targetMaximumDegree, ...
        evaluation.fwhmMinimumDirectionDegree, ...
        evaluation.minimumDirectionAzimuthDegree, ...
        evaluation.targetMinimumDegree,evaluation.objectiveScore, ...
        evaluation.withinBothTolerances);
end
end

function save_checkpoint_local(outputDirectory,currentConfig,history, ...
        parameterResults,stage)
if isempty(outputDirectory)
    return;
end
if ~isfolder(outputDirectory)
    mkdir(outputDirectory);
end
historyTable = struct2table(history);
parameterResultTable = struct2table(parameterResults);
save(fullfile(outputDirectory,'dual_axis_checkpoint.mat'), ...
    'currentConfig','historyTable','parameterResultTable','stage','-v7.3');
end

function row = empty_history_local()
row = struct('stage',0,'jointRound',0,'criterion','','parameterName','', ...
    'parameterValue',NaN,'phase','','status','invalid', ...
    'fwhmMaximumDegree',NaN,'fwhmMinimumDegree',NaN, ...
    'maximumDirectionAzimuthDegree',NaN, ...
    'minimumDirectionAzimuthDegree',NaN, ...
    'errorMaximumDegree',NaN,'errorMinimumDegree',NaN, ...
    'objectiveScore',Inf,'objectiveRmsScore',Inf, ...
    'withinMaximumTolerance',false,'withinMinimumTolerance',false, ...
    'withinBothTolerances',false,'criterionSatisfied',false, ...
    'targetAssignment','','validKernelCount',0,'elapsedSecond',NaN, ...
    'fromCache',false,'errorMessage','');
end

function row = empty_parameter_result_local()
row = struct('stage',0,'jointRound',0,'criterion','','parameterName','', ...
    'displayName','','initialValue',NaN,'bestValue',NaN, ...
    'bestObjectiveScore',Inf,'bestFwhmMaximumDegree',NaN, ...
    'bestFwhmMinimumDegree',NaN,'criterionSatisfied',false, ...
    'withinBothTolerances',false,'executed',false, ...
    'stopReason','','evaluationCount',0);
end
