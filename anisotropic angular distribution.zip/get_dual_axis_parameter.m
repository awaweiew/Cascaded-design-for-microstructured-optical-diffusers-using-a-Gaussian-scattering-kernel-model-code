function value = get_dual_axis_parameter(config,parameter)
%GET_DUAL_AXIS_PARAMETER 从配置读取当前三参数值。

switch parameter.name
    case 'kaScale'
        value = config.dualOptimization.currentKaScale;
    case 'kb'
        value = config.geometry.kb;
    case 'rotationUpperDegree'
        value = rad2deg(config.geometry.rotationRange);
    otherwise
        error('未知双方向优化参数：%s。',parameter.name);
end
end
