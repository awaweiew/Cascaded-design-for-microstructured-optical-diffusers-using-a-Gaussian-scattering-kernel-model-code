function [updatedConfig,result] = optimize_one_dual_axis_parameter( ...
        currentConfig,randomBank,parameter,evaluationOptions,evaluationCache)
%OPTIMIZE_ONE_DUAL_AXIS_PARAMETER 固定其余变量，优化一个双目标参数。
%
% 双目标响应可能非单调。为避免只检查初值左右两点而停在局部最优，
% 这里采用：当前点 -> 全搜索边界粗扫描 -> 最佳粗点邻域细搜索。
% 排序首先比较最大归一化误差，再用 RMS 归一化误差打破平局。

if nargin < 5 || isempty(evaluationCache)
    evaluationCache = containers.Map('KeyType','char','ValueType','any');
end

records = repmat(empty_record_local(),0,1);
maximumEvaluations = currentConfig.dualOptimization. ...
    maximumEvaluationsPerParameter;
currentValue = get_dual_axis_parameter(currentConfig,parameter);
stopReason = 'maximum_evaluations';

currentRecord = evaluate_value_local(currentValue,'initial');
bestRecord = currentRecord;
if currentRecord.criterionSatisfied
    stopReason = 'stage_criterion_reached_at_initial_value';
    finish_local();
    return;
end

coarseValues = build_scan_values_local(parameter.lowerBound, ...
    parameter.upperBound,parameter.coarseStep,parameter.isInteger);
for index = 1:numel(coarseValues)
    if numel(records) >= maximumEvaluations
        stopReason = 'maximum_evaluations_during_global_coarse_scan';
        break;
    end
    value = coarseValues(index);
    if already_evaluated_local(value)
        continue;
    end
    record = evaluate_value_local(value,'global_coarse_scan');
    update_best_local(record);
    if record.criterionSatisfied
        stopReason = 'stage_criterion_reached_during_global_coarse_scan';
        finish_local();
        return;
    end
end

if numel(records) >= maximumEvaluations
    finish_local();
    return;
end
stopReason = 'global_coarse_scan_completed';

% 在整个边界内的最佳粗点附近执行细搜索。
fineLower = max(parameter.lowerBound, ...
    bestRecord.parameterValue-parameter.coarseStep);
fineUpper = min(parameter.upperBound, ...
    bestRecord.parameterValue+parameter.coarseStep);
fineValues = fineLower:parameter.fineStep:fineUpper;
if parameter.isInteger
    fineValues = unique(round(fineValues));
end
for index = 1:numel(fineValues)
    if numel(records) >= maximumEvaluations
        stopReason = 'maximum_evaluations';
        break;
    end
    value = fineValues(index);
    if already_evaluated_local(value)
        continue;
    end
    fineRecord = evaluate_value_local(value,'fine_refinement');
    update_best_local(fineRecord);
    if fineRecord.criterionSatisfied
        stopReason = 'stage_criterion_reached_during_fine_refinement';
        break;
    end
end
if ~bestRecord.criterionSatisfied && ...
        ~strcmp(stopReason,'maximum_evaluations')
    stopReason = 'global_scan_and_fine_refinement_completed';
end
finish_local();

    function record = evaluate_value_local(value,phase)
        value = min(max(value,parameter.lowerBound),parameter.upperBound);
        if parameter.isInteger
            value = round(value);
        end
        try
            candidateConfig = apply_dual_axis_parameter( ...
                currentConfig,parameter,value);
            key = build_cache_key_local(candidateConfig,evaluationOptions,randomBank);
            if isKey(evaluationCache,key)
                evaluation = evaluationCache(key);
                fromCache = true;
            else
                evaluation = evaluate_dual_axis_candidate( ...
                    candidateConfig,randomBank,evaluationOptions);
                evaluationCache(key) = evaluation;
                fromCache = false;
            end
        catch exception
            evaluation = invalid_evaluation_local(exception.message,currentConfig);
            fromCache = false;
        end
        record = evaluation_to_record_local(evaluation,value,phase,fromCache);
        records(end+1,1) = record;
    end

    function update_best_local(candidate)
        if is_better_local(candidate,bestRecord)
            bestRecord = candidate;
        end
    end

    function answer = already_evaluated_local(value)
        if isempty(records)
            answer = false;
        else
            tolerance = 1e-11*max(1,abs(value));
            answer = any(abs([records.parameterValue]-value) <= tolerance);
        end
    end

    function finish_local()
        updatedConfig = apply_dual_axis_parameter( ...
            currentConfig,parameter,bestRecord.parameterValue);
        result.parameterName = parameter.name;
        result.displayName = parameter.displayName;
        result.initialValue = currentValue;
        result.bestValue = bestRecord.parameterValue;
        result.bestObjectiveScore = bestRecord.objectiveScore;
        result.bestFwhmMaximumDegree = bestRecord.fwhmMaximumDegree;
        result.bestFwhmMinimumDegree = bestRecord.fwhmMinimumDegree;
        result.criterionSatisfied = bestRecord.criterionSatisfied;
        result.criterionName = bestRecord.criterionName;
        result.withinBothTolerances = bestRecord.withinBothTolerances;
        result.stopReason = stopReason;
        result.evaluationCount = numel(records);
        result.evaluations = records;
        result.bestEvaluation = bestRecord;
    end
end

function values = build_scan_values_local( ...
        lowerBound,upperBound,step,isInteger)
values = lowerBound:step:upperBound;
if isempty(values) || abs(values(end)-upperBound) > ...
        10*eps(max(1,abs(upperBound)))
    values(end+1) = upperBound;
end
if isInteger
    values = round(values);
end
values = unique(values,'stable');
end

function answer = is_better_local(first,second)
tolerance = 1e-12;
if first.objectiveScore < second.objectiveScore-tolerance
    answer = true;
elseif abs(first.objectiveScore-second.objectiveScore) <= tolerance
    answer = first.objectiveRmsScore < second.objectiveRmsScore-tolerance;
else
    answer = false;
end
end

function key = build_cache_key_local(config,options,randomBank)
data.geometry = config.geometry;
data.height = config.height;
data.aspectKa = config.aspectKa;
data.optical = config.optical;
data.effectiveRegion = config.effectiveRegion;
data.kernel = config.kernel;
data.angular = config.angular;
data.measurement = config.measurement;
data.dualTarget = config.dualTarget;
data.seed = config.random.seed;
data.bankSeed = randomBank.seed;
data.resolutionX = options.resolutionX;
data.resolutionY = options.resolutionY;
data.angularMode = options.angularMode;
data.objectiveMode = options.objectiveMode;
key = jsonencode(data);
end

function record = evaluation_to_record_local(evaluation,value,phase,fromCache)
record = empty_record_local();
record.parameterValue = value;
record.phase = phase;
record.status = evaluation.status;
record.fwhmMaximumDegree = evaluation.fwhmMaximumDirectionDegree;
record.fwhmMinimumDegree = evaluation.fwhmMinimumDirectionDegree;
record.maximumDirectionAzimuthDegree = ...
    evaluation.maximumDirectionAzimuthDegree;
record.minimumDirectionAzimuthDegree = ...
    evaluation.minimumDirectionAzimuthDegree;
record.errorMaximumDegree = evaluation.signedErrorMaximumDegree;
record.errorMinimumDegree = evaluation.signedErrorMinimumDegree;
record.objectiveScore = evaluation.objectiveScore;
record.objectiveRmsScore = evaluation.objectiveRmsScore;
record.withinMaximumTolerance = evaluation.withinMaximumTolerance;
record.withinMinimumTolerance = evaluation.withinMinimumTolerance;
record.withinBothTolerances = evaluation.withinBothTolerances;
record.criterionSatisfied = evaluation.criterionSatisfied;
record.criterionName = evaluation.criterionName;
record.targetAssignment = evaluation.targetAssignment;
record.validKernelCount = evaluation.validKernelCount;
record.elapsedSecond = evaluation.elapsedSecond;
record.fromCache = fromCache;
record.errorMessage = evaluation.errorMessage;
end

function record = empty_record_local()
record = struct('parameterValue',NaN,'phase','','status','invalid', ...
    'fwhmMaximumDegree',NaN,'fwhmMinimumDegree',NaN, ...
    'maximumDirectionAzimuthDegree',NaN, ...
    'minimumDirectionAzimuthDegree',NaN, ...
    'errorMaximumDegree',NaN,'errorMinimumDegree',NaN, ...
    'objectiveScore',Inf,'objectiveRmsScore',Inf, ...
    'withinMaximumTolerance',false,'withinMinimumTolerance',false, ...
    'withinBothTolerances',false,'criterionSatisfied',false, ...
    'criterionName','','targetAssignment','', 'validKernelCount',0, ...
    'elapsedSecond',NaN,'fromCache',false,'errorMessage','');
end

function evaluation = invalid_evaluation_local(message,config)
evaluation = struct('status','invalid', ...
    'fwhmMaximumDirectionDegree',NaN, ...
    'fwhmMinimumDirectionDegree',NaN, ...
    'maximumDirectionAzimuthDegree',NaN, ...
    'minimumDirectionAzimuthDegree',NaN, ...
    'signedErrorMaximumDegree',NaN, ...
    'signedErrorMinimumDegree',NaN,'objectiveScore',Inf, ...
    'objectiveRmsScore',Inf,'withinMaximumTolerance',false, ...
    'withinMinimumTolerance',false,'withinBothTolerances',false, ...
    'criterionSatisfied',false,'criterionName','invalid', ...
    'targetAssignment','invalid', ...
    'validKernelCount',0,'elapsedSecond',0,'fromCache',false, ...
    'errorMessage',message, ...
    'targetMaximumDegree',max(config.dualTarget.xFwhmDegree, ...
        config.dualTarget.yFwhmDegree), ...
    'targetMinimumDegree',min(config.dualTarget.xFwhmDegree, ...
        config.dualTarget.yFwhmDegree));
end
